#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# @Time    : 2019/1/6 22:15
# @Author  : Miyouzi
# @File    : Color.py
# @Software: PyCharm

import ctypes, re, subprocess, platform, os, sys, html
from termcolor import cprint
from datetime import datetime
import Config


# GitHub release notes 是 GitHub-flavored-Markdown(標題/粗體/表格/<details>摺疊區塊等), 在 CMD 主控台或
# Telegram/Discord 純文字通知裡原樣印出時, 語法符號會照樣顯示出來(不會真的變成標題/粗體), 例如 "## 標題"、
# "**文字**"、"<details><summary>...</summary>" 這些都會整串照樣印出來, 反而比原始文字更難讀。
# 這裡不追求還原排版, 只求去掉語法符號、留下乾淨的純文字, CMD/Telegram/Discord 都適用同一份結果
_MD_DETAILS_TAG_PATTERN = re.compile(r'</?details>', re.IGNORECASE)
_MD_SUMMARY_PATTERN = re.compile(r'<summary>\s*(.*?)\s*</summary>', re.IGNORECASE | re.DOTALL)
_MD_LINK_PATTERN = re.compile(r'\[([^\]]*)\]\(([^)]*)\)')
_MD_IMG_TAG_PATTERN = re.compile(r'<img\b[^>]*>', re.IGNORECASE)
_MD_A_TAG_PATTERN = re.compile(r'<a\b[^>]*href="([^"]*)"[^>]*>(.*?)</a>', re.IGNORECASE | re.DOTALL)
_MD_BR_TAG_PATTERN = re.compile(r'<br\s*/?>', re.IGNORECASE)
_MD_HTML_TAG_PATTERN = re.compile(r'</?(?:strong|em|b|i|u|s|del|p|div|span)\b[^>]*>', re.IGNORECASE)
_MD_HEADER_PATTERN = re.compile(r'^\s{0,3}#{1,6}\s*(.*?)\s*#*\s*$')
_MD_BOLD_ITALIC_PATTERN = re.compile(r'(\*\*\*|\*\*|\*|___|__|_)(.+?)\1')
_MD_TABLE_SEPARATOR_PATTERN = re.compile(r'^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$')


def markdown_to_plain_text(md):
    if not md:
        return md
    text = _MD_SUMMARY_PATTERN.sub(lambda m: m.group(1) + '\n', md)
    text = _MD_DETAILS_TAG_PATTERN.sub('', text)
    text = _MD_A_TAG_PATTERN.sub(lambda m: m.group(2) + '(' + m.group(1) + ')', text)
    text = _MD_IMG_TAG_PATTERN.sub('', text)
    text = _MD_BR_TAG_PATTERN.sub('\n', text)
    text = _MD_HTML_TAG_PATTERN.sub('', text)
    text = _MD_LINK_PATTERN.sub(lambda m: m.group(1) + ('(' + m.group(2) + ')' if m.group(2) else ''), text)

    lines = []
    for line in text.split('\n'):
        if _MD_TABLE_SEPARATOR_PATTERN.match(line):
            continue  # 表格的 |---|---| 分隔列, 純文字沒有對齊的意義, 直接丟掉
        header_match = _MD_HEADER_PATTERN.match(line)
        if header_match:
            line = header_match.group(1)
        line = _MD_BOLD_ITALIC_PATTERN.sub(lambda m: m.group(2), line)
        stripped = line.strip()
        if stripped.startswith('|') and stripped.endswith('|'):
            line = stripped[1:-1].replace('|', '  ').strip()
        lines.append(line.rstrip())

    text = '\n'.join(lines)
    text = re.sub(r'\n{3,}', '\n\n', text).strip('\n')
    return text


# Dashboard「發現新版本」彈窗專用: 這份文件本身就是照抄 RELEASE_NOTES_vX.Y.Z.md 的內容發布到 GitHub release
# 上, 該檔案固定只用 <details>/<summary>/<br>/<strong>/<u> 等少數幾個 HTML 標籤 + 行內 `code`/連結/表格這幾種
# GFM 語法, 兩者範圍是我們自己完全掌握的固定集合。跟 markdown_to_plain_text() 服務的通道不同(那個給
# CMD/Telegram/Discord 純文字用, 直接去掉所有標籤與語法符號), 這裡要輸出能直接塞進網頁的 HTML, 讓
# <details> 摺疊區塊真的可以摺疊。整段文字一律先 html.escape() 跳脫, 再只解禁上面列的少數標籤,
# 避免任何非預期的原始 HTML(理論上不該出現, 但 release body 終究是外部資料來源)被當成標籤塞進頁面
_MD_INLINE_CODE_PATTERN = re.compile(r'`([^`\n]+)`')
_MD_TABLE_ROW_PATTERN = re.compile(r'^\s*\|(.+)\|\s*$')
_MD_LIST_ITEM_PATTERN = re.compile(r'^-\s+(.*)$')
_ALLOWED_RELEASE_HTML_TAGS = ('details', '/details', 'summary', '/summary',
                              'strong', '/strong', 'u', '/u', 'b', '/b', 'i', '/i', 'em', '/em')
# 頁尾贊助徽章是 <a href="..."><img ...></a> 這種帶屬性的原生 HTML, 不在上面的白名單機制(只認得沒有屬性的
# 裸標籤)處理範圍內, 過去會被當成不明標籤整段拿掉(見下方 markdown_release_notes_to_html() 結尾的清理正規式)。
# 這裡在跳脫之前先轉成一般的 markdown 連結語法 [alt文字](網址), 讓 _process_inline_markdown() 裡既有、
# 已經驗證過網址通訊協定的安全連結轉換邏輯接手, 不需要另外實作一套屬性解析/跳脫邏輯, 也不必放行任意 <img>
_MD_RAW_BADGE_LINK_PATTERN = re.compile(
    r'<a\s+href="(https?://[^"]+)"[^>]*>\s*<img\s+[^>]*?alt="([^"]*)"[^>]*/?>\s*</a>', re.IGNORECASE)


def _bold_italic_sub(m):
    marker = m.group(1)
    return ('<strong>' if marker in ('**', '__') else '<em>') + m.group(2) + \
           ('</strong>' if marker in ('**', '__') else '</em>')


def _process_inline_markdown(line):
    # 行內程式碼片段(`code`)先擷取出來用佔位符暫時取代, 再套用粗體/斜體與連結轉換, 避免片段內容本身
    # (例如 `@digest_update_note@`、`get_episode_list()`)裡的底線/星號被誤判成斜體/粗體標記,
    # 或裡面剛好出現的 [x](y) 形狀文字被誤判成連結語法; 處理完畢後才把程式碼片段原樣還原回去
    code_spans = []

    def _stash_code(m):
        code_spans.append(m.group(1))
        return '\x00CODE%d\x00' % (len(code_spans) - 1)

    line = _MD_INLINE_CODE_PATTERN.sub(_stash_code, line)
    # 連結網址已經跳脫過雙引號等字元(html.escape 的預設行為包含 quote=True), 可以直接放進 href 屬性,
    # 但跳脫雙引號只防得住從屬性值「跳脫出去」的注入, 防不住 javascript: 這種本身就不需要引號就能執行的
    # scheme——release body 終究是外部資料來源(理論上該由我們自己掌控, 但上游 GitHub release 內容遭竄改
    # 並非不可能), 只放行 http(s)/mailto, 其餘一律當成純文字(不做成可點擊連結), 避免點擊就執行任意 JS
    line = _MD_LINK_PATTERN.sub(
        lambda m: '<a href="' + m.group(2) + '" target="_blank" rel="noopener noreferrer">' + m.group(1) + '</a>'
        if m.group(2) and re.match(r'(https?|mailto):', m.group(2), re.IGNORECASE) else
        (m.group(1) if m.group(2) else m.group(0)), line)
    line = _MD_BOLD_ITALIC_PATTERN.sub(_bold_italic_sub, line)
    for i, code in enumerate(code_spans):
        line = line.replace('\x00CODE%d\x00' % i, '<code>' + code + '</code>')
    return line


def markdown_release_notes_to_html(md):
    if not md:
        return ''
    md = _MD_RAW_BADGE_LINK_PATTERN.sub(lambda m: '[' + (m.group(2) or '連結') + '](' + m.group(1) + ')', md)
    text = html.escape(md)
    for tag in _ALLOWED_RELEASE_HTML_TAGS:
        text = text.replace('&lt;' + tag + '&gt;', '<' + tag + '>')
    text = text.replace('&lt;br&gt;', '<br>').replace('&lt;br/&gt;', '<br>').replace('&lt;br /&gt;', '<br>')

    lines = []
    table_buffer = []
    list_buffer = []  # 累積目前這個 <ul> 底下每個 <li> 的內容(逐項目一個字串, 換行的續行併進同一項)

    def flush_table():
        if not table_buffer:
            return
        rows_html = []
        for i, cells in enumerate(table_buffer):
            cell_tag = 'th' if i == 0 else 'td'
            rows_html.append('<tr>' + ''.join('<' + cell_tag + '>' + _process_inline_markdown(c.strip()) +
                                               '</' + cell_tag + '>' for c in cells) + '</tr>')
        lines.append('<table class="table table-sm table-bordered">' + ''.join(rows_html) + '</table>')
        table_buffer.clear()

    def flush_list():
        if not list_buffer:
            return
        lines.append('<ul>' + ''.join('<li>' + item + '</li>' for item in list_buffer) + '</ul>')
        list_buffer.clear()

    def append_plain_line(raw_line):
        # 這個檔案裡的一般段落文字慣例是每一行結尾自己帶 <br> 手動換行(方便 GitHub 網頁與這裡的 HTML
        # 轉換同時適用), 但不是每一行都有(例如段落最後一行、或倚賴空白行斷開的引言區塊), 若照原樣拿去跟
        # 下一行用純粹的 "\n" 接在一起, 瀏覽器預設會把沒有 <br> 的換行整個吃掉、擠成同一行(這正是「完整
        # 變更歷史」那行黏到下一行「如果喜歡的可以按下 Star」的成因)。這裡在真正的文字內容行(排除已經是
        # <details>/<summary> 這類整行都是標籤的結構行, 以及本來就空白的行)結尾補一個 <br>, 缺的地方統一補齊,
        # 已經有的不會重複疊加
        processed = _process_inline_markdown(raw_line)
        stripped = processed.strip()
        if stripped and not stripped.startswith('<') and not processed.rstrip().endswith('<br>'):
            processed = processed.rstrip() + '<br>'
        lines.append(processed)

    for line in text.split('\n'):
        if _MD_TABLE_SEPARATOR_PATTERN.match(line):
            continue  # 表格的 |---|---| 分隔列, HTML 表格不需要這行
        row_match = _MD_TABLE_ROW_PATTERN.match(line)
        if row_match:
            flush_list()
            table_buffer.append(row_match.group(1).split('|'))
            continue
        flush_table()
        list_match = _MD_LIST_ITEM_PATTERN.match(line)
        if list_match:
            list_buffer.append(_process_inline_markdown(list_match.group(1)))
            continue
        if list_buffer and line.strip() and not line.lstrip().startswith('<'):
            # 清單項目的續行(原始 .md 裡靠行尾 <br> 手動換行、沒有再打一次 "- " 前綴的那些行, 見
            # RELEASE_NOTES 裡每個項目常見的多行寫法), 併進上一個 <li> 而不是另起新的一行/新的清單,
            # 否則會在還沒真的結束這個項目時就把清單砍斷。上一行結尾通常已經自帶 <br>(來源 .md 手動換行
            # 的慣例), 這裡先看有沒有, 沒有才補一個, 避免疊成 <br><br>
            prev = list_buffer[-1].rstrip()
            if not prev.endswith('<br>'):
                prev += '<br>'
            list_buffer[-1] = prev + _process_inline_markdown(line)
            continue
        flush_list()
        header_match = _MD_HEADER_PATTERN.match(line)
        if header_match:
            lines.append('<strong>' + _process_inline_markdown(header_match.group(1)) + '</strong>')
            continue
        line = re.sub(r'^\s{0,3}&gt;\s?', '', line)  # 引用區塊的 "> " 標記, 沒有對應樣式可用, 去掉即可
        append_plain_line(line)
    flush_table()
    flush_list()

    result = '\n'.join(lines)
    # 沒被 _ALLOWED_RELEASE_HTML_TAGS 解禁、殘留跳脫狀態的原始標籤, 這裡不支援還原成真正的標籤(避免任意
    # 屬性帶來的風險), 直接整段拿掉比留著一串 &lt;xxx&gt; 亂碼好讀(常見的 <a>/<img> 已在上面轉成安全連結,
    # 這裡清理的是其餘沒被特別處理過的標籤)
    result = re.sub(r'&lt;/?[a-zA-Z].*?&gt;', '', result)
    return re.sub(r'\n{3,}', '\n\n', result).strip('\n')


def safe_text(text):
    # 部分 Windows 主控台編碼(例如 cp950)無法顯示某些字元(常見於 GitHub release notes 等外部來源文字)
    # 印出前先做編碼健檢, 無法編碼的字元改用問號等替代, 避免整個程式因 UnicodeEncodeError 而崩潰
    encoding = getattr(sys.stdout, 'encoding', None) or 'utf-8'
    try:
        text.encode(encoding)
        return text
    except (UnicodeEncodeError, LookupError):
        return text.encode(encoding, errors='replace').decode(encoding)


def read_log_settings():
    try:
        return Config.get_log_settings()
    except BaseException as e:
        print(safe_text('日誌配置讀取失敗, 將使用默認配置: 啓用日誌, 最多保存7份 '+str(e)))
        return {'save_logs': True, 'quantity_of_logs': 7}


log_settings = read_log_settings()


def _detect_tty_type():
    # 判斷目前終端機類型只跟這個行程本身的 stdout/stderr 連接到哪種主控台有關, 執行期間不會改變,
    # 拆成獨立函式在模組載入時算一次並快取結果(見下方 _tty_type), 不要在 succeed_or_failed_print()
    # 裡每次印訊息都重新呼叫一次——過去那樣寫等於每印一行狀態訊息(下載成功/失敗訊息, 批次下載時非常頻繁)
    # 就另外開一個 shell 子行程執行 tty 指令, 而且只讀 stdout、從未 wait()/close(), 完全交給 GC 回收,
    # 長時間執行下來會不斷產生用不到的行程與管道控制代碼
    try:
        with subprocess.Popen('tty', shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE) as check_tty:
            stdout_data, _ = check_tty.communicate()
        return stdout_data.decode("utf-8")[0:-1]
    except BaseException:
        return ''


_tty_type = _detect_tty_type()


def err_print(sn, err_msg, detail='', status=0, no_sn=False, prefix='', display=True, display_time=True):
    # status 三個設定值, 0 為一般輸出, 1 為錯誤輸出, 2 為成功輸出
    # err_msg 為信息類型/概要, 最好為四字中文
    # detail 為詳細信息描述
    # no_sn 控制是否打印 sn , 默認打印
    # display 是否在 console 顯示（False則僅輸出在日誌文件）
    # display_time 是否顯示時間
    # 格式範例:
    # 2019-01-30 17:22:30 更新狀態: sn=12345 檢查更新失敗, 跳過等待下次檢查
    green = False

    def succeed_or_failed_print():
        safe_msg = safe_text(msg)
        if 'Windows' in platform.system() and _tty_type in ('/dev/cons0', ''):
            clr = Color()
            if green:
                clr.print_green_text(safe_msg)
            else:
                clr.print_red_text(safe_msg)
        else:
            if green:
                cprint(safe_msg, 'green', attrs=['bold'])
            else:
                cprint(safe_msg, 'red', attrs=['bold'])

    if display_time:
        msg = prefix + datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' '
    else:
        msg = prefix

    if no_sn:
        msg = msg + err_msg + ' ' + detail
    else:
        msg = msg + err_msg + ': sn=' + str(sn) + '\t' + detail

    if display:
        if status == 0:
            print(safe_text(msg))
        elif status == 1:
            # 為 1 錯誤輸出
            green = False
            succeed_or_failed_print()
        else:
            # 為 2 成功輸出
            green = True
            succeed_or_failed_print()

    if log_settings['save_logs']:
        logs_dir = os.path.join(Config.get_working_dir(), 'logs')
        if not os.path.exists(logs_dir):
            os.makedirs(logs_dir)
        log_path = os.path.join(logs_dir, datetime.now().strftime("%Y-%m-%d") + '.log')
        with open(log_path, 'a+', encoding='utf-8') as log:
            log.write(msg + '\n')


# 用於Win下染色輸出，代碼來自 https://blog.csdn.net/five3/article/details/7630295
class Color:
    ''' See http://msdn.microsoft.com/library/default.asp?url=/library/en-us/winprog/winprog/windows_api_reference.asp
    for information on Windows APIs.'''

    def __init__(self):
        self.FOREGROUND_RED = 0x04
        self.FOREGROUND_GREEN = 0x02
        self.FOREGROUND_BLUE = 0x01
        self.FOREGROUND_INTENSITY = 0x08
        STD_OUTPUT_HANDLE = -11
        self.handle = ctypes.windll.kernel32.GetStdHandle(STD_OUTPUT_HANDLE)

    def set_cmd_color(self, color):
        """(color) -> bit
        Example: set_cmd_color(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE | FOREGROUND_INTENSITY)
        """
        bool = ctypes.windll.kernel32.SetConsoleTextAttribute(self.handle, color)
        return bool

    def reset_color(self):
        self.set_cmd_color(self.FOREGROUND_RED | self.FOREGROUND_GREEN | self.FOREGROUND_BLUE)

    def print_red_text(self, print_text):
        self.set_cmd_color(self.FOREGROUND_RED | self.FOREGROUND_INTENSITY)
        print(print_text)
        self.reset_color()

    def print_green_text(self, print_text):
        self.set_cmd_color(self.FOREGROUND_GREEN | self.FOREGROUND_INTENSITY)
        print(print_text)
        self.reset_color()
