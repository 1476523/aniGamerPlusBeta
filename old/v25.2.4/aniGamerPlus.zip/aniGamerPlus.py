#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# @Time    : 2019/1/4 1:00
# @Author  : Miyouzi
# @File    : aniGamerPlus.py
# @Software: PyCharm

import sys as _sys

# 快速取得Cookie/UA-JA3-Akamai 的瀏覽器輔助子行程進入點: 打包成 .exe 後 sys.executable 就是
# aniGamerPlus.exe 自己(沒有另外隨附 python.exe 可以執行 Dashboard/quick_fetch.py), 所以改成
# 自己重新呼叫自己並帶上這個隱藏旗標來啟動輔助子行程, 必須放在 gevent monkey-patch 與其餘重量級
# import 之前判斷, 才能盡快跳過整支程式原本的啟動流程(讀取設定/連線檢查等)
if len(_sys.argv) >= 2 and _sys.argv[1] == '--quick-fetch':
    import os as _os
    _sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))
    from Dashboard import quick_fetch as _quick_fetch
    _quick_fetch.main(_sys.argv[2:])
    _sys.exit(0)

# 非阻塞 (Web)
from gevent import monkey
monkey.patch_all()


import os, sys, time, re, random, traceback, argparse
import signal
import sqlite3
import hashlib
import threading
import subprocess
import platform
import socket
import requests
from contextlib import closing
import datetime

import Config
import NotifyDB
import Gossip
from Anime import Anime, TryTooManyTimeError, ForceStopError, warm_up_cookie_session
from ColorPrint import err_print, markdown_to_plain_text, markdown_release_notes_to_html
from Danmu import Danmu


def port_is_available(port):
    # 檢測端口是否可用(未佔用), 可用返回 True
    # 參考: https://blog.csdn.net/roger_royer/article/details/79519826
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    result = sock.connect_ex(('127.0.0.1', port))
    sock.close()
    if result == 0:
        return False
    else:
        return True


def gost_port():
    random_port = random.randint(40000, 60000)
    while not port_is_available(random_port):
        # 如果該端口不可用
        random_port = random.randint(40000, 60000)
    return random_port


def build_anime(sn, manual=False):
    anime = {'anime': None, 'failed': True}
    try:
        if settings['use_gost']:
            # 如果使用 gost, 則隨機一個 gost 監聽端口
            anime['anime'] = Anime(sn, gost_port=gost_port, manual=manual)
        else:
            anime['anime'] = Anime(sn, manual=manual)
        anime['failed'] = False

        if danmu:
            anime['anime'].enable_danmu()

    except TryTooManyTimeError:
        err_print(sn, '抓取失敗', '影片信息抓取失敗!', status=1)
    except ForceStopError as e:
        err_print(sn, '抓取失敗', '致命錯誤, 終止任務: ' + str(e), status=1)
    except BaseException as e:
        err_print(sn, '抓取失敗', '抓取影片信息時發生未知錯誤: '+str(e), status=1)
        err_print(sn, '抓取異常', '異常詳情:\n'+traceback.format_exc(), status=1, display=False)

    # sn 解析冷卻
    if settings['parse_sn_cd'] > 0:
        err_print("更新資訊", "SN 解析冷卻 " + str(settings['parse_sn_cd']) + " 秒", no_sn=True)
        time.sleep(settings['parse_sn_cd'])

    return anime


def read_db_all():
    db_locker.acquire()
    try:
        with closing(sqlite3.connect(db_path)) as conn:
            cursor = conn.cursor()
            cursor.execute("select * FROM anime")
            values = cursor.fetchall()
            cursor.close()
    finally:
        db_locker.release()

    anime_db = [0] * len(values)
    for i in range(len(values)):
        anime_db[i] = {'sn': values[i][0],
                    'title': values[i][1],
                    'anime_name': values[i][2],
                    'episode': values[i][3],
                    'status': values[i][4],
                    'remote_status': values[i][5],
                    'resolution': values[i][6],
                    'file_size': values[i][7],
                    'local_file_path': values[i][8]}
    return anime_db


def read_db(sn):
    db_locker.acquire()
    # 傳入sn(int)，讀取該 sn 資料，返回 dict
    try:
        with closing(sqlite3.connect(db_path)) as conn:
            cursor = conn.cursor()
            cursor.execute("select * FROM anime WHERE sn=:sn", {'sn': sn})
            values = cursor.fetchall()[0]
            cursor.close()
    finally:
        db_locker.release()
    anime_db = {'sn': values[0],
                'title': values[1],
                'anime_name': values[2],
                'episode': values[3],
                'status': values[4],
                'remote_status': values[5],
                'resolution': values[6],
                'file_size': values[7],
                'local_file_path': values[8]}
    return anime_db


def insert_db(anime):
    db_locker.acquire()
    # 向數據庫插入新資料
    anime_dict = {'sn': str(anime.get_sn()),
                  'title': anime.get_title(),
                  'anime_name': anime.get_bangumi_name(),
                  'episode': anime.get_episode()}

    try:
        with closing(sqlite3.connect(db_path)) as conn:
            cursor = conn.cursor()
            try:
                cursor.execute("INSERT INTO anime (sn, title, anime_name, episode) VALUES (:sn, :title, :anime_name, :episode)",
                               anime_dict)
            except sqlite3.IntegrityError as e:
                err_print(anime_dict['sn'], 'ＤＢ錯誤', 'title=' + anime_dict['title'] + ' 數據已存在！' + str(e), status=1)
            cursor.close()
            conn.commit()
    finally:
        db_locker.release()


def update_db(anime):
    db_locker.acquire()
    # 更新數據庫 status, resolution, file_size 資料
    anime_dict = {}
    # 邊界值需要跟 worker()/`__download_only()` 判定失敗用的 `video_size < 5` 一致(即 >=5 才算成功),
    # 否則剛好 5MB 時 worker() 當作成功繼續往下跑(上傳/發通知), 這裡卻寫入 status=0(失敗), 下次檢查更新
    # 又會看到 status==0 而重新排入下載, 永遠重複下載同一集
    if anime.video_size >= 5:
        anime_dict['status'] = 1
    else:
        # 下載失敗
        anime_dict['status'] = 0

    if anime.upload_succeed_flag:
        anime_dict['remote_status'] = 1
    else:
        anime_dict['remote_status'] = 0

    anime_dict['sn'] = anime.get_sn()
    anime_dict['title'] = anime.get_title()
    anime_dict['anime_name'] = anime.get_bangumi_name()
    anime_dict['episode'] = anime.get_episode()
    anime_dict['file_size'] = anime.video_size
    anime_dict['resolution'] = anime.video_resolution
    anime_dict['local_file_path'] = anime.local_video_path

    try:
        with closing(sqlite3.connect(db_path)) as conn:
            cursor = conn.cursor()
            try:
                cursor.execute(
                    "UPDATE anime SET status=:status,"
                    "remote_status=:remote_status,"
                    "resolution=:resolution,"
                    "file_size=:file_size,"
                    "local_file_path=:local_file_path WHERE sn=:sn",
                    anime_dict)
            finally:
                cursor.close()
                conn.commit()
    finally:
        db_locker.release()


def mark_episode_as_downloaded(ep_sn, anime_name, title, episode):
    # Dashboard「重新檢查排程更新」的「標記為已下載」: 不實際下載, 直接把該集在 aniGamer.db 標成已完成(status=1),
    # 讓之後的排程檢查不再重複把它排入下載(適用於使用者已經自行取得該集、或根本不想補下載的情況)
    # 資料庫尚無該列就先補一列(title/anime_name/episode 為 NOT NULL, 呼叫端保證帶入非空字串), 已有就只改 status
    db_locker.acquire()
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    try:
        cursor.execute("INSERT OR IGNORE INTO anime (sn, title, anime_name, episode) "
                       "VALUES (:sn, :title, :anime_name, :episode)",
                       {'sn': ep_sn, 'title': title, 'anime_name': anime_name, 'episode': episode})
        cursor.execute("UPDATE anime SET status=1 WHERE sn=:sn", {'sn': ep_sn})
        conn.commit()
    finally:
        cursor.close()
        conn.close()
        db_locker.release()


def _cleanup_removed_sn_list_entries(old_sns, new_sns):
    # 偵測 sn_list.txt 中被移除的 sn, 將該作品在 aniGamer.db 中的相關紀錄(同 anime_name 底下所有集數)一併清除
    # 只清除資料庫紀錄, 不會刪除已下載的實體檔案; 若之後又重新加回 sn_list.txt, 該作品會被視為全新項目重新下載
    # 回傳實際被清除的 [{'anime_name': str, 'removed_count': int}], 供呼叫端(如 Dashboard 手動整頓)顯示結果
    #
    # 「還有沒有在追蹤」不能靠 anime_name 字面比對(舊做法: 拿其他仍追蹤中 sn 在資料庫裡的 anime_name 互相比對)。
    # 一來那些 sn 可能從沒下載過, 資料庫裡根本沒有對應的列可以比對; 二來使用者事後改了 <重新命名> 標籤、
    # 或站方調整了 [年齡限制版] 這類分類標籤, 都會讓字面對不上, 明明還在追蹤卻被誤判成孤兒紀錄刪除
    # (實測案例:《從後面來的神威先生》)。改成對被移除的 sn 重新做一次線上查詢, 展開它完整的集數 sn 清單,
    # 跟 sn_list.txt 目前仍在追蹤的 sn 集合做交集, 只要有交集就代表同一部作品還在追蹤, 不受名稱字面影響
    removed_sns = old_sns - new_sns
    cleaned = []
    if not removed_sns:
        return cleaned
    already_checked_names = set()
    db_locker.acquire()
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    try:
        for sn in removed_sns:
            cursor.execute("SELECT anime_name FROM anime WHERE sn=:sn", {'sn': sn})
            row = cursor.fetchone()
            if row is None:
                continue  # 這個 sn 從沒成功下載過, 資料庫裡沒有紀錄, 不用清理
            anime_name = row[0]
            if anime_name in already_checked_names:
                continue  # 同一部作品的其他集數 sn 已經處理過
            already_checked_names.add(anime_name)

            try:
                episode_sns = set(Anime(sn).get_episode_list().values())
                episode_sns.add(sn)
                still_tracked = bool(episode_sns & new_sns)
            except BaseException as e:
                # 線上查詢失敗(可能該 sn 已下架或暫時連線異常): 為避免誤刪, 這次先當作仍在追蹤跳過,
                # 等下次能成功查詢到時再判斷
                err_print(sn, 'sn_list清理', '查詢集數列表失敗, 本次暫不清理避免誤刪: ' + str(e), status=1)
                continue
            if still_tracked:
                continue

            cursor.execute("SELECT COUNT(*) FROM anime WHERE anime_name=:name", {'name': anime_name})
            removed_count = cursor.fetchone()[0]
            cursor.execute("DELETE FROM anime WHERE anime_name=:name", {'name': anime_name})
            conn.commit()
            cleaned.append({'anime_name': anime_name, 'removed_count': removed_count})
            err_print(sn, 'sn_list清理',
                      f'偵測到已從 sn_list.txt 移除, 清除資料庫中《{anime_name}》相關紀錄共 {removed_count} 筆 (不影響已下載的檔案)',
                      status=2)
    finally:
        cursor.close()
        conn.close()
        db_locker.release()
    return cleaned


def run_db_cleanup():
    # Dashboard「資料庫整頓」背景任務: 對 sn_list.txt 每個項目發線上查詢,
    # sn_list.txt 上字面的 sn 對 latest/all/largest-sn 模式而言幾乎不會等於資料庫裡任何一列的 sn(見排程掃描功能的說明),
    # 不能直接拿字面 sn 跟資料庫比對, 所以這裡展開每個追蹤項目「完整的集數 sn 清單」, 再用 sn 是否有交集
    # 找出 aniGamer.db 中「疑似」不再被追蹤的作品(不影響已下載的檔案)
    # 不能用 anime_name 字面比對: 使用者事後在 sn_list.txt 加上 <重新命名> 標籤、或動畫瘋站方事後調整
    # [年齡限制版] 這類分類標籤, 都會讓資料庫裡舊紀錄的 anime_name 跟現在重新解析出來的字面對不上,
    # 明明還在追蹤卻被誤判成孤兒紀錄(實測案例:《從後面來的神威先生》舊紀錄帶 [年齡限制版] 後綴, 但
    # sn_list.txt 目前的 <重新命名> 是乾淨的「從後面來的神威先生」, 字面比對會誤判; sn 交集不受影響)
    # 即使 sn 交集判斷已經比字面比對可靠很多, 仍然不是 100% 沒有例外(例如某些冷門解析情境),
    # 所以這裡只負責「掃描列出候選」, 不自動刪除——實際刪不刪、刪哪些, 交給使用者在 Dashboard 勾選確認,
    # 真正的刪除動作在 run_db_cleanup_delete()
    # 過程中設置 maintenance_mode, 讓主循環與自訂排程背景執行緒暫停排入新的檢查/下載任務
    state = Config.db_cleanup_state
    state.clear()
    state.update({'status': 'running', 'total': 0, 'done': 0, 'current_sn': None,
                  'current_title': '', 'candidates': [], 'removed': [], 'cancel': False})
    Config.maintenance_mode.set()
    try:
        current_sns = sorted(Config.read_sn_list().keys())
        state['total'] = len(current_sns)
        tracked_episode_sns = set()
        failed_sns = []
        for sn in current_sns:
            if state.get('cancel'):
                state['status'] = 'cancelled'
                return
            state['current_sn'] = sn
            state['current_title'] = ''

            settings = Config.read_settings()
            anime_result = build_anime(sn)  # 內部已 sleep parse_sn_cd 秒
            _rate_limit_sleep(settings)

            if anime_result['failed']:
                failed_sns.append(sn)
            else:
                anime = anime_result['anime']
                state['current_title'] = anime.get_bangumi_name()
                # get_episode_list() 直接從同一次頁面請求解析, 不會額外發送網路請求
                tracked_episode_sns.add(sn)
                tracked_episode_sns.update(anime.get_episode_list().values())
            state['done'] += 1

        if failed_sns:
            # 有解析失敗的項目時, 為避免誤判成孤兒紀錄而誤列, 整個整頓中止不列出任何候選
            state['status'] = 'error'
            state['error'] = '以下 sn 線上查詢失敗, 為避免誤判資料已中止整頓, 請稍後再試: ' + ', '.join(map(str, failed_sns))
            return

        db_locker.acquire()
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        candidates = []
        try:
            cursor.execute("SELECT DISTINCT anime_name FROM anime")
            all_names = {row[0] for row in cursor.fetchall()}
            for anime_name in all_names:
                cursor.execute("SELECT sn FROM anime WHERE anime_name=:name", {'name': anime_name})
                db_sns = {row[0] for row in cursor.fetchall()}
                if db_sns & tracked_episode_sns:
                    continue  # 有 sn 交集, 仍在追蹤中(即使 anime_name 字面對不上也不列入候選)
                candidates.append({'anime_name': anime_name, 'episode_count': len(db_sns)})
        finally:
            cursor.close()
            conn.close()
            db_locker.release()

        candidates.sort(key=lambda c: c['anime_name'])
        state['candidates'] = candidates
        state['status'] = 'done'
    except BaseException as e:
        state['status'] = 'error'
        state['error'] = str(e)
        err_print(0, '資料庫整頓', '執行時發生未知錯誤: ' + str(e), status=1, no_sn=True)
    finally:
        Config.maintenance_mode.clear()


def run_db_cleanup_delete(anime_names):
    # 使用者在 Dashboard 勾選確認後才真正執行刪除; 只接受這次掃描候選清單裡出現過的名稱, 避免任意刪除
    # 刪除前用「目前 sn_list.txt 字面上的 sn」再檢查一次(輕量、不發網路請求), 防止使用者勾選確認前又把
    # 同一部作品重新加回 sn_list.txt 卻用了剛好等於舊資料庫紀錄裡的 sn 這種極端情況下誤刪
    state = Config.db_cleanup_state
    candidate_names = {c['anime_name'] for c in state.get('candidates', [])}
    to_delete = [name for name in anime_names if name in candidate_names]

    current_sns = set(Config.read_sn_list().keys())
    cleaned = []
    db_locker.acquire()
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    try:
        for anime_name in to_delete:
            cursor.execute("SELECT sn FROM anime WHERE anime_name=:name", {'name': anime_name})
            db_sns = {row[0] for row in cursor.fetchall()}
            if db_sns & current_sns:
                err_print(0, 'sn_list清理', f'《{anime_name}》在勾選確認前已被重新加回 sn_list.txt, 已跳過不刪除',
                          no_sn=True, status=1)
                continue
            removed_count = len(db_sns)
            cursor.execute("DELETE FROM anime WHERE anime_name=:name", {'name': anime_name})
            conn.commit()
            cleaned.append({'anime_name': anime_name, 'removed_count': removed_count})
            err_print(0, 'sn_list清理', f'資料庫整頓: 清除《{anime_name}》相關紀錄共 {removed_count} 筆 (不影響已下載的檔案)',
                      no_sn=True, status=2)
    finally:
        cursor.close()
        conn.close()
        db_locker.release()

    state['removed'] = cleaned
    state['candidates'] = [c for c in state.get('candidates', []) if c['anime_name'] not in {x['anime_name'] for x in cleaned}]
    return cleaned


_NUMERIC_EPISODE_LABEL = re.compile(r'^\d+(\.\d+)?$')


def _rate_limit_sleep(settings):
    # 對 ani.gamer.com.tw 的每次請求都至少間隔 3 秒(不論 parse_sn_cd 設多少), 避免這個功能短時間內密集發送請求
    # build_anime() 內部已經 sleep 過一次 parse_sn_cd 秒, 這裡只補足與 3 秒的差額
    extra = 3 - settings['parse_sn_cd']
    if extra > 0:
        time.sleep(extra)


_EPISODE_LABEL_NUM = re.compile(r'^(\D*)(\d+(?:\.\d+)?)$')  # 前綴文字(可空) + 尾端數字(可含小數), 例如 '特別篇12'/'6.5'


def _format_episode_group(items):
    # items: [(原始標籤, sn), ...], 同一組(本篇/中文配音/特別篇)內部處理
    # 1. 依集數數字排序(而非字串排序, 避免 10 排到 2 前面)
    # 2. 補零寬度依這組最大集數的位數動態決定, 至少 2 位數(集數上看 100 集以上時自動變 3 位數)
    # 3. 若組內存在「X.5」這類半集, 同組內原本是純整數 X 的項目改顯示為「X.0」以便對齊, 只影響有對應半集的那個整數
    # 無法解析出數字的標籤(例如「電影」)不參與補零, 直接沿用原始標籤, 並排在這組最後面
    parsed = []
    numeric_int_parts = set()
    has_half = set()
    for label, ep_sn in items:
        m = _EPISODE_LABEL_NUM.match(label)
        if not m:
            parsed.append({'label': label, 'sn': ep_sn, 'prefix': None, 'num': None, 'num_str': None})
            continue
        prefix, num_str = m.group(1), m.group(2)
        num = float(num_str)
        parsed.append({'label': label, 'sn': ep_sn, 'prefix': prefix, 'num': num, 'num_str': num_str})
        int_part = int(num)
        numeric_int_parts.add(int_part)
        if num != int_part:
            has_half.add(int_part)

    width = max(2, len(str(max(numeric_int_parts))) if numeric_int_parts else 2)

    result = []
    for p in parsed:
        if p['num'] is None:
            # 排序鍵 (1, 0): 排在所有數字項目後面, 非數字項目彼此保持原始相對順序(sort 為穩定排序)
            result.append({'label': p['label'], 'sn': p['sn'], 'display': p['label'], 'sort_key': (1, 0)})
            continue
        int_part = int(p['num'])
        padded_int = str(int_part).zfill(width)
        if p['num'] == int_part:
            # 純整數集數; 若同組有對應的 X.5 半集存在, 補上 .0 以便對齊排序與顯示
            frac_display = '.0' if int_part in has_half else ''
        else:
            frac_display = '.' + p['num_str'].split('.', 1)[1]
        display = p['prefix'] + padded_int + frac_display
        result.append({'label': p['label'], 'sn': p['sn'], 'display': display, 'sort_key': (0, p['num'])})

    result.sort(key=lambda d: d['sort_key'])
    for d in result:
        del d['sort_key']
    return result


def _split_episode_groups(episode_list):
    # episode_list: anime.get_episode_list() 原始回傳的 {標籤: sn}
    # 依標籤前綴分成三組, 對應網頁上「本篇」/「中文配音」/「特別篇」三個區塊(與 _filter_bilingual() 的判斷邏輯一致)
    main_items, dub_items, special_items = [], [], []
    for label, ep_sn in episode_list.items():
        if label.startswith('特別篇'):
            special_items.append((label, ep_sn))
        elif label.startswith('中文'):
            dub_items.append((label, ep_sn))
        else:
            main_items.append((label, ep_sn))
    return {
        'main': _format_episode_group(main_items),
        'dub': _format_episode_group(dub_items),
        'special': _format_episode_group(special_items),
    }


def run_episode_scan(sn):
    # Dashboard「掃描集數」背景任務: 對指定 sn 發線上查詢, 取得該作品完整集數清單, 供手動任務的集數勾選框使用
    # 過程中設置 maintenance_mode, 讓主循環與自訂排程背景執行緒暫停排入新的檢查/下載任務
    state = Config.episode_scan_state
    state.clear()
    state.update({'status': 'running', 'sn': sn, 'anime_name': '', 'groups': {}, 'cancel': False})
    Config.maintenance_mode.set()
    try:
        if state.get('cancel'):
            state['status'] = 'cancelled'
            return
        anime_result = build_anime(sn)  # 內部已 sleep parse_sn_cd 秒
        if state.get('cancel'):
            state['status'] = 'cancelled'
            return
        if anime_result['failed']:
            state['status'] = 'error'
            state['error'] = '線上查詢失敗, 無法取得作品資訊(sn 可能不存在或裝置驗證異常)'
            return
        anime = anime_result['anime']
        state['anime_name'] = anime.get_bangumi_name()
        state['groups'] = _split_episode_groups(anime.get_episode_list())
        state['status'] = 'done'
    except BaseException as e:
        state['status'] = 'error'
        state['error'] = '執行時發生未知錯誤: ' + str(e)
        err_print(sn, '掃描集數', '執行時發生未知錯誤: ' + str(e), status=1)
    finally:
        Config.maintenance_mode.clear()


_full_recheck_decision_event = threading.Event()
_full_recheck_decisions = []
# 使用者按下「重新檢查排程更新」後關掉分頁/離開就再也不確認的話, maintenance_mode 會一直卡著,
# 自動更新檢查與排程下載全部停擺; 等這麼久還沒收到確認就視同取消, 讓程式恢復正常運作
_FULL_RECHECK_DECISION_TIMEOUT = 30 * 60


def submit_full_recheck_decisions(decisions):
    # decisions: [{'ep_sn': int, 'action': 'download'|'mark_done'}, ...]; 回傳 False 代表目前不在等待確認狀態
    global _full_recheck_decisions
    state = Config.full_recheck_state
    if state.get('status') != 'awaiting_confirmation':
        return False
    valid = {c['ep_sn'] for c in state.get('candidates', [])}
    _full_recheck_decisions = [d for d in (decisions or [])
                               if d.get('ep_sn') in valid and d.get('action') in ('download', 'mark_done')]
    _full_recheck_decision_event.set()
    return True


def run_full_recheck(sn_filter=None):
    # Dashboard「重新檢查排程更新」背景任務: 用於突發狀況(例如程式離線一段時間、或排程檢查剛好沒抓到更新)導致
    # 前幾天的更新沒有被正常排入下載時, 讓使用者手動補齊更新, 不必等到下次自動檢查或下週同一排程時段
    # sn_filter=None  -> 檢查所有排程(sn_list.txt 全部項目, 不論是否有自訂排程)
    # sn_filter=[...] -> 檢查指定排程(只檢查使用者勾選的那幾個 sn)
    # 兩種模式的檢查階段都「只找出更新、不直接下載」, 找到的候選送到 Dashboard 讓使用者逐項選擇
    # 「下載」或「標記為已下載」, 確認之後才真的排入下載/寫入資料庫; 這是與舊版(檢查完直接下載)最大的差異
    #
    # 過程中設置 maintenance_mode, 讓主循環與自訂排程背景執行緒暫停排入新的檢查/下載任務; 跟其他維護任務不同的是,
    # 這裡的 maintenance_mode 要一直維持到「找到的更新全部下載完成(或個別項目重試逾時放棄)」才會解除,
    # 而不是檢查完 sn_list.txt 就結束——避免下載途中自動排程/全數檢查又跳進來搶並發下載名額或造成裝置驗證異常
    global sn_dict
    state = Config.full_recheck_state
    state.clear()
    state.update({'status': 'running', 'phase': 'checking', 'total_sn': 0, 'checked_sn': 0,
                  'current_sn': None, 'candidates': [], 'tasks': [], 'marked_done': [],
                  'total_progress': 0, 'cancel': False})
    Config.maintenance_mode.set()
    _full_recheck_decision_event.clear()
    try:
        sn_dict = Config.read_sn_list()  # 重新從磁碟讀取, 確保反映使用者可能剛更新過的 sn_list.txt
        sns = sorted(sn_dict.keys())
        if sn_filter:
            wanted = {int(x) for x in sn_filter}
            sns = [sn for sn in sns if sn in wanted]
        state['total_sn'] = len(sns)

        # ---- 階段一: 只檢查, 不排入下載 ----
        for sn in sns:
            if state.get('cancel'):
                state['status'] = 'cancelled'
                return
            state['current_sn'] = sn
            state['candidates'].extend(_check_single_sn(sn, collect_only=True))
            state['checked_sn'] += 1

        if not state['candidates']:
            state['total_progress'] = 100
            state['status'] = 'done'
            return

        # ---- 階段二: 等待使用者逐項確認 ----
        state['phase'] = 'awaiting_confirmation'
        state['status'] = 'awaiting_confirmation'
        if not _full_recheck_decision_event.wait(timeout=_FULL_RECHECK_DECISION_TIMEOUT):
            state['status'] = 'cancelled'
            state['error'] = '等待確認逾時, 已自動取消(未下載也未標記任何項目)'
            return
        if state.get('cancel'):
            state['status'] = 'cancelled'
            return
        decisions = list(_full_recheck_decisions)

        # ---- 階段三: 套用決定 ----
        state['status'] = 'running'
        candidate_by_ep = {c['ep_sn']: c for c in state['candidates']}
        # 先處理「標記為已下載」再處理「下載」: 順序很重要, 底下重跑 _check_single_sn() 是靠資料庫
        # status 判斷還有哪些集數要排入, 先標記完才不會把已標記的集數又排進下載列隊
        for d in decisions:
            if d['action'] != 'mark_done':
                continue
            c = candidate_by_ep[d['ep_sn']]
            mark_episode_as_downloaded(c['ep_sn'], c['anime_name'], c['title'], str(c['episode_display']))
            state['marked_done'].append({'ep_sn': c['ep_sn'], 'title': c['title']})
            err_print(c['ep_sn'], '重新檢查排程更新', '已標記為已下載(未實際下載): ' + c['title'], status=2)

        download_series = sorted({candidate_by_ep[d['ep_sn']]['series_sn']
                                   for d in decisions if d['action'] == 'download'})
        task_by_ep = {}
        pending_since = {}
        for sn in download_series:
            if state.get('cancel'):
                state['status'] = 'cancelled'
                return
            queued_before = set(queue.keys())
            _check_single_sn(sn)  # 正常模式: 真的 insert_db + 排入 queue
            _start_queued_workers()
            for ep in set(queue.keys()) - queued_before:
                # 排隊中還沒真的開始下載時, 用資料庫裡已經記錄的標題顯示(_check_single_sn() 剛剛才 insert_db()
                # 或原本就已存在, 不需要額外的網路請求), 而不是單純的 sn 數字
                try:
                    initial_filename = read_db(ep)['title']
                except IndexError:
                    initial_filename = 'sn=' + str(ep)
                task = {'ep_sn': ep, 'series_sn': sn, 'status': '已排入, 排隊中', 'rate': 0,
                        'filename': initial_filename}
                task_by_ep[ep] = task
                pending_since[ep] = datetime.datetime.now()
                state['tasks'].append(task)

        # ---- 階段四: 下載追蹤(邏輯與舊版相同) ----
        state['phase'] = 'downloading'
        pending = set(task_by_ep.keys())
        while pending and not state.get('cancel'):
            now = datetime.datetime.now()
            for ep in list(pending):
                task = task_by_ep[ep]
                live = Config.tasks_progress_rate.get(int(ep))
                if live:
                    task['status'] = live['status']
                    task['rate'] = live['rate']
                    # worker()/__download_only() 一開始會先把 filename 設成 'sn=' + sn 佔位, 等 build_anime() 解析完
                    # 才換成真正的標題/檔名; 排隊等待並發名額期間會一直是這個佔位字串, 這時候不要蓋掉上面已經填好的
                    # 番劇名+集數顯示, 避免使用者看到的名稱在還沒真的開始下載前又被打回單純的 sn 數字
                    if live['filename'] != 'sn=' + str(ep):
                        task['filename'] = live['filename']
                    continue
                try:
                    done = read_db(ep)['status'] == 1
                except IndexError:
                    done = False
                if done:
                    task['status'] = '下載完成'
                    task['rate'] = 100
                    pending.discard(ep)
                    continue
                if ep in queue.keys() or ep in processing_queue:
                    continue  # 剛失敗被移出隊列又馬上補排回去, 即將重新出現在 tasks_progress_rate, 下一輪再讀
                if now > pending_since[ep] + _scheduled_retry_deadline:
                    task['status'] = '重試逾時, 已放棄(將於下次自動檢查時再試)'
                    pending.discard(ep)
                    continue
                # 已被移出隊列但尚未下載成功, 代表上次嘗試失敗(例如裝置驗證異常): 重新檢查該 sn 讓它自動補排入隊列重試
                task['status'] = '失敗, 重新排入中...'
                _check_single_sn(task['series_sn'])
                _start_queued_workers()

            finished = sum(1 for ep in task_by_ep if ep not in pending)
            state['total_progress'] = round(finished / len(task_by_ep) * 100) if task_by_ep else 100
            if pending:
                time.sleep(1)

        state['total_progress'] = 100
        state['status'] = 'cancelled' if state.get('cancel') else 'done'
    except BaseException as e:
        state['status'] = 'error'
        state['error'] = str(e)
        err_print(0, '重新檢查排程更新', '執行時發生未知錯誤: ' + str(e), status=1, no_sn=True)
    finally:
        Config.maintenance_mode.clear()


def run_schedule_scan():
    # Dashboard「取得當前新番更新時間」背景任務: 對 sn_list.txt 每個項目發線上查詢,
    # 找出該作品「本篇」最新 3 集在網頁上的「上架時間」, 換算成星期+時間候選排程, 交給使用者逐項確認/自訂/跳過後套用
    # 過程中設置 maintenance_mode, 讓主循環與自訂排程背景執行緒暫停排入新的檢查/下載任務
    state = Config.schedule_scan_state
    state.clear()
    state.update({'status': 'running', 'total': 0, 'done': 0, 'current_sn': None,
                  'current_title': '', 'results': [], 'cancel': False})
    Config.maintenance_mode.set()
    try:
        current_sn_dict = Config.read_sn_list()
        sns = sorted(current_sn_dict.keys())
        state['total'] = len(sns)
        for sn in sns:
            if state.get('cancel'):
                state['status'] = 'cancelled'
                return
            state['current_sn'] = sn
            state['current_title'] = ''
            entry = {'sn': sn}

            try:
                settings = Config.read_settings()
                anime_result = build_anime(sn)  # 內部已 sleep parse_sn_cd 秒
                _rate_limit_sleep(settings)

                if anime_result['failed']:
                    entry['action'] = 'error'
                    entry['message'] = '線上查詢失敗, 無法取得作品資訊'
                    entry['candidates'] = []
                else:
                    anime = anime_result['anime']
                    anime_name = anime.get_bangumi_name()
                    entry['anime_name'] = anime_name
                    state['current_title'] = anime_name

                    existing_schedule = current_sn_dict[sn].get('schedule')
                    if existing_schedule:
                        entry['old_weekday'] = Config.WEEKDAY_TO_ZH[existing_schedule['weekday']]
                        entry['old_time'] = f"{existing_schedule['hour']:02d}:{existing_schedule['minute']:02d}"
                    else:
                        entry['old_weekday'] = None
                        entry['old_time'] = None

                    # 找出「本篇」(排除電影/特別篇/中文配音等)裡 sn 最大(最新)的 3 集
                    episode_list = anime.get_episode_list()
                    numeric_eps = [(label, ep_sn) for label, ep_sn in episode_list.items()
                                   if _NUMERIC_EPISODE_LABEL.match(label)]
                    latest_eps = sorted(numeric_eps, key=lambda kv: kv[1], reverse=True)[:3]

                    candidates = []
                    reused_current_page = False
                    for label, ep_sn in latest_eps:
                        if state.get('cancel'):
                            state['status'] = 'cancelled'
                            return
                        if ep_sn == sn and not reused_current_page:
                            ep_anime = anime  # 目前這一頁本身就是目標集數, 不用重複請求
                            reused_current_page = True
                        else:
                            ep_result = build_anime(ep_sn)
                            _rate_limit_sleep(settings)
                            if ep_result['failed']:
                                continue
                            ep_anime = ep_result['anime']
                        upload_time = ep_anime.get_upload_time()
                        if upload_time:
                            candidates.append({
                                'episode': label,
                                'weekday': Config.WEEKDAY_TO_ZH[upload_time.isoweekday()],
                                'time': upload_time.strftime('%H:%M'),
                                'datetime': upload_time.strftime('%Y-%m-%d %H:%M')
                            })

                    # candidates 已經依照 latest_eps 的 sn 由新到舊順序附加, 不需要再重新排序
                    # (若改依 episode 標籤字串排序, "10" 會被排在 "9" 之前, 集數新舊順序反而會錯亂)
                    entry['candidates'] = candidates
                    if not candidates:
                        entry['action'] = 'no_data'
                        entry['message'] = '無法取得任何集數的上架時間(可能為 APP 解析模式或該作品沒有數字集數)'
                    elif len(candidates) < 3:
                        entry['action'] = 'insufficient_data'
                        entry['message'] = f'僅有 {len(candidates)} 集資料可供參考(集數不足 3 集), 請自行判斷或改用自訂時間'
                    else:
                        entry['action'] = 'ok'
            except BaseException as e:
                # 單一項目發生未預期錯誤不應中止整個掃描, 記錄後繼續下一項
                entry['action'] = 'error'
                entry['message'] = '處理時發生未知錯誤: ' + str(e)
                entry['candidates'] = []
                err_print(sn, '新番更新時間分析', '處理此項目時發生未知錯誤: ' + str(e), status=1)

            state['results'].append(entry)
            state['done'] += 1
        state['status'] = 'done'
    except BaseException as e:
        state['status'] = 'error'
        state['error'] = str(e)
        err_print(0, '新番更新時間分析', '執行時發生未知錯誤: ' + str(e), status=1, no_sn=True)
    finally:
        Config.maintenance_mode.clear()


def worker(sn, sn_info, realtime_show_file_size=False):
    bangumi_tag = sn_info['tag']
    rename = sn_info['rename']

    def upload_quit():
        queue.pop(sn)
        processing_queue.remove(sn)
        upload_limiter.release()  # 併發上傳限制器
        sys.exit(0)

    # 整個函式包一層 try/finally: 不論從哪個分支結束(含中途的 sys.exit()), 都要確保這個 sn 被從
    # Config.scheduled_priority_pending_sns 移除, 排程優先插隊(__download_only() 的 defer_for_priority)
    # 才能正確判斷「排程任務是否都處理完了、手動任務可以繼續」, 見 _start_queued_workers() 加入時的說明
    try:
        try:
            anime_in_db = read_db(sn)
        except BaseException as e:
            # read_db() 可能因為這個 sn 的資料庫記錄被同時間的清理作業刪除(例如使用者剛把這部作品從
            # sn_list.txt 移除, run_db_cleanup_delete() 刪掉了記錄)而拋出例外; 這裡若不接住, worker()
            # 唯一的 finally 只會清掉 scheduled_priority_pending_sns, 不會把 sn 從 queue/processing_queue
            # 移除, 導致這個 sn 永久卡在列隊裡、_start_queued_workers() 每輪都跳過它, 直到程式重啟才會恢復
            err_print(sn, '任務失敗', '讀取資料庫記錄失敗(可能已被移除), 從任務列隊中移除, 等待下次重新發現: ' + str(e), status=1)
            queue.pop(sn, None)
            if sn in processing_queue:
                processing_queue.remove(sn)
            if int(sn) in Config.tasks_progress_rate.keys():
                del Config.tasks_progress_rate[int(sn)]
            return
        # 如果用戶設定要上傳且已經下載好了但還沒有上傳成功, 那麼僅上傳
        if settings['upload_to_server'] and anime_in_db['status'] == 1 and anime_in_db['remote_status'] == 0:
            upload_limiter.acquire()  # 併發上傳限制器
            anime = build_anime(sn)
            if anime['failed']:
                err_print(sn, '任務失敗', '從任務列隊中移除, 等待下次更新重試.', status=1)
                upload_quit()

            # 視頻信息抓取成功
            anime = anime['anime']
            if not os.path.exists(anime_in_db['local_file_path']):
                # 如果數據庫中記錄的文件路徑已失效
                update_db(anime)
                err_msg_detail = 'title=\"' + anime.get_title() + '\" 本地文件丟失, 從任務列隊中移除, 等待下次更新重試.'
                err_print(sn, '上傳失敗', err_msg_detail, status=1)
                upload_quit()

            anime.local_video_path = anime_in_db['local_file_path']  # 告知文件位置
            anime.video_size = anime_in_db['file_size']  # 通過 update_db() 下載狀態檢查
            anime.video_resolution = anime_in_db['resolution']  # 避免更新時把分辨率變成0

            try:
                if not anime.upload(bangumi_tag):  # 如果上傳失敗
                    err_msg_detail = 'title=\"' + anime.get_title() + '\" 從任務列隊中移除, 等待下次更新重試.'
                    err_print(sn, '上傳失敗', err_msg_detail, 1)
                else:
                    update_db(anime)
                    err_print(sn, '任務完成', status=2)
            except BaseException as e:
                err_msg_detail = 'title=\"' + anime.get_title() + '\" 發生未知錯誤, 等待下次更新重試: ' + str(e)
                err_print(sn, '上傳失敗', '異常詳情:\n'+traceback.format_exc(), status=1, display=False)
                err_print(sn, '上傳失敗', err_msg_detail, 1)

            upload_quit()

        # =====下載模塊 =====
        # 跟手動任務(__download_only())一樣, 在取得並發號誌、解析 SN 資訊(可能因排程一次帶入多個 sn 而排隊、
        # 或 SN 解析冷卻耗時數秒)之前, 先讓任務以暫定狀態出現在監控列表, 之後由 anime.download() 用實際標題/進度覆蓋
        Config.tasks_progress_rate[int(sn)] = {'rate': 0, 'filename': 'sn=' + str(sn), 'status': '已排入, 排隊中'}
        thread_limiter.acquire()  # 併發下載限制器
        if int(sn) in Config.tasks_progress_rate.keys():
            Config.tasks_progress_rate[int(sn)]['status'] = '準備中(SN解析冷卻)'
        anime = build_anime(sn)

        if anime['failed']:
            queue.pop(sn)
            processing_queue.remove(sn)
            thread_limiter.release()
            err_print(sn, '任務失敗', '從任務列隊中移除, 等待下次更新重試.', status=1)
            if int(sn) in Config.tasks_progress_rate.keys():
                del Config.tasks_progress_rate[int(sn)]
            Config.download_failure_counts[int(sn)] = Config.download_failure_counts.get(int(sn), 0) + 1
            sys.exit(1)

        anime = anime['anime']

        try:
            anime.download(settings['download_resolution'], bangumi_tag=bangumi_tag, rename=rename,
                           realtime_show_file_size=realtime_show_file_size, classify=settings['classify_bangumi'])
        except ForceStopError as e:
            err_print(sn, '下載異常', '遇到致命錯誤, 終止任務: ' + str(e), status=1)
            anime.video_size = 0
        except BaseException as e:
            # 兜一下各種奇奇怪怪的錯誤
            err_print(sn, '下載異常', '發生未知錯誤: '+str(e), status=1)
            err_print(sn, '下載異常', '異常詳情:\n'+traceback.format_exc(), status=1, display=False)
            anime.video_size = 0

        if anime.video_size < 5:
            # 下載失敗
            queue.pop(sn)
            processing_queue.remove(sn)
            thread_limiter.release()
            err_msg_detail = 'title=\"' + anime.get_title() + '\" 從任務列隊中移除, 等待下次更新重試.'
            err_print(sn, '任務失敗', err_msg_detail, status=1)
            if int(sn) in Config.tasks_progress_rate.keys():
                del Config.tasks_progress_rate[int(sn)]  # 任務失敗, 不在監控此任務進度
            Config.download_failure_counts[int(sn)] = Config.download_failure_counts.get(int(sn), 0) + 1
            Config.send_notification(
                'download_schedule_failed', '消息',
                animation_name=anime.get_bangumi_name(),
                episode=anime.get_notify_episode_display(),
                download_time=NotifyDB.now_str(),
                finish_time=NotifyDB.now_str(),
            )
            sys.exit(1)

        Config.download_failure_counts.pop(int(sn), None)  # 下載成功, 重置連續失敗計數
        Config.download_paused_notified.discard(int(sn))  # 一併清掉暫停通知紀錄, 下次再暫停能重新通知一次
        update_db(anime)  # 下載完成後, 更新數據庫
        download_cd = threading.Thread(target=download_cd_counter)
        download_cd.start()
        # =====下載模塊結束 =====

        # =====上傳模塊=====
        if settings['upload_to_server']:
            upload_limiter.acquire()  # 併發上傳限制器

            try:
                anime.upload(bangumi_tag)  # 上傳至服務器
            except BaseException as e:
                # 兜一下各種奇奇怪怪的錯誤
                err_print(sn, '上傳異常', '發生未知錯誤, 從任務列隊中移除, 等待下次更新重試: ' + str(e), status=1)
                err_print(sn, '上傳異常', '異常詳情:\n'+traceback.format_exc(), status=1, display=False)
                upload_quit()

            update_db(anime)  # 上傳完成後, 更新數據庫
            upload_limiter.release()  # 併發上傳限制器
        # =====上傳模塊結束=====

        download_cd.join()
        queue.pop(sn)  # 從任務列隊中移除
        processing_queue.remove(sn)  # 從當前任務列隊中移除
        err_print(sn, '任務完成', status=2)
    finally:
        Config.scheduled_priority_pending_sns.discard(sn)


def download_cd_counter():
    seconds = settings['download_cd']
    while(seconds > 0):
        err_print('', '下載冷卻:', '下載冷卻時間剩餘 ' + str(seconds) + ' 秒', status=0, no_sn=True)
        wait_time = min(30, seconds)
        time.sleep(wait_time)
        seconds -= wait_time
    thread_limiter.release()  # 併發下載限制器


def _check_single_sn(sn, collect_only=False):
    # 檢查單一 sn 是否有更新, 有的話加入下載列隊。回傳 True 表示這次呼叫確實新增了下載任務
    #
    # collect_only=True(供 Dashboard「重新檢查排程更新」的檢查階段使用): 只回傳「這次會被排入的集數清單」,
    # 完全不動 queue、也不寫入資料庫, 讓使用者先逐項決定要下載還是標記為已下載; 真正要下載的項目在確認後
    # 再用一般模式(collect_only=False)重跑一次這個函式排入, 排入邏輯只有一份不會走樣。這個模式下對於
    # 資料庫還沒有紀錄的全新集數, 刻意不呼叫 build_anime(ep) 額外解析(每個新集數都要一次網路請求),
    # 直接沿用這個 sn 本身解析時已經拿到的集數標籤清單組出顯示用的候選項目
    queued_before = set(queue.keys())
    found = []
    anime = build_anime(sn)
    if anime['failed']:
        err_print(sn, '更新狀態', '檢查更新失敗, 跳過等待下次檢查', status=1)
        # # sn 解析冷卻
        # if settings['parse_sn_cd'] > 0:
        #     err_print("更新資訊", "SN 解析冷卻 " + str(settings['parse_sn_cd']) + " 秒", no_sn=True)
        #     time.sleep(settings['parse_sn_cd'])
        return found if collect_only else False
    anime = anime['anime']
    err_print(sn, '更新資訊', '正在檢查《' + anime.get_bangumi_name() + '》')
    episode_dict = anime.get_episode_list()  # {集數標籤: ep_sn}
    episode_list = list(episode_dict.values())
    label_by_sn = {v: k for k, v in episode_dict.items()}

    def _candidate(ep):
        label = label_by_sn.get(ep, str(ep))
        return {'ep_sn': ep, 'series_sn': sn, 'anime_name': anime.get_bangumi_name(),
                'episode_display': label, 'title': anime.get_bangumi_name() + ' [' + str(label) + ']'}

    if sn_dict[sn]['mode'] == 'all':
        # 如果用戶選擇全部下載 download_mode = 'all'
        for ep in episode_list:  # 遍歷劇集列表
            try:
                db = read_db(ep)
                #           未下載的   或                設定要上傳但是沒上傳的                         並且  還沒在列隊中
                if (db['status'] == 0 or (db['remote_status'] == 0 and settings['upload_to_server'])) and ep not in queue.keys():
                    if collect_only:
                        found.append(_candidate(ep))
                    else:
                        queue[ep] = sn_dict[sn]  # 添加至下載列隊
            except IndexError:
                # 如果數據庫中尚不存在此條記錄
                if collect_only:
                    found.append(_candidate(ep))
                    continue
                if anime.get_sn() == ep:
                    new_anime = anime  # 如果是本身則不用重複創建實例
                else:
                    new_anime = build_anime(ep)
                    if new_anime['failed']:
                        err_print(ep, '更新狀態', '更新數據失敗, 跳過等待下次檢查', status=1)
                        continue
                    new_anime = new_anime['anime']
                insert_db(new_anime)
                queue[ep] = sn_dict[sn]  # 添加至列隊
    else:
        if sn_dict[sn]['mode'] == 'single':
            latest_sn = sn  # 適配命令行 sn-list 模式
        elif not episode_list:
            # 頁面解析成功但目前沒有任何集數(例如集數列表暫時為空), 沒有 sn 可比對, 跳過這輪等下次檢查,
            # 避免 episode_list[-1] 對空列表取值拋出 IndexError 一路炸穿到主迴圈導致整個程式崩潰
            err_print(sn, '更新狀態', '目前沒有任何集數可供比對, 跳過等待下次檢查', status=1)
            return found if collect_only else False
        elif sn_dict[sn]['mode'] == 'largest-sn':
            # 如果用戶選擇僅下載最新上傳, download_mode = 'largest_sn', 則對 sn 進行排序
            episode_list.sort()
            latest_sn = episode_list[-1]
            # 否則用戶選擇僅下載最後劇集, download_mode = 'latest', 即下載網頁上顯示在最右的劇集
        else:
            latest_sn = episode_list[-1]
        try:
            db = read_db(latest_sn)
            #           未下載的   或                設定要上傳但是沒上傳的                         並且  還沒在列隊中
            if (db['status'] == 0 or (db['remote_status'] == 0 and settings['upload_to_server'])) and latest_sn not in queue.keys():
                if collect_only:
                    found.append(_candidate(latest_sn))
                else:
                    queue[latest_sn] = sn_dict[sn]  # 添加至下載列隊
        except IndexError:
            # 如果數據庫中尚不存在此條記錄
            if collect_only:
                found.append(_candidate(latest_sn))
            else:
                if anime.get_sn() == latest_sn:
                    new_anime = anime  # 如果是本身則不用重複創建實例
                else:
                    new_anime = build_anime(latest_sn)
                    if new_anime['failed']:
                        err_print(latest_sn, '更新狀態', '更新數據失敗, 跳過等待下次檢查', status=1)
                        return found if collect_only else False
                    new_anime = new_anime['anime']
                insert_db(new_anime)
                queue[latest_sn] = sn_dict[sn]

    # # sn 解析冷卻
    # if settings['parse_sn_cd'] > 0:
    #     err_print("更新資訊", "SN 解析冷卻 " + str(settings['parse_sn_cd']) + " 秒", no_sn=True)
    if collect_only:
        return found
    return len(set(queue.keys()) - queued_before) > 0


def check_tasks():
    for sn in sn_dict.keys():
        if sn_dict[sn].get('schedule'):
            continue  # 有自定義排程的 sn 不納入一般全數檢查, 改由 _scheduled_check_worker 專門處理
        _check_single_sn(sn)


def _start_queued_workers():
    # 為所有已在 queue 中但尚未啟動下載執行緒的任務啟動 worker, 回傳本次新啟動的任務數
    #
    # 排程下載插隊: 這裡是排程檢查(check_tasks())、自訂排程(_scheduled_check_worker())、
    # 「重新檢查所有排程更新」(run_full_recheck()) 三條路徑最終都會呼叫到的共同起點。若當下有任一筆手動批次任務
    # 正在進行中, 這次新啟動的任務就記進 Config.scheduled_priority_pending_sns, 讓批次類手動任務
    # (__download_only() 的 defer_for_priority)暫停啟動新的下載, 優先把並發名額讓給這裡的排程下載
    any_manual_batch_running = any(v.get('status') == 'running' for v in Config.manual_batch_progress.values())
    new_tasks_counter = 0
    if queue:
        for task_sn in list(queue.keys()):
            # 「檢查是否已在跑」到「加入 processing_queue(佔位)」整段必須是原子操作, 否則兩條執行緒可能都在
            # task_sn 還沒被加入 processing_queue 前看到「沒在跑」, 各自啟動一個 worker 對同一集同時下載
            with _queue_lock:
                if task_sn in processing_queue:  # 已在進行中, 跳過
                    continue
                task_info = queue.get(task_sn)
                if task_info is None:
                    continue
                # 連續失敗達 download_retry_count 次(例如 Cookie 過期導致每次都失敗), 不再啟動新的下載執行緒,
                # 避免無限重試對動畫瘋送出大量注定失敗的請求; 直接從 queue 移除, 下次排程檢查若仍未下載成功
                # 會被重新發現、重新排入, 但一樣會在這裡再次被擋下, 不會真的發出網路請求, 直到使用者更新 Cookie
                # (見 Dashboard /cookie 路由清空 Config.download_failure_counts)才會重新獲得完整的重試次數
                # download_retry_count 來自網頁下拉選單, 跟 download_resolution 等其他 <select> 欄位一樣
                # 經前端 id_list 通用邏輯存回設定時會是字串, 這裡用 int() 統一處理, 不管存的是數字還是字串都能比較
                retry_limit = int(settings['download_retry_count'])
                if Config.download_failure_counts.get(int(task_sn), 0) >= retry_limit:
                    queue.pop(task_sn, None)
                    # 「找到更新後持續追蹤下載結果」的機制(_scheduled_check_worker)每 30 秒會重新發現、重新排入
                    # 這個已經暫停中的 sn, 若不擋著會每 30 秒重複印同一則暫停訊息, 最長洗版到 2 小時追蹤逾時
                    # (見 Config.download_paused_notified 的說明); 同一個暫停狀態只印一次
                    if int(task_sn) not in Config.download_paused_notified:
                        Config.download_paused_notified.add(int(task_sn))
                        err_print(task_sn, '任務暫停', '已連續失敗 ' + str(retry_limit) +
                                  ' 次, 暫停自動重試(可能是 Cookie 已過期), 請確認後更新 Cookie 以重新嘗試', status=1)
                    continue
                if any_manual_batch_running:
                    Config.scheduled_priority_pending_sns.add(task_sn)
                processing_queue.append(task_sn)  # 先佔位再放鎖, 確保鎖內完成整個「判斷+登記」
            task = threading.Thread(target=worker, args=(task_sn, task_info))
            task.daemon = True
            task.start()
            new_tasks_counter = new_tasks_counter + 1
            err_print(task_sn, '加入任務列隊')
    return new_tasks_counter


_scheduled_check_state = {}  # {sn: {'window_start': datetime, 'resolved': bool, 'checked': bool, 'pending_episodes': set}}
_weekday_map_zh = {'一': 1, '二': 2, '三': 3, '四': 4, '五': 5, '六': 6, '日': 7}
_daily_digest_sent_date = None  # 「每日新番通知」上次送出的日期(datetime.date), 用來確保每天只在 00:00 觸發一次
_daily_digest_sent_signature = None  # 上次送出時彙整的機動調整異動簽章, 供偵測「送出後又有新異動」以重新發送更新版
# 找到更新後, 若下載失敗(例如兩個排程任務同時交握觸發裝置驗證異常 code=1007)導致任務被移出隊列,
# 最多再花這麼久時間持續追蹤並自動補排入隊列重試, 避免像一般任務一樣必須等到下次檢查(也就是下週同一時段)才會重試
_scheduled_retry_deadline = datetime.timedelta(hours=2)


def _this_week_occurrence(now, weekday, hour, minute):
    # 計算「這一週」內該 weekday 對應的 hour:minute 時間點 (isoweekday: 週一=1 ... 週日=7)
    days_diff = weekday - now.isoweekday()
    candidate_date = now.date() + datetime.timedelta(days=days_diff)
    return datetime.datetime.combine(candidate_date, datetime.time(hour, minute))


def _scheduled_check_worker():
    # 背景執行緒: 專門處理 sn_list 中設定了自定義星期/時間的項目
    # 只在該星期幾的指定時間開始後的 10 分鐘內主動檢查, 找到更新或超過 10 分鐘則跳過, 等下週同一時段再檢查
    # 藉此把這些項目排除在「每次全數檢查」的隊伍外, 避免 sn_list 項目過多時延誤其他項目的檢查
    # 找到更新後不會立刻視為本週結束, 而是持續追蹤該集數是否真的下載成功, 直到成功或追蹤逾時才放棄本週,
    # 這樣即使下載途中失敗(裝置驗證異常等暫時性錯誤)也能在本次執行內自動重試補下載, 不必等到下週或手動重啓程式
    global _daily_digest_sent_date, _daily_digest_sent_signature
    while True:
        if Config.maintenance_mode.is_set():
            # Dashboard 正在執行需要獨佔網路資源的維護操作(例如取得當前新番更新時間), 暫停排入新的排程檢查
            time.sleep(1)
            continue
        try:
            now = datetime.datetime.now()
            if now.hour == 0 and _daily_digest_sent_date != now.date():
                # 先標記今天已送出再實際發送: 就算下面的彙整/發送過程出錯, 也不會在同一天內反覆重試洗版,
                # 等明天 00:00 再重新嘗試即可, 跟這個迴圈本來對其他例外狀況「本次跳過, 下次再說」的處理方式一致
                _daily_digest_sent_date = now.date()
                _send_daily_digest(now)
            elif _daily_digest_sent_date == now.date() and settings['gossip_dynamic_schedule']:
                # v25.2.2 新增: 今天已經送過一次, 之後若「機動調整」被新增/修改/移除(例如公告新增了臨時加更, 或使用者
                # 在「操作處置」手動調整了對應排程), 造成已發送的內容跟目前實際情況不一致, 就重新發送一次
                # 更新版; 只比對機動調整簽章而不比對本日排程清單, 是因為本日排程清單來自 sn_list.txt 本身的
                # 固定排程, 不會在當天無聲無息被改動, 不需要每 30 秒都重新連線查詢集數來比對是否變動
                current_signature = _adjustment_rows_signature(_collect_adjustment_rows(now))
                if current_signature != _daily_digest_sent_signature:
                    _send_daily_digest(now, is_update=True)
            gossip_pending = Gossip.load_pending_snapshot() if settings['gossip_dynamic_schedule'] else None
            if settings['gossip_dynamic_schedule']:
                # 監視公告功能: 依臨時檔(不更動 sn_list.txt)處理「今晚/本週時間調整、延到未來日期、合併集數/加更兩集
                # 的雙重保險複查」, 這些都跟 sn_list.txt 原本的每週排程無關, 獨立處理
                Gossip.process_oneoff_entries(now, _check_single_sn, _start_queued_workers, queue, processing_queue, read_db)
            for sn, info in list(sn_dict.items()):
                schedule = info.get('schedule')
                if not schedule:
                    continue
                if gossip_pending is not None and Gossip.is_skipped(gossip_pending, sn, now.date()):
                    # 公告要求這個 sn 本次(暫停/延期到未來日期)跳過, 不進入這週的排程檢查
                    continue
                window_start = _this_week_occurrence(now, schedule['weekday'], schedule['hour'], schedule['minute'])
                window_end = window_start + datetime.timedelta(minutes=10)
                state = _scheduled_check_state.get(sn)
                if state is None or state['window_start'] != window_start:
                    # 進入新的一週(或第一次看到這個排程, 例如程式重啓), 重置這個 sn 的狀態
                    # 若這次算出的 window_start 是本週已經過去的日子(不是今天), 視為本週已錯過, 直接跳過不補檢查
                    # 避免程式重啓時把「本週一到今天」所有日期的排程都補檢查一遍, 只補檢查今天當天錯過的時段
                    missed_past_day = window_start.date() < now.date()
                    state = {'window_start': window_start, 'resolved': missed_past_day, 'checked': missed_past_day,
                              'pending_episodes': set(), 'pending_since': None}
                    _scheduled_check_state[sn] = state
                if state['resolved']:
                    continue

                if state['pending_episodes']:
                    # 已找到過更新, 追蹤這些集數是否真的下載成功; 若被移出隊列但仍未下載成功(代表上次嘗試失敗),
                    # 重新檢查一次該 sn 讓失敗的集數自動補排入隊列重試
                    # 注意: 這裡的期限要從「開始追蹤」的時間點算起, 不能用 window_start(排定的時間點) 當基準——
                    # 若程式是在排定時間過後很久才補檢查(例如清晨排程但傍晚才啓動/檢查到), window_start 早已是幾小時前,
                    # 用它當基準會讓期限一開始追蹤就已經過期, 完全沒有機會重試
                    if now > state['pending_since'] + _scheduled_retry_deadline:
                        err_print(sn, '排程檢查', '重試逾時仍有集數下載失敗, 放棄本週, 等待下週同一時段', status=1)
                        state['resolved'] = True
                        state['pending_episodes'] = set()
                        continue
                    still_pending = set()
                    need_retry = False
                    for ep in state['pending_episodes']:
                        try:
                            done = read_db(ep)['status'] == 1
                        except IndexError:
                            done = False
                        if done:
                            continue
                        if ep in queue.keys() or ep in processing_queue:
                            still_pending.add(ep)  # 仍在隊列中或下載中, 繼續等待
                        elif Config.download_failure_counts.get(int(ep), 0) >= int(settings['download_retry_count']):
                            # 已經因連續失敗達上限被 _start_queued_workers() 暫停(見那裡的 download_paused_notified
                            # 說明), 不算「值得重試」——不然這裡每 30 秒都會重新排入、被那裡再擋下一次, 直到
                            # 2 小時追蹤逾時為止都是白工。直接放棄追蹤這一集, 使用者更新 Cookie 後
                            # download_failure_counts 會被清空, 下次排程檢查會重新正常嘗試
                            continue
                        else:
                            need_retry = True  # 已被移出隊列但尚未下載成功, 代表上次嘗試失敗
                    if need_retry:
                        queued_before = set(queue.keys())
                        _check_single_sn(sn)
                        still_pending |= (set(queue.keys()) - queued_before)
                        _start_queued_workers()
                    state['pending_episodes'] = still_pending
                    if not still_pending:
                        state['resolved'] = True
                    continue

                if now < window_start:
                    continue  # 還沒到排定時間, 先不檢查

                # 到了排定時間, 或雖然已經過了10分鐘視窗但這週還沒真的檢查過(例如程式剛啟動時排程時間已過去): 至少檢查一次
                if now <= window_end or not state['checked']:
                    queued_before = set(queue.keys())
                    found = _check_single_sn(sn)
                    state['pending_episodes'] = set(queue.keys()) - queued_before
                    if state['pending_episodes']:
                        state['pending_since'] = now
                    state['checked'] = True
                    _start_queued_workers()
                    if found:
                        err_print(sn, '排程檢查', '找到更新, 持續追蹤下載結果直到成功或重試逾時', status=2)
                    elif now > window_end:
                        err_print(sn, '排程檢查', '超過自定義時間10分鐘仍未偵測到更新, 跳過本週, 等待下週同一時段', status=2)
                        state['resolved'] = True
                else:
                    # 已經超過視窗, 且這週已經至少檢查過一次, 也沒有集數在追蹤中
                    state['resolved'] = True
        except BaseException as e:
            err_print(0, '排程檢查異常', '發生未知錯誤: ' + str(e), status=1, no_sn=True)
        time.sleep(30)


def _lookup_cached_anime_name(sn):
    # 從本地 aniGamer.db 的下載紀錄快取撈番劇名稱, 不觸發線上查詢(每日新番通知一次要彙整多部作品,
    # 若每部都線上查詢會很慢也容易觸發驗證/流量限制), 找不到快取紀錄(該 sn 從未成功下載過一集)時回傳 None
    db_locker.acquire()
    try:
        with closing(sqlite3.connect(db_path)) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT anime_name FROM anime WHERE sn=:sn", {'sn': sn})
            row = cursor.fetchone()
    finally:
        db_locker.release()
    return row[0] if row else None


def _display_name_for_sn(sn, info):
    return _lookup_cached_anime_name(sn) or info.get('rename') or ('sn=' + str(sn))


def _fetch_live_anime_info(sn, fallback_name):
    # 每日新番通知需要「目前(本篇)最新集數 + 1」預測本次應該更新到第幾集, 這只能即時連線動畫瘋查詢才拿得到,
    # 本地資料庫的下載紀錄快取只知道「上次成功下載的集數」, 使用者剛好還沒下載完上一集時會不準確, 不能拿來替代。
    #
    # v25.2.2 修正: 不能用 anime.get_episode() —— 那只會回傳「這個 sn 對應的那一集頁面本身是第幾集」, 而
    # sn_list.txt 追蹤時存的通常是第 1 集當初的 sn, 導致這裡查到的永遠是「1」、預測結果永遠是第 2 話, 這正是實測發現
    # 每日新番通知集數預測全部顯示「第02話」的原因。必須改用 get_episode_list() 從整份劇集清單裡挑出
    # 「本篇」數字集數最大的一筆, 才是真正「目前實際更新到第幾集」, 邏輯與 run_schedule_scan() 一致。
    # 查詢失敗(離線/該 sn 已下架等)時退回呼叫端傳入的備援名稱, 集數預測部分留空(None)由呼叫端自行處理
    try:
        anime = Anime(sn)
        numeric_labels = [label for label in anime.get_episode_list().keys() if re.match(r'^\d+$', label)]
        current_ep = max(int(label) for label in numeric_labels) if numeric_labels else None
        return anime.get_bangumi_name(), current_ep
    except BaseException as e:
        err_print(sn, '每日新番通知', '查詢目前集數失敗, 本次不附上集數預測: ' + str(e), status=1)
        return fallback_name, None


def _format_expected_episodes(current_ep, count):
    # current_ep 是「目前(上次)實際集數」, 預測本次應更新到 current_ep+1 ... current_ep+count;
    # current_ep 為 None(電影/特別篇/查詢失敗等無法判斷數字集數)時不附加任何集數說明
    if current_ep is None:
        return ''
    if count <= 1:
        return ', 預計播出第{:02d}話'.format(current_ep + 1)
    labels = ['第{:02d}話'.format(current_ep + i) for i in range(1, count + 1)]
    joined = labels[0] if len(labels) == 1 else ('、'.join(labels[:-1]) + ' 與 ' + labels[-1])
    return ', 預計連續播出{}話({})'.format(count, joined)


# 「本日」比照動畫瘋網站本身「本日更新」的分類方式, 以 13:00 為界: 從當日 13:00 算到隔日 12:59 才算同一個
# 播出日, 而不是日曆上的 00:00~23:59——深夜/凌晨(00:00~12:59)才更新的集數雖然日曆已經跨到隔天, 仍算作
# 「今天」的更新, 這樣才符合番劇實際的播出習慣(多數深夜番在 23:00~01:00 左右更新); 供 _send_daily_digest()
# 與偵測「已發送後是否又有新機動調整異動」共用同一份判斷邏輯
def _row_hour(row):
    # override_check_time 類型自帶 check_time, 直接取小時判斷; override_check_window 類型(模糊時段, 例如
    # 「明日白天」)沒有單一時刻, 退回去用範圍的起始時間判斷; skip_check 類型完全沒有明確時間,
    # 退回去查該 sn 原本的排程時間判斷屬於今天還是隔天的播出日
    if row.get('check_time'):
        return int(row['check_time'].split(':')[0])
    if row.get('check_time_start'):
        return int(row['check_time_start'].split(':')[0])
    schedule = sn_dict.get(row.get('sn'), {}).get('schedule')
    return schedule['hour'] if schedule else None


def _collect_adjustment_rows(now):
    # 統整「本日播出日」(今日13:00~隔日12:59)內生效中的監視公告機動調整(暫停/延期/加更等)異動,
    # 供每日新番通知彙整內容, 以及判斷「已發送過的每日新番通知是否已經過期需要重新發送更新版」兩處共用
    today_str = now.date().strftime('%Y-%m-%d')
    tomorrow_str = (now.date() + datetime.timedelta(days=1)).strftime('%Y-%m-%d')
    adjustment_rows = []
    for row in Gossip.list_pending_for_date(today_str) + Gossip.list_pending_for_date(tomorrow_str):
        row_hour = _row_hour(row)
        if row_hour is None:
            # 查無排程時間可判斷歸屬(例如該 sn 已從排程移除), 保守只在 check_date 為今天時列出, 避免漏掉
            if row.get('check_date') == today_str:
                adjustment_rows.append(row)
        elif row.get('check_date') == today_str and row_hour >= 13:
            adjustment_rows.append(row)
        elif row.get('check_date') == tomorrow_str and row_hour < 13:
            adjustment_rows.append(row)
    adjustment_rows.sort(key=lambda r: (r.get('check_time') or '', r.get('name') or ''))
    return adjustment_rows


def _adjustment_rows_signature(adjustment_rows):
    # 用 (id, updated_at) 組成簽章: 新增/修改一筆會改變它的 updated_at, 移除一筆(狀態轉為 done/expired 後
    # 不再落在 status='pending' 查詢範圍內)則會讓它從清單中消失, 兩種情況都會反映在這裡, 用來判斷已發送的
    # 每日新番通知內容是否已經過期(見 _scheduled_check_worker 呼叫處)
    return tuple(sorted((row.get('id'), row.get('updated_at')) for row in adjustment_rows))


def _send_daily_digest(now, is_update=False):
    # 每日新番通知: 統整「本日」依 sn_list.txt 自訂星期/時間排定更新的番劇, 以及監視公告機動調整(暫停/延期/加更等)
    # 當天生效中的異動, 由 _scheduled_check_worker 每天 00:00 觸發一次(見上方呼叫處); is_update=True 代表
    # 這是同一天內因為機動調整異動有變化而重新發送的更新版(而非首次發送), 通知內容會附上提示文字
    global _daily_digest_sent_signature
    today = now.date()
    tomorrow = today + datetime.timedelta(days=1)
    today_str = today.strftime('%Y-%m-%d')
    tomorrow_str = tomorrow.strftime('%Y-%m-%d')
    today_weekday = today.isoweekday()
    tomorrow_weekday = tomorrow.isoweekday()

    def _in_broadcast_day(schedule_weekday, schedule_hour):
        if schedule_weekday == today_weekday and schedule_hour >= 13:
            return True
        if schedule_weekday == tomorrow_weekday and schedule_hour < 13:
            return True
        return False

    def _in_broadcast_day_for_date(check_date_str, hour):
        # 比照上面 _in_broadcast_day() 的 13:00 分界慣例, 但改用機動調整覆蓋「本身實際生效」的 check_date 判斷,
        # 而不是 sn_list.txt 裡原本的星期幾——修正 v25.2.3 的 bug: 覆蓋把某部作品從「今天 20:30」延到
        # 「明天 08:30」時, 舊邏輯仍用原本星期幾/20:30 判斷還是落在今天的播出日範圍, 於是「本日排程更新」
        # 清單裡冒出一筆其實是明天的時間, 跟「機動調整異動」區塊顯示的日期互相矛盾
        if check_date_str == today_str and hour >= 13:
            return True
        if check_date_str == tomorrow_str and hour < 13:
            return True
        return False

    # 機動調整要先算好, 「本日排程更新」才能依此覆蓋掉 sn_list.txt 裡的靜態排程時間/排除本週暫停的項目——
    # 這兩個區塊過去各自獨立計算, 「本日排程更新」永遠只看靜態時間, 遇到「本週延後更新」這類異動時,
    # 會跟下面「機動調整異動」區塊顯示的新時間互相矛盾(同一部作品出現兩個不同時間), 這裡改成單一資料來源
    adjustment_rows = _collect_adjustment_rows(now)
    override_by_sn = {}
    skipped_sns = set()
    for row in adjustment_rows:
        if row['type'] == 'skip_check':
            skipped_sns.add(row.get('sn'))
        elif row.get('check_time') or row.get('check_time_start'):
            override_by_sn[row.get('sn')] = row

    scheduled_today = []
    for sn, info in sn_dict.items():
        if sn in skipped_sns:
            continue  # 本週暫停更新, 下面「機動調整異動」區塊已經會列出, 這裡不重複顯示成照常排程
        if sn in override_by_sn:
            row = override_by_sn[sn]
            hour_str = row.get('check_time') or row.get('check_time_start')
            hour, minute = (int(x) for x in hour_str.split(':'))
            # 覆蓋的實際日期以 row['check_date'] 為準, 不是 sn_list.txt 的固定星期, 要重新判斷是否落在
            # 「本日播出日」範圍內, 不落在範圍內(已經被改到別天)就不列入本日排程, 避免跟機動調整異動區塊矛盾
            if not _in_broadcast_day_for_date(row.get('check_date'), hour):
                continue
        else:
            schedule = info.get('schedule')
            if not schedule or not _in_broadcast_day(schedule['weekday'], schedule['hour']):
                continue
            hour, minute = schedule['hour'], schedule['minute']
        scheduled_today.append((hour, minute, sn, info))
    # 排序時把 00:00~12:59 視為接在 23:59 之後(而非之前), 呈現順序才會跟實際播出先後一致
    scheduled_today.sort(key=lambda x: ((x[0] - 13) % 24, x[1]))
    schedule_lines = []
    for hour, minute, sn, info in scheduled_today:
        fallback_name = _lookup_cached_anime_name(sn) or info.get('rename') or ('sn=' + str(sn))
        name, current_ep = _fetch_live_anime_info(sn, fallback_name)
        ep_part = '第{:02d}話 '.format(current_ep + 1) if current_ep is not None else ''
        schedule_lines.append('- ' + name + ' ' + ep_part + '{:02d}:{:02d}'.format(hour, minute))

    adjustment_lines = []
    for row in adjustment_rows:
        fallback_name = row.get('name') or ('sn=' + str(row.get('sn')))
        if row['type'] == 'skip_check':
            adjustment_lines.append('- ' + fallback_name + ' 本週暫停更新')
        else:  # override_check_time/override_check_window: 一次性調整檢查時間(本週提前/延後/同時更新/加更/
            # 模糊時段等), 詳見 Gossip.py 的說明
            name, current_ep = _fetch_live_anime_info(row.get('sn'), fallback_name)
            count = row.get('expect_episode_count') or 1
            ep_suffix = _format_expected_episodes(current_ep, count)
            # 修正 v25.2.3 的 bug: 這裡過去無論 check_date 是不是真的今天都硬印「今日」二字,
            # 使用者延到明天的覆蓋在通知裡完全看不出跟今天不一樣
            if row.get('check_date') == today_str:
                date_label = '今日'
            elif row.get('check_date') == tomorrow_str:
                date_label = '明日'
            else:
                date_label = row.get('check_date') or ''
            if row['type'] == 'override_check_window':
                time_desc = (row.get('check_time_start') or '') + '~' + (row.get('check_time_end') or '')
            else:
                time_desc = row.get('check_time') or ''
            adjustment_lines.append('- ' + name + ' ' + date_label + ' ' + time_desc + ' 檢查更新' + ep_suffix)

    Config.send_notification(
        'system_daily_digest', '系統通知',
        digest_date=today_str,
        digest_update_note=' (機動調整異動更新, 重新發送)' if is_update else '',
        today_schedule_count=str(len(schedule_lines)),
        today_schedule_list='\n'.join(schedule_lines) if schedule_lines else '今日無排定更新',
        dynamic_adjustment_count=str(len(adjustment_lines)),
        dynamic_adjustment_list='\n'.join(adjustment_lines) if adjustment_lines else '今日無機動調整異動',
        finish_time=NotifyDB.now_str(),
    )
    # 記住這次送出時的機動調整內容, 供上面的重新發送判斷比對是否有變化; 首次發送(00:00 觸發)與更新版發送
    # 都要更新, 這樣同一天內若後續又有新異動, 才會拿「這次剛送出的版本」而不是「今天最早那一版」來比對
    _daily_digest_sent_signature = _adjustment_rows_signature(adjustment_rows)


def _resume_pending_manual_tasks():
    # 程式啟動時還原上次意外中斷(當機/斷電/被強制關閉等)的手動任務, 詳見 Config.py 開頭關於暫存紀錄檔的說明
    # 單集類(single/latest/largest-sn)重新提交後, __cui() 同步下載完(不論成功失敗)即由這裡的 finally 移除紀錄
    # 批次類(all/range)重新提交後, __cui() 立即回傳, 移除交給背景執行中的 _run_manual_batch_download()
    # 批次類還原時會排除 completed_episodes 裡已經記錄下載成功的集數, 只重新嘗試當機前仍在下載中或已放棄的集數
    single_tasks = Config.read_manual_single_tasks()
    batch_tasks = Config.read_manual_batch_tasks()
    total = len(single_tasks) + len(batch_tasks)
    if total == 0:
        return
    err_print(0, '還原任務', '偵測到 ' + str(total) + ' 個上次意外中斷的手動任務, 重新提交中...', no_sn=True, status=2)

    def _resume_single(params):
        sn = params['sn']
        thread_limit = params['thread']
        if thread_limit > Config.get_max_multi_thread():
            thread_limit = Config.get_max_multi_thread()
        try:
            __cui(sn, params['resolution'], params['mode'], thread_limit, [], classify=params['classify'],
                  realtime_show=False, cui_danmu=params['danmu'], bilingual=params.get('bilingual', False),
                  rename=params.get('rename', ''), resize_thread_limiter=False)
        finally:
            Config.remove_manual_single_task(sn)

    def _resume_batch(params):
        sn = params['sn']
        thread_limit = params['thread']
        if thread_limit > Config.get_max_multi_thread():
            thread_limit = Config.get_max_multi_thread()
        completed_episodes = set(params.get('completed_episodes') or [])
        __cui(sn, params['resolution'], params['mode'], thread_limit, params.get('ep_range') or [],
              classify=params['classify'], realtime_show=False, cui_danmu=params['danmu'],
              bilingual=params.get('bilingual', False), rename=params.get('rename', ''), resize_thread_limiter=False,
              exclude_episodes=completed_episodes)

    for params in single_tasks.values():
        t = threading.Thread(target=_resume_single, args=(params,))
        t.daemon = True
        t.start()
    for params in batch_tasks.values():
        t = threading.Thread(target=_resume_batch, args=(params,))
        t.daemon = True
        t.start()


def __download_only(sn, dl_resolution='', dl_save_dir='', realtime_show_file_size=False, classify=True, rename='',
                     cancel_check=None, defer_for_priority=False):
    # 僅下載,不操作數據庫
    # 回傳 True/False 代表這次呼叫最終是否成功, 供批次手動任務協調函式(_run_manual_batch_download())
    # 判斷該集是否要標記為失敗、供使用者於 Dashboard 上手動重試; 現有呼叫端(不使用回傳值)完全不受影響
    #
    # cancel_check: 無參數 callable, 回傳 True 代表使用者已終止這筆任務。還沒真的開始下載前偵測到會直接釋放
    #   並發名額並回傳 False, 不發送任何下載請求; 下載進行中(v25.2.2 起, 見 anime.cancel_check 的說明)也會
    #   在 ffmpeg 執行/分段下載等待期間定期偵測到, 中止該次下載(已經下載到一半的分段/檔案不強制清除,
    #   交給程式啟動時的殘留暫存檔清理機制處理), 而不是像過去那樣放著跑完才結束
    # defer_for_priority: True 時, 若 Config.scheduled_priority_active() 為真(代表有手動批次任務正在跑,
    #   同時排程檢查偵測到新更新, 正優先處理中), 會先釋放名額、等待後重新排隊, 讓排程下載有機會優先搶到並發名額,
    #   而不是讓手動任務長時間佔用名額卡住時效性較高的排程更新; 只在批次類手動任務使用, 其餘呼叫端維持預設 False
    #
    # 在真正取得並發號誌、解析 SN 資訊(可能因並發限制排隊、或 SN 解析冷卻 parse_sn_cd 耗時數秒)之前,
    # 先讓任務以暫定狀態出現在 Dashboard 任務監控列表, 讓使用者能立即看到提交已生效,
    # 避免誤以為按鈕沒反應而重複提交、產生重複任務; anime.download() 稍後會用實際標題/進度覆蓋這個暫定項目
    Config.tasks_progress_rate[int(sn)] = {'rate': 0, 'filename': 'sn=' + str(sn), 'status': '已提交, 排隊中'}
    thread_limiter.acquire()
    while True:
        if cancel_check and cancel_check():
            if int(sn) in Config.tasks_progress_rate.keys():
                del Config.tasks_progress_rate[int(sn)]
            thread_limiter.release()
            return False
        if defer_for_priority and Config.scheduled_priority_active():
            if int(sn) in Config.tasks_progress_rate.keys():
                Config.tasks_progress_rate[int(sn)]['status'] = '已暫停(排程下載優先處理中)'
            thread_limiter.release()
            time.sleep(1)
            thread_limiter.acquire()
            continue
        break
    if int(sn) in Config.tasks_progress_rate.keys():
        Config.tasks_progress_rate[int(sn)]['status'] = '準備中(SN解析冷卻)'
    err_counter = 0

    anime = build_anime(sn, manual=True)
    if anime['failed']:
        if int(sn) in Config.tasks_progress_rate.keys():
            del Config.tasks_progress_rate[int(sn)]
        thread_limiter.release()
        return False
    anime = anime['anime']
    anime.cancel_check = cancel_check  # 讓下載中(而不只是還沒開始下載)的階段也能偵測到終止請求, 見 Anime.py 的說明

    def force_stop(reason):
        # 遇到不該重試的致命錯誤 (例如非VIP強制停止、地區限制、sn不存在), 直接終止任務, 不進入重試流程
        err_print(sn, '終止任務', 'title=' + anime.get_title() + ' 遇到致命錯誤, 終止任務: ' + reason, status=1)
        thread_limiter.release()
        if int(sn) in Config.tasks_progress_rate.keys():
            del Config.tasks_progress_rate[int(sn)]
        Config.send_notification(
            'download_manual_failed', '消息',
            animation_name=anime.get_bangumi_name(),
            episode=anime.get_notify_episode_display(),
            fail_reason='致命錯誤: ' + reason,
            download_time=NotifyDB.now_str(),
            finish_time=NotifyDB.now_str(),
        )

    try:
        if dl_resolution:
            anime.download(dl_resolution, dl_save_dir, realtime_show_file_size=realtime_show_file_size, classify=classify, rename=rename)
        else:
            anime.download(settings['download_resolution'], dl_save_dir, realtime_show_file_size=realtime_show_file_size, classify=classify, rename=rename)
    except ForceStopError as e:
        force_stop(str(e))
        return False
    except BaseException as e:
        err_print(sn, '下載異常', '發生未知異常: ' + str(e), status=1)
        err_print(sn, '下載異常', '異常詳情:\n'+traceback.format_exc(), status=1, display=False)
        anime.video_size = 0

    while anime.video_size < 5:
        if cancel_check and cancel_check():
            thread_limiter.release()
            if int(sn) in Config.tasks_progress_rate.keys():
                del Config.tasks_progress_rate[int(sn)]
            return False
        if err_counter >= 3:
            err_print(sn, '終止任務', 'title=' + anime.get_title()+' 任務失敗達三次! 終止任務!', status=1)
            thread_limiter.release()
            if int(sn) in Config.tasks_progress_rate.keys():
                del Config.tasks_progress_rate[int(sn)]
            Config.send_notification(
                'download_manual_failed', '消息',
                animation_name=anime.get_bangumi_name(),
                episode=anime.get_notify_episode_display(),
                fail_reason='已重試三次',
                download_time=NotifyDB.now_str(),
                finish_time=NotifyDB.now_str(),
            )
            return False
        else:
            err_print(sn, '任務失敗', 'title=' + anime.get_title() + ' 10s後自動重啓,最多重試三次', status=1)
            err_counter = err_counter + 1
            if int(sn) in Config.tasks_progress_rate.keys():
                Config.tasks_progress_rate[int(sn)]['status'] = '失敗! 重啓中'
            time.sleep(10)

            try:
                anime.renew()
                if dl_resolution:
                    anime.download(dl_resolution, dl_save_dir, realtime_show_file_size=realtime_show_file_size, classify=classify, rename=rename)
                else:
                    anime.download(settings['download_resolution'], dl_save_dir, realtime_show_file_size=realtime_show_file_size, classify=classify, rename=rename)
            except ForceStopError as e:
                force_stop(str(e))
                return False
            except BaseException as e:
                err_print(sn, '下載異常', '發生未知異常: ' + str(e), status=1)
                err_print(sn, '下載異常', '異常詳情:\n'+traceback.format_exc(), status=1, display=False)
                anime.video_size = 0

    download_cd = threading.Thread(target=download_cd_counter)
    download_cd.start()
    return True


_MANUAL_BATCH_DONE_STATUS = '下載完成'
_MANUAL_BATCH_FAILED_STATUS = '失敗, 已放棄'
_MANUAL_BATCH_CANCELLED_STATUS = '已取消'
_MANUAL_BATCH_TERMINAL_STATUSES = (_MANUAL_BATCH_DONE_STATUS, _MANUAL_BATCH_FAILED_STATUS, _MANUAL_BATCH_CANCELLED_STATUS)


def _manual_batch_episode_worker(batch_sn, ep_sn, dl_resolution, dl_save_dir, realtime_show_file_size, classify, rename):
    # 手動批次任務(all/range)裡單一集數的下載執行緒: 呼叫 __download_only() 並用其回傳值決定這一集在
    # Config.manual_batch_progress 裡的最終狀態。失敗時特意標記清楚的狀態文字(而不是像過去那樣讓進度項目直接消失),
    # 讓 Dashboard 能顯示「這一集失敗了」並提供重試按鈕
    #
    # cancel_check 同時傳給 __download_only(): 讓「終止任務」能在這一集還沒真的開始下載前就擋下來;
    # defer_for_priority=True: 讓這一集在排程下載優先處理期間暫停啟動, 見 __download_only() 的說明
    def cancel_check():
        return Config.manual_batch_progress.get(str(batch_sn), {}).get('cancel', False)

    ok = __download_only(ep_sn, dl_resolution, dl_save_dir, realtime_show_file_size, classify, rename=rename,
                          cancel_check=cancel_check, defer_for_priority=True)
    if ok:
        # 記進批次任務暫存紀錄檔的 completed_episodes, 供意外中斷後重啟還原這筆批次任務時可以跳過這一集不重複下載
        Config.mark_manual_batch_episode_done(batch_sn, ep_sn)
    state = Config.manual_batch_progress.get(str(batch_sn))
    if state is None:
        return
    if ok:
        final_status = _MANUAL_BATCH_DONE_STATUS
    elif cancel_check():
        final_status = _MANUAL_BATCH_CANCELLED_STATUS
    else:
        final_status = _MANUAL_BATCH_FAILED_STATUS
    for task in state['tasks']:
        if task['ep_sn'] == ep_sn:
            task['status'] = final_status
            task['rate'] = 100 if ok else task.get('rate', 0)
            break


def _sync_manual_batch_progress_until_done(batch_sn):
    # 背景執行緒: 只要這個批次裡還有任一集數尚未到達終態(下載完成/失敗放棄), 就持續把
    # Config.tasks_progress_rate 的即時進度(狀態文字/百分比/檔名)同步進 Config.manual_batch_progress,
    # 供 Dashboard 顯示個別集數即時進度; 全部到達終態才把整體狀態設回 'done'
    #
    # 用「這個批次裡的集數狀態」而非「當初啟動的那幾條執行緒是否還活著」來判斷是否結束, 是刻意的設計:
    # 使用者可能在原本這批下載途中(還有其他集數在跑)就點了某一集的「重試」, 重試會另外啟動一輪新的下載執行緒
    # 與另一個背景同步執行緒。如果用「執行緒是否還活著」判斷, 先啟動的同步執行緒可能只看得到「自己啟動的那批」
    # 執行緒都結束了, 就誤把整個批次標記為 'done', 導致其他集數(包含正在重試中的那一集)明明還在下載,
    # 網頁卻已經停止輪詢、卡在「已完成」的舊畫面。改成檢查集數狀態後, 不論同一個批次先後啟動了幾輪重試,
    # 每一輪各自的同步執行緒都只會在「整個批次真的全部到達終態」時才會標記完成, 重複啟動也不會有副作用
    state = Config.manual_batch_progress.get(str(batch_sn))
    if state is None:
        return

    def _sync_once():
        for task in state['tasks']:
            if task['status'] in _MANUAL_BATCH_TERMINAL_STATUSES:
                continue
            live = Config.tasks_progress_rate.get(int(task['ep_sn']))
            if live:
                task['status'] = live['status']
                task['rate'] = live['rate']
                # __download_only() 一開始會先把 filename 設成 'sn=' + sn 佔位, 等 build_anime() 解析完才換成真正的
                # 標題/檔名; 排隊等待並發名額期間會一直是這個佔位字串, 這時候不要蓋掉上面已經填好的番劇名+集數顯示
                if live['filename'] != 'sn=' + str(task['ep_sn']):
                    task['filename'] = live['filename']
        finished = sum(1 for t in state['tasks'] if t['status'] in _MANUAL_BATCH_TERMINAL_STATUSES)
        state['total_progress'] = round(finished / len(state['tasks']) * 100) if state['tasks'] else 100

    def _still_pending():
        return any(t['status'] not in _MANUAL_BATCH_TERMINAL_STATUSES for t in state['tasks'])

    while _still_pending():
        _sync_once()
        time.sleep(1)
    _sync_once()  # 剛結束的最後一絲進度變化, 迴圈判斷條件已為 False 前可能還沒同步到, 收尾前再做最後一次
    state['status'] = 'done'


def _run_manual_batch_download(batch_sn, anime_name, episode_targets, dl_resolution, dl_save_dir,
                                realtime_show_file_size, classify, rename):
    # Dashboard「下載全部」/「掃描集數後指定範圍」手動任務的背景協調函式(取代過去單純各自獨立、重試3次就放棄且
    # 進度直接消失的做法): episode_targets 為 [(ep_sn, label), ...]。建立這批任務的進度紀錄、啟動每一集的下載執行緒,
    # 並在全部完成後移除批次類手動任務暫存紀錄檔(跟過去 _cleanup_batch_task_when_done() 語意相同)
    # 這個函式本身會阻塞直到全部下載完成, 呼叫端(見 __cui())需自行包一層背景執行緒, 才不會讓 __cui() 卡住
    # 下載參數存進 state, 讓稍後「重試失敗項目」(_retry_manual_batch_failed())只需要 batch_sn 就能重現同樣的下載設定
    # 排隊中還沒真的開始下載時, 用掃描集數時已經知道的番劇名+集數標籤顯示, 而不是單純的 sn 數字;
    # 真正開始下載後, filename 會被 _sync_manual_batch_progress_until_done() 換成 anime.download() 給的實際檔名
    Config.manual_batch_progress[str(batch_sn)] = {
        'anime_name': anime_name,
        'status': 'running',
        'cancel': False,
        'tasks': [{'ep_sn': ep_sn, 'label': label, 'status': '已排入, 排隊中', 'rate': 0,
                   'filename': ('《' + anime_name + '》第 ' + label + ' 集') if label else
                               ('《' + anime_name + '》sn=' + str(ep_sn))} for ep_sn, label in episode_targets],
        'total_progress': 0,
        '_dl_params': {'dl_resolution': dl_resolution, 'dl_save_dir': dl_save_dir,
                       'realtime_show_file_size': realtime_show_file_size, 'classify': classify, 'rename': rename},
    }
    for ep_sn, _label in episode_targets:
        t = threading.Thread(target=_manual_batch_episode_worker,
                              args=(batch_sn, ep_sn, dl_resolution, dl_save_dir, realtime_show_file_size, classify, rename))
        t.daemon = True
        thread_tasks.append(t)
        t.start()
    _sync_manual_batch_progress_until_done(batch_sn)
    Config.remove_manual_batch_task(batch_sn)


def _retry_manual_batch_failed(batch_sn, ep_sn=None):
    # Dashboard 集數重試按鈕(只在該集重試3次後最終放棄時才會出現): 針對目前狀態為失敗的集數重新給一次全新的
    # 下載嘗試(內部一樣是 __download_only() 既有的3次重試邏輯), 不影響已成功或仍在下載中的集數。
    # ep_sn 指定時只重試那一集, 不指定則重試這個批次裡目前所有失敗的集數。非阻塞, 立即回傳是否有找到失敗項目可供重試
    state = Config.manual_batch_progress.get(str(batch_sn))
    if state is None:
        return False
    failed_tasks = [t for t in state['tasks'] if t['status'] == _MANUAL_BATCH_FAILED_STATUS]
    if ep_sn is not None:
        failed_tasks = [t for t in failed_tasks if t['ep_sn'] == ep_sn]
    if not failed_tasks:
        return False
    dl_params = state['_dl_params']
    for task in failed_tasks:
        task['status'] = '已排入, 排隊中'
        task['rate'] = 0
    state['status'] = 'running'
    state['cancel'] = False  # 重試代表使用者想繼續這個批次, 若之前終止過, 這裡一併解除, 否則新開的下載會被 cancel_check 立刻擋下
    for task in failed_tasks:
        t = threading.Thread(target=_manual_batch_episode_worker,
                              args=(batch_sn, task['ep_sn'], dl_params['dl_resolution'], dl_params['dl_save_dir'],
                                    dl_params['realtime_show_file_size'], dl_params['classify'], dl_params['rename']))
        t.daemon = True
        thread_tasks.append(t)
        t.start()
    # 不論這個批次原本的同步執行緒是否還在跑(還有其他集數在下載中), 都直接再啟動一個新的同步執行緒:
    # _sync_manual_batch_progress_until_done() 是用「集數狀態」而非執行緒是否存活判斷是否結束, 多啟動一個
    # 同時跑並不會有副作用(頂多重複輪詢), 但可以確保重試的這一集一定有人在追蹤, 不會卡在舊的完成畫面
    sync_thread = threading.Thread(target=_sync_manual_batch_progress_until_done, args=(batch_sn,))
    sync_thread.daemon = True
    sync_thread.start()
    return True


def _cancel_manual_batch(batch_sn):
    # Dashboard「終止任務」: 還沒真的開始下載的集數(見 __download_only() 的 cancel_check)不會再啟動;
    # 已經在下載中的集數(v25.2.2 起, 見 Anime.py 的 cancel_check 說明)也會在 ffmpeg 執行/分段下載等待期間
    # 定期偵測到並中止, 不再像過去那樣放著跑完。不論是還沒開始就被擋下、還是下載到一半被中止,
    # __download_only() 迴圈裡的 cancel_check() 判斷都會先於重試邏輯攔截, 所以兩種情況在
    # _manual_batch_episode_worker() 裡最終都會正確標記為「已取消」, 不會被誤判成真的下載失敗
    # 回傳這個批次任務是否存在且可以終止
    state = Config.manual_batch_progress.get(str(batch_sn))
    if state is None:
        return False
    state['cancel'] = True
    return True


def _sync_manual_single_progress(sn):
    # 背景執行緒: __download_only() 是阻塞呼叫, 執行期間沒有機會自己回頭更新 Config.manual_single_progress,
    # 這裡比照批次任務的 _sync_manual_batch_progress_until_done(), 從 Config.tasks_progress_rate 持續複製
    # 即時進度(百分比/檔名)過去, 直到狀態不再是 'running'(_run_manual_single_download() 設定終態後)才結束
    key = str(sn)
    while True:
        state = Config.manual_single_progress.get(key)
        if state is None or state['status'] != 'running':
            return
        live = Config.tasks_progress_rate.get(state['ep_sn'])
        if live:
            state['rate'] = live['rate']
            if live['filename'] != 'sn=' + str(state['ep_sn']):
                state['filename'] = live['filename']
        time.sleep(1)


def _run_manual_single_download(sn, target_ep_sn, dl_resolution, dl_save_dir, realtime_show_file_size, classify, rename):
    # Dashboard 單集類手動任務(single/latest/largest-sn)的進度追蹤包裝, 只在 __cui() 的 track_progress=True
    # (由 Dashboard 提交時指定, CLI 不受影響)時才會被呼叫。過去這幾種模式直接呼叫 __download_only(), 阻塞
    # 直到下載終結(成功或重試3次後放棄)才回傳, 過程中/結束後 Config.tasks_progress_rate 的暫存項目終態時
    # 會被刪掉, Dashboard 完全看不到最終結果、失敗了也沒有重試入口, 只能憑送出當下的「已提交」提示自行猜測。
    # 這裡額外維護一份「終態也保留」的進度紀錄(比照 manual_batch_progress), 讓 Dashboard 能顯示進度條,
    # 下載完成/失敗都有明確結果, 失敗時可按重試——重試沿用同一個 target_ep_sn, 不重新解析 latest/largest-sn
    # (避免重試時因為番劇又更新了一集而悄悄改成重試到不同的集數, 跟使用者原本按下重試想重來的那一集對不上)
    #
    # sn: 使用者提交當下輸入的 sn(進度紀錄的 key, 見 Config.manual_single_progress 開頭的說明), 可能是字串
    # (Dashboard 表單直接從網址擷取, 未轉型)也可能是數字(latest/largest-sn 模式由 __cui() 解析網頁算出);
    # target_ep_sn 統一轉成 int, 這裡要拿它去查 Config.tasks_progress_rate(見 __download_only() 一律用
    # int(sn) 當 key), 型別對不上會導致 _sync_manual_single_progress() 永遠讀不到即時進度
    target_ep_sn = int(target_ep_sn)
    key = str(sn)
    fallback_name = 'sn=' + str(target_ep_sn)
    Config.manual_single_progress[key] = {
        'anime_name': fallback_name, 'filename': fallback_name, 'status': 'running', 'rate': 0, 'cancel': False,
        'ep_sn': target_ep_sn,
        '_dl_params': {'dl_resolution': dl_resolution, 'dl_save_dir': dl_save_dir,
                       'realtime_show_file_size': realtime_show_file_size, 'classify': classify, 'rename': rename},
    }

    def cancel_check():
        return Config.manual_single_progress.get(key, {}).get('cancel', False)

    sync_thread = threading.Thread(target=_sync_manual_single_progress, args=(sn,))
    sync_thread.daemon = True
    sync_thread.start()

    ok = __download_only(target_ep_sn, dl_resolution, dl_save_dir, realtime_show_file_size=realtime_show_file_size,
                          classify=classify, rename=rename, cancel_check=cancel_check)
    state = Config.manual_single_progress.get(key)
    if state is None:
        return
    if ok:
        state['status'] = 'done'
        state['rate'] = 100
    elif cancel_check():
        state['status'] = 'cancelled'
    else:
        state['status'] = 'failed'


def _retry_manual_single(sn):
    # Dashboard 單集任務失敗後的重試按鈕: 針對同一個 target_ep_sn 重新給一次全新的下載嘗試(內部一樣是
    # __download_only() 既有的3次重試邏輯)。非阻塞, 立即回傳是否有找到失敗紀錄可供重試
    key = str(sn)
    state = Config.manual_single_progress.get(key)
    if state is None or state['status'] != 'failed':
        return False
    dl_params = state['_dl_params']
    t = threading.Thread(target=_run_manual_single_download,
                          args=(sn, state['ep_sn'], dl_params['dl_resolution'], dl_params['dl_save_dir'],
                                dl_params['realtime_show_file_size'], dl_params['classify'], dl_params['rename']))
    t.daemon = True
    t.start()
    return True


def _cancel_manual_single(sn):
    # Dashboard「終止任務」: 跟批次任務的 _cancel_manual_batch() 語意相同, 見該函式的說明——不論這一集
    # 還沒開始下載或已經在下載中, 都會被 __download_only() 的 cancel_check 攔截並正確標記為「已取消」
    # (v25.2.2 起連下載中也能真的中止, 不再像過去那樣放著跑完)。回傳這個任務是否存在且可以終止
    state = Config.manual_single_progress.get(str(sn))
    if state is None:
        return False
    state['cancel'] = True
    return True


def __get_info_only(sn):
    thread_limiter.acquire()

    anime = build_anime(sn)
    if anime['failed']:
        sys.exit(1)
    anime = anime['anime']
    anime.set_resolution(resolution)
    anime.get_info()
    download_dir = settings['bangumi_dir']
    if classify:  # 控制是否建立番劇文件夾
        download_dir = os.path.join(download_dir, Config.legalize_filename(anime.get_bangumi_name()))

    if danmu:
        if os.path.exists(download_dir):
            full_filename = os.path.join(download_dir, anime.get_filename()).replace('.' + settings['video_filename_extension'], '.ass')
            d = Danmu(sn, full_filename, Config.read_cookie())
            d.download(settings['danmu_ban_words'])
        else:
            err_print(sn, '彈幕下載異常', '番劇資料夾不存在: ' + download_dir, status=1)

    thread_limiter.release()


def __get_danmu_only(sn, bangumi_name, video_path):
    thread_limiter.acquire()

    download_dir = settings['bangumi_dir']
    if classify:  # 控制是否建立番劇文件夾
        download_dir = os.path.join(download_dir, Config.legalize_filename(bangumi_name))

    if os.path.exists(download_dir):
        d = Danmu(sn, video_path.replace('.' + settings['video_filename_extension'], '.ass'), Config.read_cookie())
        d.download(settings['danmu_ban_words'])
    else:
        err_print(sn, '彈幕下載異常', '番劇資料夾不存在: ' + download_dir, status=1)

    thread_limiter.release()


def __cui(sn, cui_resolution, cui_download_mode, cui_thread_limit, ep_range,
          cui_save_dir='', classify=True, get_info=False, user_cmd=False, realtime_show=True, cui_danmu=False,
          bilingual=True, rename='', resize_thread_limiter=True, exclude_episodes=None, track_progress=False):
    # exclude_episodes: all/range 批次下載模式下, 要跳過不下載的集數 sn 集合。目前只有 _resume_pending_manual_tasks()
    # 還原意外中斷的批次任務時會用到, 傳入該批次任務已經記錄下載成功的 completed_episodes, 避免重新下載一次;
    # 一般正常提交(Dashboard/CLI)不會有已完成的集數可排除, 維持預設值 None 即可
    #
    # track_progress: 只有 Dashboard 提交 single/latest/largest-sn 這三種單集類手動任務時才會傳入 True
    # (見 Dashboard/Server.py 的 /manualTask 路由), CLI 呼叫維持預設 False, 行為完全不變。為 True 時,
    # 下方單集下載改呼叫 _run_manual_single_download() 而不是直接呼叫 __download_only(), 讓 Dashboard
    # 能追蹤進度並在失敗時提供重試, 詳見該函式開頭的說明
    exclude_episodes = exclude_episodes or set()

    def _download_single(target_ep_sn):
        if track_progress:
            _run_manual_single_download(sn, target_ep_sn, cui_resolution, cui_save_dir,
                                         realtime_show_file_size=realtime_show_file_size, classify=classify, rename=rename)
        else:
            __download_only(target_ep_sn, cui_resolution, cui_save_dir,
                             realtime_show_file_size=realtime_show_file_size, classify=classify, rename=rename)
    def _filter_bilingual(episode_dict):
        # bilingual 為 False 時, 排除 SN 解析中出現的其他語言版本
        # 例如「中文配音12」(一般劇集的中文配音版) 或「中文電影1」(電影的中文配音版) 這類雙語/配音版劇集
        if bilingual:
            return episode_dict
        return {ep: ep_sn for ep, ep_sn in episode_dict.items() if not ep.startswith('中文')}
    # resize_thread_limiter=False: Dashboard 手動任務/還原任務執行時, Web 控制台與排程自動下載共用同一個持續執行的程序,
    # 若在這裡用使用者於手動任務表單挑選的執行緒數重建全域 thread_limiter, 會使正在進行中的排程下載執行緒
    # 手上持有的號誌物件與新號誌物件失去關聯(併發數統計失真), 且新號誌的容量可能高於設定檔的「最大並發下載數」,
    # 讓手動任務完全不受「下載冷卻時間(秒)」與「最大並發下載數」限制。只有獨立的命令列一次性執行(CLI模式,
    # 執行完就結束程序, 不會有其他背景任務共用這個號誌)才適合在此重建
    global thread_limiter
    if resize_thread_limiter:
        thread_limiter = threading.Semaphore(cui_thread_limit)

    global danmu
    danmu = cui_danmu

    if realtime_show:
        if cui_thread_limit == 1 or cui_download_mode in ('single', 'latest', 'largest-sn'):
            realtime_show_file_size = True
        else:
            realtime_show_file_size = False
    else:
        realtime_show_file_size = False

    if cui_download_mode == 'single':
        if get_info:
            print('當前模式: 查詢本集資訊\n')
        else:
            print('當前下載模式: 僅下載本集\n')

        if get_info:
            __get_info_only(sn)
        else:
            _download_single(sn)

    elif cui_download_mode == 'latest' or cui_download_mode == 'largest-sn':
        if cui_download_mode == 'latest':
            if get_info:
                print('當前模式: 查詢本番劇最後一集資訊\n')
            else:
                print('當前下載模式: 下載本番劇最後一集\n')
        else:
            if get_info:
                print('當前模式: 查詢本番劇最近上傳一集資訊\n')
            else:
                print('當前下載模式: 下載本番劇最近上傳的一集\n')

        anime = build_anime(sn)
        if anime['failed']:
            sys.exit(1)
        anime = anime['anime']

        bangumi_list = list(_filter_bilingual(anime.get_episode_list()).values())

        if cui_download_mode == 'largest-sn':
            bangumi_list.sort()

        if get_info:
            __get_info_only(bangumi_list[-1])
        else:
            _download_single(bangumi_list[-1])

    elif cui_download_mode == 'all':
        if get_info:
            print('當前模式: 查詢本番劇所有劇集資訊\n')
        else:
            print('當前下載模式: 下載本番劇所有劇集\n')

        anime = build_anime(sn)
        if anime['failed']:
            if not get_info:
                Config.remove_manual_batch_task(sn)
            sys.exit(1)
        anime = anime['anime']

        episode_dict = _filter_bilingual(anime.get_episode_list())  # {label: ep_sn}
        label_by_sn = {ep_sn: label for label, ep_sn in episode_dict.items()}
        bangumi_list = sorted(episode_dict.values())

        if get_info:
            tasks_counter = 0  # 任務計數器
            for anime_sn in bangumi_list:
                task = threading.Thread(target=__get_info_only, args=(anime_sn,))
                task.daemon = True
                thread_tasks.append(task)
                task.start()
                tasks_counter = tasks_counter + 1
                print('添加任務列隊: sn=' + str(anime_sn))
            print('所有查詢任務已添加至列隊, 共 '+str(tasks_counter)+' 個任務\n')
        else:
            # 改用 _run_manual_batch_download() 統一協調這批集數的下載, 讓 Dashboard 能顯示個別集數進度、
            # 失敗的集數清楚標示狀態並可手動重試(取代過去單純各自獨立展開執行緒、失敗3次就悄悄消失的做法)
            # exclude_episodes: 還原意外中斷的批次任務時, 跳過已經記錄下載成功的集數不重複下載
            download_list = [ep_sn for ep_sn in bangumi_list if ep_sn not in exclude_episodes]
            skipped_count = len(bangumi_list) - len(download_list)
            if download_list:
                episode_targets = [(ep_sn, label_by_sn.get(ep_sn, '')) for ep_sn in download_list]
                batch_thread = threading.Thread(target=_run_manual_batch_download,
                                                 args=(sn, anime.get_bangumi_name(), episode_targets, cui_resolution,
                                                       cui_save_dir, realtime_show_file_size, classify, rename))
                batch_thread.daemon = True
                thread_tasks.append(batch_thread)
                batch_thread.start()
            else:
                Config.remove_manual_batch_task(sn)
            skipped_msg = ('(已跳過 ' + str(skipped_count) + ' 個先前已下載成功的集數)') if skipped_count else ''
            print('所有下載任務已添加至列隊, 共 '+str(len(download_list))+' 個任務'+skipped_msg+', '+'執行緒數: ' + str(cui_thread_limit) + '\n')

    elif cui_download_mode == 'range':
        if get_info:
            print('當前模式: 查詢本番劇指定劇集資訊\n')
        else:
            print('當前下載模式: 下載本番劇指定劇集\n')

        anime = build_anime(sn)
        if anime['failed']:
            if not get_info:
                Config.remove_manual_batch_task(sn)
            sys.exit(1)
        anime = anime['anime']

        episode_dict = anime.get_episode_list()
        bangumi_ep_list = list(episode_dict.keys())  # 本番劇集列表

        if get_info:
            tasks_counter = 0  # 任務計數器
            for ep in ep_range:
                if ep in bangumi_ep_list:
                    a = threading.Thread(target=__get_info_only, args=(episode_dict[ep],))
                    a.daemon = True
                    thread_tasks.append(a)
                    a.start()
                    tasks_counter = tasks_counter + 1
                    print('添加查詢列隊: sn=' + str(episode_dict[ep]) + ' 《' + anime.get_bangumi_name() + '》 第 ' + ep + ' 集')
                else:
                    err_print(0, '《'+anime.get_bangumi_name()+'》 第 '+ep+' 集不存在!', status=1, no_sn=True)
            print('所有任務已添加至列隊, 共 '+str(tasks_counter)+' 個任務, '+'執行緒數: ' + str(cui_thread_limit) + '\n')
        else:
            # 改用 _run_manual_batch_download() 統一協調這批集數的下載, 讓 Dashboard 能顯示個別集數進度、
            # 失敗的集數清楚標示狀態並可手動重試(取代過去單純各自獨立展開執行緒、失敗3次就悄悄消失的做法)
            # exclude_episodes: 還原意外中斷的批次任務時, 跳過已經記錄下載成功的集數不重複下載
            episode_targets = []
            skipped_count = 0
            for ep in ep_range:
                if ep in bangumi_ep_list:
                    if episode_dict[ep] in exclude_episodes:
                        skipped_count += 1
                        continue
                    episode_targets.append((episode_dict[ep], ep))
                    print('添加任務列隊: sn='+str(episode_dict[ep])+' 《'+anime.get_bangumi_name()+'》 第 '+ep+' 集')
                else:
                    err_print(0, '《'+anime.get_bangumi_name()+'》 第 '+ep+' 集不存在!', status=1, no_sn=True)
            if episode_targets:
                batch_thread = threading.Thread(target=_run_manual_batch_download,
                                                 args=(sn, anime.get_bangumi_name(), episode_targets, cui_resolution,
                                                       cui_save_dir, realtime_show_file_size, classify, rename))
                batch_thread.daemon = True
                thread_tasks.append(batch_thread)
                batch_thread.start()
            else:
                Config.remove_manual_batch_task(sn)
            skipped_msg = ('(已跳過 ' + str(skipped_count) + ' 個先前已下載成功的集數)') if skipped_count else ''
            print('所有任務已添加至列隊, 共 '+str(len(episode_targets))+' 個任務'+skipped_msg+', '+'執行緒數: ' + str(cui_thread_limit) + '\n')

    elif cui_download_mode == 'sn-range':
        if get_info:
            print('當前模式: 查詢本番劇指定sn範圍資訊\n')
        else:
            print('當前下載模式: 下載本番劇指定sn範圍劇集\n')

        anime = build_anime(sn)
        if anime['failed']:
            sys.exit(1)
        anime = anime['anime']

        # 劇集列表 key value 互換, {'sn', '劇集名'}
        episode_dict = {value:key for key,value in anime.get_episode_list().items()}
        ep_sn_list = list(episode_dict.keys())  # 本番劇集sn列表
        tasks_counter = 0  # 任務計數器
        ep_range = list(map(lambda x: int(x), ep_range))
        for sn in ep_sn_list:
            if sn in ep_range:
                # 如果該 sn 在用戶指定的 sn 範圍裏
                if get_info:
                    a = threading.Thread(target=__get_info_only, args=(sn,))
                else:
                    a = threading.Thread(target=__download_only, args=(sn, cui_resolution, cui_save_dir, realtime_show_file_size))
                a.daemon = True
                thread_tasks.append(a)
                a.start()
                tasks_counter = tasks_counter + 1
                if get_info:
                    print('添加查詢列隊: sn=' + str(sn) + ' 《' + anime.get_bangumi_name() + '》 第 ' + episode_dict[sn] + ' 集')
                else:
                    print('添加任務列隊: sn='+str(sn)+' 《'+anime.get_bangumi_name()+'》 第 ' + episode_dict[sn] + ' 集')
        print('所有任務已添加至列隊, 共 ' + str(tasks_counter) + ' 個任務, ' + '執行緒數: ' + str(cui_thread_limit) + '\n')

    elif cui_download_mode == 'multi':
        if get_info:
            print('當前模式: 查詢指定sn資訊\n')
        else:
            print('當前下載模式: 下載指定sn劇集\n')

        tasks_counter = 0
        for sn in ep_range:
            if get_info:
                a = threading.Thread(target=__get_info_only, args=(sn,))
            else:
                a = threading.Thread(target=__download_only,args=(sn, cui_resolution, cui_save_dir, realtime_show_file_size))
            a.daemon = True
            thread_tasks.append(a)
            a.start()
            tasks_counter = tasks_counter + 1

        print('所有任務已添加至列隊, 共 ' + str(tasks_counter) + ' 個任務, ' + '執行緒數: ' + str(cui_thread_limit) + '\n')

    elif cui_download_mode in ('list', 'sn-list'):
        if get_info:
            # 如果為list模式也僅查詢名單中的sn信息, 可用於檢查sn是否輸入正確
            print('當前模式: 查詢sn_list.txt中指定sn的資訊\n')
            ep_range = Config.read_sn_list().keys()
            for sn in ep_range:
                anime = build_anime(sn)
                if anime['failed']:
                    sys.exit(1)
                anime = anime['anime']
                anime.get_info()
        else:
            if cui_download_mode == 'sn-list':
                print('當前下載模式: 下載sn_list.txt中指定的sn劇集\n')
                for i in sn_dict:
                    sn_dict[i]['mode'] = 'single'
            else:
                print('當前下載模式: 單次下載sn_list.txt中的番劇\n')

            check_tasks()  # 檢查更新，生成任務列隊
            for sn in queue.keys():  # 遍歷任務列隊
                processing_queue.append(sn)
                task = threading.Thread(target=worker, args=(sn, queue[sn], realtime_show_file_size))
                task.daemon = True
                thread_tasks.append(task)
                task.start()
                err_print(sn, '加入任務列隊')
            msg = '共 ' + str(len(queue)) + ' 個任務'
            err_print(0, '任務資訊', msg, no_sn=True)
            print()

    elif cui_download_mode == 'danmu':
        tasks_counter = 0
        for anime_db in ep_range:
            if anime_db["status"] == 1:
                if anime_db["anime_name"] is not None \
                and anime_db["local_file_path"] is not None :
                    a = threading.Thread(target=__get_danmu_only,args=(anime_db["sn"], anime_db["anime_name"], anime_db["local_file_path"]))
                    a.daemon = True
                    thread_tasks.append(a)
                    a.start()
                    tasks_counter = tasks_counter + 1
                else:
                    err_print(anime_db["sn"], '彈幕更新失敗', "資料庫不存在番劇名稱或影片路徑", status=1)

        print('所有任務已添加至列隊, 共 ' + str(tasks_counter) + ' 個任務, ' + '執行緒數: ' + str(cui_thread_limit) + '\n')

    __kill_thread_when_ctrl_c()
    kill_gost()  # 結束 gost

    # 結束後執行用戶自定義命令
    if user_cmd:
        print()
        # 用 with 包住並讀取輸出: os.popen() 只是開了一個管道立刻回傳, 不會等指令真的執行完就繼續往下印
        # 「已執行用戶命令」, 且指令本身的輸出/錯誤訊息完全沒有被記錄下來; read() 會等到指令執行完(EOF)
        # 才回傳, close() 則能取得非 0 的結束狀態, 藉此把使用者自訂命令的執行結果一併記錄進 log
        with os.popen(settings['user_command']) as user_cmd_pipe:
            user_cmd_output = user_cmd_pipe.read().strip()
        err_print(0, '任務完成', '已執行用戶命令' + (': ' + user_cmd_output if user_cmd_output else ''),
                  no_sn=True, status=2)

    sys.exit(0)


def __kill_thread_when_ctrl_c():
    # 等待所有任務完成
    for t in thread_tasks:  # 當用戶 Ctrl+C 可以 kill 線程
        while True:
            if t.is_alive():
                time.sleep(1)
            else:
                break


def kill_gost():
    if gost_subprocess is not None:
        gost_subprocess.kill()  # 結束 gost


def user_exit(signum, frame):
    err_print(0, '你終止了程序!', '\n', status=1, no_sn=True, prefix='\n\n')
    kill_gost()  # 結束 gost
    sys.exit(255)


def _thread_exception_hook(args):
    # 統一攔截所有背景執行緒中未被捕捉的例外, 避免直接印出原始英文 Python Traceback
    if issubclass(args.exc_type, SystemExit):
        return  # sys.exit() 屬於正常流程, 不視為異常
    thread_name = args.thread.name if args.thread else '未知執行緒'
    err_detail = ''.join(traceback.format_exception(args.exc_type, args.exc_value, args.exc_traceback))
    err_print(0, '未預期錯誤', f'背景執行緒 [{thread_name}] 發生未捕捉的例外: {args.exc_value}', status=1, no_sn=True)
    err_print(0, '未預期錯誤', '異常詳情:\n' + err_detail, status=1, no_sn=True, display=False)


def _version_epoch(major):
    # v25.1.9 之後預計會有一個世代轉換: 從 aniGamerPlus vNN.N.N(目前, 主版號接近年份, 例如 v25.1.8)
    # 改名重新編號成 aniGamerPlusBeta vN.N.N(例如 v1.0.0)。單純數字比較會把 v1.0.0 誤判成比 v25.1.8 舊(倒退),
    # 用主版號門檻區分世代, 世代新的一律視為比較新——等舊世代版號徹底沒人在用之後, 這個函式可以整個拿掉
    return 0 if major >= 20 else 1


def _parse_version(version_str):
    # 將 'v24.6.1' 這類版本號拆成 (世代, 24, 6, 1) 以利逐段比較, 避免版本號有兩個以上小數點時 float() 直接崩潰
    parts = tuple(int(x) for x in version_str.strip().lstrip('vV').split('.'))
    return (_version_epoch(parts[0]),) + parts


def check_new_version():
    # 檢查 GitHub 上是否有新版(正式版與預告版分開比對), 結果寫進 Config.update_check_state 供 Dashboard
    # 的 /data/update_check/status 顯示; 主控台輸出與 Telegram/Discord 通知只在「這個 tag 還沒通知過」時
    # 送出一次, 讓 _version_check_worker() 的定期檢查不會每 10 分鐘洗一次版
    #
    # 這裡刻意重新讀一次設定(而不是沿用模組層級啟動時就讀好的 settings), 讓「檢查最新版本」/「檢查預告版本」
    # 開關即時生效, 不必重啟程式
    current_settings = Config.read_settings()
    releases = Config.read_github_releases()
    state = Config.update_check_state
    try:
        current = _parse_version(current_settings['aniGamerPlus_version'])
        release = releases['release']
        prerelease = releases['prerelease'] if current_settings.get('check_prerelease_version', True) else None
        release_newer = release is not None and current < _parse_version(release['tag_name'])
        prerelease_newer = prerelease is not None and current < _parse_version(prerelease['tag_name'])
        target = None
        if prerelease_newer and (not release_newer or _parse_version(prerelease['tag_name']) >= _parse_version(release['tag_name'])):
            target = prerelease
        elif release_newer:
            target = release
    except (ValueError, AttributeError, KeyError, TypeError) as e:
        err_print(0, '檢查更新', '版本號格式無法解析, 跳過本次更新檢查: ' + str(e), status=1, no_sn=True, display=False)
        return

    state['checked_at'] = NotifyDB.now_str()
    if target is None:
        state.update({'update_available': False, 'is_prerelease': False, 'tag_name': '', 'body': '',
                      'body_html': '', 'body_hash': '', 'html_url': ''})
        return

    # target['body'] 是 GitHub release notes 原始的 GitHub-flavored-Markdown 文字, 標題/粗體/表格/<details>
    # 摺疊區塊等語法符號在 CMD 主控台/Telegram/Discord 純文字通知裡都不會真的被渲染, 只會照樣印出語法符號
    # 本身、比原始文字更難讀, 這裡統一轉成乾淨的純文字再輸出; Dashboard 彈窗則改用 body_html(見下方),
    # 保留 <details> 讓每個項目可以摺疊顯示, 而不是像純文字版一樣整段拉平
    version_body_plain = markdown_to_plain_text(target['body'])
    version_body_html = markdown_release_notes_to_html(target['body'])
    # 用原始 body 內容算雜湊, 供 Dashboard 判斷「使用者略過此版本通知」之後, GitHub 上的內容如果又被編輯過
    # (常見於預告版本: 邊寫邊補內容), 要不要視為新內容重新彈出, 而不是只認 tag_name 沒變就永遠不再提醒
    version_body_hash = hashlib.sha1(target['body'].encode('utf-8')).hexdigest()
    state.update({'update_available': True, 'is_prerelease': target['prerelease'], 'tag_name': target['tag_name'],
                  'body': version_body_plain, 'body_html': version_body_html, 'body_hash': version_body_hash,
                  'html_url': target['html_url']})
    if state.get('notified_tag') == target['tag_name']:
        return  # 這個 tag 上次檢查已經通知過, 避免每 10 分鐘定期檢查就重複發送
    state['notified_tag'] = target['tag_name']
    label = '新版本預告' if target['prerelease'] else '新版本'
    err_print(0, '發現GitHub上有' + label + ': ' + target['tag_name'] + '\n更新內容:\n' + version_body_plain + '\n',
              status=1, no_sn=True)
    Config.send_new_version_notification(target['prerelease'], target['tag_name'], version_body_plain)


_COOKIE_WARM_UP_INTERVAL = 1800  # 30 分鐘: 目前沒有動畫瘋登入 session 實際存活時間的準確數字(觀察到
                                  # 閒置 3~4.5 小時後就已經失效), 30 分鐘是在「不要太頻繁打擾伺服器」跟
                                  # 「盡量在閒置視窗內趕上真正的過期時間點」之間取的折衷值


def _cookie_warm_up_worker():
    # 背景執行緒: 每 _COOKIE_WARM_UP_INTERVAL 秒模擬一次瀏覽動線(見 Anime.warm_up_cookie_session()), 幫登入
    # cookie 保溫, 避免長時間沒有下載/排程檢查時 BAHARUNE 因閒置過久被動畫瘋判定過期。只在「沒有下載正在
    # 進行中、也沒有工作排入隊列」時才真的發出請求, 避免這裡的額外請求跟真正的下載/排程檢查搶用併發名額
    while True:
        time.sleep(_COOKIE_WARM_UP_INTERVAL)
        try:
            if queue or processing_queue:
                continue  # 有工作排隊或正在下載中, 這次跳過, 下個週期再檢查
            warm_up_cookie_session()
        except BaseException as e:
            err_print(0, 'Cookie保溫背景執行緒發生未知錯誤: ' + str(e), status=1, no_sn=True)


_VERSION_CHECK_INTERVAL = 600  # 10 分鐘


def _version_check_worker():
    # 背景執行緒: 每 10 分鐘重新檢查一次 GitHub 上是否有新版本(啟動時那次檢查之外的定期檢查), 沿用
    # _scheduled_check_worker() 的常駐迴圈 + sleep 慣例; check_new_version() 自己每次都會重新讀取設定,
    # 所以「檢查最新版本」開關即時生效不需要重啟程式
    while True:
        time.sleep(_VERSION_CHECK_INTERVAL)
        try:
            if not Config.read_settings().get('check_latest_version'):
                continue
            check_new_version()
        except BaseException as e:
            err_print(0, '檢查更新', '定期檢查更新時發生錯誤: ' + str(e), status=1, no_sn=True, display=False)


def __init_proxy():
    if settings['use_gost']:
        print('使用代理連接動畫瘋, 使用擴展的代理協議')
        # 需要使用 gost 的情況
        # 尋找 gost
        check_gost = subprocess.Popen('gost -h', shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if check_gost.stderr.readlines():  # 查找 gost 是否已放入系統 path
            gost_path = 'gost'
        else:
            # print('沒有在系統PATH中發現gost，嘗試在所在目錄尋找')
            if 'Windows' in platform.system():
                gost_path = os.path.join(working_dir, 'gost.exe')
            else:
                gost_path = os.path.join(working_dir, 'gost')
            if not os.path.exists(gost_path):
                err_print(0, '當前代理使用擴展協議, 需要使用gost, 但是gost未找到', status=1, no_sn=True)
                raise FileNotFoundError  # 如果本地目錄下也沒有找到 gost 則丟出異常
        # 構造 gost 命令
        gost_cmd = [gost_path, '-L=:'+str(gost_port), '-F=' + settings['proxy']]  # 本地監聽端口 34173

        def run_gost():
            # gost 線程
            global gost_subprocess
            gost_subprocess = subprocess.Popen(gost_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            gost_subprocess.communicate()

        run_gost_threader = threading.Thread(target=run_gost)
        run_gost_threader.daemon = True
        run_gost_threader.start()  # 啓動 gost
        time.sleep(3)  # 給時間讓 gost 啓動

    else:
        print('使用代理連接動畫瘋, 使用http/https/socks5協議')


def do_request(url, headers, cookies, params=None):
    return requests.get(url, headers=headers, cookies=cookies, params=params)


def parse_anime(soup, animes, headers, cookies):
    if soup.text.find("目前沒有訂閱內容") != -1:
        return False
    for animeInfo in soup.select_one(".theme-list-block").select("a"):
        response = do_request(f"https://ani.gamer.com.tw/{animeInfo['href']}", headers, cookies)
        sn = response.url.split("=")[-1]
        name = animeInfo.select_one(".theme-name").text
        animes.append({"sn": sn, "name": name})
    return True


def export_my_anime():
    from bs4 import BeautifulSoup

    url = "https://ani.gamer.com.tw/mygather.php"
    header = {
        'accept':
        'application/json',
        'origin':
        'https://ani.gamer.com.tw',
        'authority':
        'ani.gamer.com.tw',
        'user-agent':
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.83 Safari/537.36',
    }

    cookies = Config.read_cookie()
    if not cookies:
        err_print(0, "請先設定cookie後再執行此指令", status=1, no_sn=True)
        return

    page = 1
    animes = []
    while True:
        params = {'page': page, 'sort': 0}
        bahamygatherPage = do_request(url, headers=header, cookies=cookies, params=params)
        if bahamygatherPage.status_code == requests.codes.ok:
            soup = BeautifulSoup(bahamygatherPage.text, 'html.parser')
            if not parse_anime(soup, animes, header, cookies):
                break
        else:
            err_print(0, f"匯入我的動畫失敗，狀態碼{bahamygatherPage.status_code}", status=1, no_sn=True)
        page += 1

    with open("my_anime.txt", "w", encoding="utf-8") as f:
        for anime in animes:
            f.write(f"{anime['sn']} all <{anime['name']}>\n")


def run_dashboard():
    # 檢測端口是否佔用: 若使用者手動快速關閉又重啟程式, 舊程序可能還沒真正釋放連接埠, 新程序就已經檢查到這裡。
    # 若只檢查一次就放棄, 之後終其整個程序生命週期都不會再重試, Dashboard 從此再也起不來(表現為網頁一直連線被拒)。
    # 改成短暫重試最多 10 秒, 只要舊程序在這段時間內確實釋放了連接埠就能正常接手, 真的長期被佔用才視為啟動失敗
    port = settings['dashboard']['port']
    wait_deadline = time.time() + 10
    while not port_is_available(port):
        if time.time() > wait_deadline:
            Config.write_emergency_recovery_file(port)
            err_print(0, 'Web控制面板啓動失敗',
                      f'Port {port} 已被佔用! 設定已改存進 aniGamer.db, 無法直接用文字編輯器打開修改, '
                      f'已在程式資料夾產生 emergency_fix.txt, 請用記事本打開並依照裡面的說明修改 dashboard_port 後'
                      f'重新啟動 aniGamerPlus.exe 即可自動套用',
                      status=1, no_sn=True)
            return
        time.sleep(0.5)

    from Dashboard.Server import run as dashboard
    server = threading.Thread(target=dashboard)
    server.daemon = True
    server.start()
    if settings['dashboard']['SSL']:
        dashboard_address = 'https://'
    else:
        dashboard_address = 'http://'
    if settings['dashboard']['host'] == '0.0.0.0':
        host = Config.get_local_ip()
        dashboard_address = '【開放外部訪問】訪問地址: ' + dashboard_address
        if not settings['dashboard']['BasicAuth']:
            err_print(0, 'Web控制面板安全性警告',
                      '面板已開放外部訪問但未啓用登入密碼保護, 任何人皆可存取與操控此面板! 建議至配置文件開啓 dashboard.BasicAuth',
                      status=1, no_sn=True)
    else:
        host = settings['dashboard']['host']
        dashboard_address = '訪問地址: ' + dashboard_address

    dashboard_address = dashboard_address + host + ':' + str(settings['dashboard']['port'])
    err_print(0, 'Web控制面板已啓動', dashboard_address, no_sn=True, status=2)


signal.signal(signal.SIGINT, user_exit)
signal.signal(signal.SIGTERM, user_exit)
threading.excepthook = _thread_exception_hook
Config.apply_emergency_recovery_file()  # 讀取設定前先套用啟動修復檔案(若存在)
settings = Config.read_settings()
if Config.sanitize_ja3_akamai_in_settings(settings):
    Config.write_settings(settings)
    settings = Config.read_settings()  # 重新載入以取得正規化後的完整設定
working_dir = settings['working_dir']
db_path = os.path.join(working_dir, 'aniGamer.db')
queue = {}  # 儲存 sn 相關信息, {'tag': TAG, 'rename': RENAME}, rename,
processing_queue = []
# _start_queued_workers() 會被主迴圈/_scheduled_check_worker()/run_full_recheck()/Gossip.process_oneoff_entries
# 這幾條獨立執行緒同時呼叫, 保護 queue/processing_queue 的「檢查是否已在跑」與「加入 processing_queue」這組
# 讀取-判斷-寫入操作, 避免同一個 sn 被兩條執行緒同時判定成「還沒在跑」而各自啟動一個 worker 重複下載
_queue_lock = threading.Lock()
thread_limiter = threading.Semaphore(settings['multi-thread'])  # 下載併發限制器
upload_limiter = threading.Semaphore(settings['multi_upload'])  # 併發上傳限制器
db_locker = threading.Semaphore(1)
thread_tasks = []
gost_subprocess = None  # 存放 gost 的 subprocess.Popen 對象, 用於結束時 kill gost
gost_port = gost_port()  # gost 端口
sn_dict = Config.read_sn_list()
_previous_sn_dict_keys = set(sn_dict.keys())  # 用於偵測下次讀取 sn_list.txt 時哪些 sn 被移除了
danmu = settings['danmu']

if __name__ == '__main__':
    if settings['check_latest_version']:
        check_new_version()  # 檢查新版
    version_msg = '當前aniGamerPlus版本: ' + settings['aniGamerPlus_version']
    print(version_msg)

    # 初始化 sqlite3 數據庫
    with closing(sqlite3.connect(db_path)) as conn:
        cursor = conn.cursor()
        cursor.execute('CREATE TABLE IF NOT EXISTS anime ('
                       'sn INTEGER PRIMARY KEY NOT NULL,'
                       'title VARCHAR(100) NOT NULL,'
                       'anime_name VARCHAR(100) NOT NULL, '
                       'episode VARCHAR(10) NOT NULL,'
                       'status TINYINT DEFAULT 0,'
                       'remote_status INTEGER DEFAULT 0,'
                       'resolution INTEGER DEFAULT 0,'
                       'file_size INTEGER DEFAULT 0,'
                       'local_file_path VARCHAR(500),'
                       "[CreatedTime] TimeStamp NOT NULL DEFAULT (datetime('now','localtime')))")
        conn.commit()

    Config.cleanup_stale_temp_files()  # 清理上次意外中斷留下的殘留暫存檔案(下載中斷的分段/合併中的暫存影片)

    if len(sys.argv) > 1:  # 支持命令行使用
        parser = argparse.ArgumentParser()
        parser.add_argument('--sn', '-s', type=int, help='視頻sn碼(數字)')
        parser.add_argument('--resolution', '-r', type=int, help='指定下載清晰度(數字)', choices=[360, 480, 540, 576, 720, 1080])
        parser.add_argument('--download_mode', '-m', type=str, help='下載模式', default='single',
                            choices=['single', 'latest', 'largest-sn', 'multi', 'all', 'range', 'list', 'sn-list', 'sn-range', 'db'])
        parser.add_argument('--thread_limit', '-t', type=int, help='最高並發下載數(數字)')
        parser.add_argument('--current_path', '-c', action='store_true', help='下載到當前工作目錄')
        parser.add_argument('--episodes', '-e', type=str, help='僅下載指定劇集')
        parser.add_argument('--no_classify', '-n', action='store_true', help='不建立番劇資料夾')
        parser.add_argument('--user_command', '-u', action='store_true', help='所有下載完成後執行用戶命令')
        parser.add_argument('--information_only', '-i', action='store_true', help='僅查詢資訊，可搭配 -d 更新彈幕')
        parser.add_argument('--danmu', '-d', action='store_true', help='以 .ass 下載彈幕')
        parser.add_argument('--my_anime', action='store_true', help='匯出「我的動畫」至my_anime.txt')
        arg = parser.parse_args()

        if arg.my_anime:
            export_my_anime()
            sys.exit(0)

        if (arg.download_mode not in ('list', 'multi', 'sn-list', 'db')) and arg.sn is None:
            err_print(0, '參數錯誤', '非 list/multi 模式需要提供 sn ', no_sn=True, status=1)
            sys.exit(1)

        save_dir = ''
        download_mode = arg.download_mode
        if arg.current_path:
            save_dir = os.getcwd()
            info = '使用命令行模式, 指定下載到當前目錄: '
            print(info + '\n    ' + save_dir)
            err_print(0, info + save_dir, no_sn=True, display=False)
        else:
            info = '使用命令行模式, 文件將保存在配置文件中指定的目錄下: '
            print(info + '\n    ' + settings['bangumi_dir'])
            err_print(0, info + settings['bangumi_dir'], no_sn=True, display=False)

        classify = True
        if arg.no_classify:
            classify = False
            print('將不會建立番劇資料夾')

        if not arg.episodes and arg.download_mode == 'range':
            err_print(0, 'ERROR: 當前為指定範圍模式, 但範圍未指定!', status=1, no_sn=True)
            sys.exit(1)

        download_episodes = []
        if arg.episodes or arg.download_mode == 'sn-list':
            if arg.download_mode == 'multi':
                # 如果此時為 multi 模式, 則 download_episodes 裝的是 sn 碼
                for i in arg.episodes.split(','):
                    if re.match(r'^\d+$', i):
                        download_episodes.append(int(i))
                if arg.sn:
                    download_episodes.append(arg.sn)

            elif arg.download_mode == 'sn-list':
                # 如果此時為 sn-list 模式, 則 download_episodes 裝的是 sn_list.txt 裏的 sn 碼
                download_episodes = list(Config.read_sn_list().keys())

            else:
                for i in arg.episodes.split(','):
                    if re.match(r'^\d+-\d+$', i):
                        episodes_range_start = int(i.split('-')[0])
                        episodes_range_end = int(i.split('-')[1])
                        if episodes_range_start > episodes_range_end:  # 如果有zz從大到小寫
                            episodes_range_start, episodes_range_end = episodes_range_end, episodes_range_start
                        download_episodes.extend(list(range(episodes_range_start, episodes_range_end + 1)))
                    if re.match(r'^\d+$', i):
                        download_episodes.append(int(i))
                if arg.download_mode != 'sn-range':
                    download_mode = 'range'  # 如果帶 -e 參數沒有指定 multi 模式, 則默認為 range 模式

            download_episodes = list(set(download_episodes))  # 去重複
            download_episodes.sort()  # 排序, 任務將會按集數順序下載
            # 轉為 str, 方便作為 Anime.get_episode_list() 的 key
            download_episodes = list(map(lambda x: str(x), download_episodes))

        if not arg.resolution:
            resolution = settings['download_resolution']
            print('未設定下載解析度, 將使用配置文件指定的清晰度: ' + resolution + 'P')
        else:
            if arg.download_mode in ('sn-list', 'list'):
                err_print(0,'無效參數:', 'list 及 sn-list 模式無法通過命令行指定清晰度', 1, no_sn=True, display_time=False)
                resolution = settings['download_resolution']
                print('將使用配置文件指定的清晰度: ' + resolution + 'P')
            else:
                resolution = str(arg.resolution)
                print('指定下載解析度: ' + resolution + 'P')

        if arg.download_mode == "db":
            download_mode = "danmu"
            download_episodes = read_db_all()

        if arg.information_only:
            # 為避免排版混亂, 僅顯示信息時強制為單線程
            thread_limit = 1
            thread_limiter = threading.Semaphore(thread_limit)
        else:
            if arg.thread_limit:
                # 用戶設定並發數
                if arg.thread_limit > Config.get_max_multi_thread():
                    # 是否超過最大允許線程數
                    thread_limit = Config.get_max_multi_thread()
                else:
                    thread_limit = arg.thread_limit
            else:
                thread_limit = settings['multi-thread']

        if settings['use_proxy']:
            __init_proxy()

        if arg.user_command:
            user_command = True
        else:
            user_command = False

        if arg.danmu:
            danmu = True

        Config.test_cookie()  # 測試cookie
        __cui(arg.sn, resolution, download_mode, thread_limit, download_episodes, save_dir, classify,
              get_info=arg.information_only, user_cmd=user_command, cui_danmu=danmu)

    err_print(0, '自動模式啓動aniGamerPlus '+version_msg, no_sn=True, display=False)
    err_print(0, '工作目錄: ' + working_dir, no_sn=True, display=False)

    if settings['use_proxy']:
        __init_proxy()

    if settings['use_dashboard']:
        run_dashboard()

    _resume_pending_manual_tasks()

    scheduled_check_thread = threading.Thread(target=_scheduled_check_worker)
    scheduled_check_thread.daemon = True
    scheduled_check_thread.start()

    version_check_thread = threading.Thread(target=_version_check_worker)
    version_check_thread.daemon = True
    version_check_thread.start()

    cookie_warm_up_thread = threading.Thread(target=_cookie_warm_up_worker)
    cookie_warm_up_thread.daemon = True
    cookie_warm_up_thread.start()

    while True:
        if Config.maintenance_mode.is_set():
            # Dashboard 正在執行需要獨佔網路資源的維護操作(例如取得當前新番更新時間), 暫停本輪自動檢查
            time.sleep(1)
            continue
        print()
        err_print(0, '開始更新', no_sn=True)
        Config.test_cookie()  # 測試cookie
        if settings['read_sn_list_when_checking_update']:
            sn_dict = Config.read_sn_list()
            _cleanup_removed_sn_list_entries(_previous_sn_dict_keys, set(sn_dict.keys()))
            _previous_sn_dict_keys = set(sn_dict.keys())
        if settings['read_config_when_checking_update']:
            settings = Config.read_settings()
        danmu = settings['danmu'] # 避免手動加入工作時，global 覆寫掉 config 的 danmu 設定
        check_tasks()  # 檢查更新，生成任務列隊
        new_tasks_counter = _start_queued_workers()  # 新增任務計數器
        info = '本次更新添加了 '+str(new_tasks_counter)+' 個新任務, 目前列隊中共有 ' + str(len(processing_queue)) + ' 個任務'
        err_print(0, '更新資訊', info, no_sn=True)
        err_print(0, '更新終了', no_sn=True)
        if settings['gossip_monitor']:
            Gossip.run_gossip_check(settings, sn_dict)
        print()
        for i in range(settings['check_frequency'] * 60):
            time.sleep(1)  # cool down, 這麼寫是為了可以 Ctrl+C 馬上退出
