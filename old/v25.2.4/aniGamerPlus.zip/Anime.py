#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# @Time    : 2019/1/5 16:22
# @Author  : Miyouzi
# @File    : Anime.py @Software: PyCharm
import ftplib
import shutil
import traceback
import Config
import NotifyDB
from curl_cffi import requests as cffi_requests
from Danmu import Danmu
from bs4 import BeautifulSoup
import re, time, os, platform, subprocess, requests, random, sys, datetime
import gevent
from ColorPrint import err_print
from ftplib import FTP, FTP_TLS
import socket
import threading
import base64
import itertools
from urllib.parse import quote


class TryTooManyTimeError(BaseException):
    pass


class ForceStopError(Exception):
    # 標記不該重試的致命錯誤 (例如非VIP強制停止、地區限制、sn不存在等)
    # 由外層直接終止任務, 不進入重試流程
    pass


class DeviceVerificationError(Exception):
    # 標記「裝置驗證異常」(code=1007): 跟 ForceStopError 不同, 這個錯誤是可以重試的
    # 實測發現這組 device_id 一旦觸發過一次 1007, 之後不管重試幾次、甚至重啟程式沿用同一組都會持續失敗,
    # 必須換一組全新的裝置ID才能恢復; 拋出這個例外前呼叫端應該已經呼叫過 Config.invalidate_device_id() 清除舊的,
    # 讓外層既有的重試機制(__download_only()/worker() 的 while 迴圈)重試時能自動申請到新裝置ID, 不用使用者手動介入
    pass


# ---------------------------------------------------------------------------
# Windows 版 ffmpeg.exe 自動下載: 使用者沒有自行準備 ffmpeg 時, 從內建更新源抓一份放進 working_dir,
# 不用手動安裝。下載網址不直接以明文字串存在原始碼裡——執行期本來就一定要能還原出網址才能發送請求,
# 這裡只是簡單的 XOR + base64 混淆, 避免有人隨手 grep/搜尋原始碼或看 log 就撈到網址去對外轉貼/盜連,
# 不是真正的加密防護(不具備防止真正想反組譯還原的能力)。
# ---------------------------------------------------------------------------
_FFMPEG_DL_KEY = bytes([80, 116, 89, 238, 229, 153, 70, 66, 107, 5, 158, 150, 2, 40, 253, 254])
_FFMPEG_DL_BLOB = 'OAAtnpajaW0KYu70LFySnTMSd4uQtykwDCr48G9YmJl+ESGL'
_ffmpeg_download_lock = threading.Lock()


def _resolve_ffmpeg_download_url():
    raw = base64.b64decode(_FFMPEG_DL_BLOB)
    return bytes(b ^ k for b, k in zip(raw, itertools.cycle(_FFMPEG_DL_KEY))).decode()


def _ensure_windows_ffmpeg(ffmpeg_path):
    # 加鎖: 多個下載任務的執行緒可能同時發現 ffmpeg.exe 不存在, 避免各自觸發一次下載互相踩到彼此寫入的暫存檔
    with _ffmpeg_download_lock:
        if os.path.exists(ffmpeg_path):
            return  # 等待鎖的期間已經被別的執行緒下載完成
        err_print(0, '缺少ffmpeg.exe', no_sn=True, status=1)
        err_print(0, '正在下載ffmpeg.exe', no_sn=True)
        tmp_path = ffmpeg_path + '.downloading'
        try:
            resp = requests.get(_resolve_ffmpeg_download_url(), stream=True, timeout=30)
            resp.raise_for_status()
            with open(tmp_path, 'wb') as f:
                for chunk in resp.iter_content(chunk_size=1024 * 1024):
                    if chunk:
                        f.write(chunk)
            os.replace(tmp_path, ffmpeg_path)  # 下載完整才原子性地換成正式檔名, 避免中途失敗留下半個 ffmpeg.exe
        except Exception:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
            return  # 下載失敗: 交給呼叫端既有的「找不到 ffmpeg」邏輯處理, 這裡不額外印出例外內容(可能夾帶網址)
        err_print(0, 'ffmpeg.exe已下載完成', no_sn=True, status=2)


# 「解鎖影片」的交握流程(token.php 取得播放權杖、unlock/checklock、video_start/checklock 檢查廣告完成)全部圍繞同一組 device_id 進行,
# 代表的是「這個裝置現在正在啟動這部影片」。真實瀏覽器一次只會啟動一部影片; 若同一個 device_id 短時間內對兩部不同影片
# 同時進行這段交握(例如手動任務一次勾選多集、且並發數 > 1), 會被動畫瘋判定為裝置異常使用, 回應 code=1007 裝置驗證異常
# 用這把全域鎖把「解鎖」這段序列化, 讓同一時間只有一部影片在跟伺服器交握; 交握完成拿到 m3u8 之後, 實際分段下載仍可並行進行,
# 不會讓多集並發下載整個變成序列執行
_device_activation_lock = threading.Lock()


# 除錯用(受隱藏開關 Config.is_debug_mode_enabled() 控制): cookie 刷新流程診斷輔助函式, 只在 __request() 的
# cookie 刷新分支呼叫, 不影響一般流程
_DIAG_HEADER_KEYS = ('server', 'cf-ray', 'cf-mitigated', 'content-type', 'content-length')
_DIAG_BODY_MAX_BYTES = 500  # 回應內文只在夠小時才印出(通常代表不是正常頁面, 而是轉址/錯誤提示頁),
                            # 避免不小心把完整頁面內容(可能很長、也可能剛好夾帶敏感內容)整個寫進日誌檔


def _cookie_diag_response_summary(resp, req=None):
    # 只挑幾個不含實際 cookie/使用者資料、但有機會看出「這次回應是不是被 CDN/WAF 攔截轉成挑戰頁」的標頭,
    # 刻意不印完整 headers, 避免夾帶 set-cookie 等敏感內容進日誌檔; body 只在夠小時才印(見 _DIAG_BODY_MAX_BYTES)
    try:
        parts = ['status=' + str(getattr(resp, 'status_code', '?'))]
        if req:
            parts.append('req=' + req)
        for key in _DIAG_HEADER_KEYS:
            value = resp.headers.get(key)
            if value:
                parts.append(key + '=' + value)
        content_length = resp.headers.get('content-length')
        try:
            small_enough = content_length is not None and int(content_length) <= _DIAG_BODY_MAX_BYTES
        except ValueError:
            small_enough = False
        if small_enough:
            body_text = resp.text.strip().replace('\n', ' ').replace('\r', '')[:_DIAG_BODY_MAX_BYTES]
            parts.append('body=' + repr(body_text))
        return ' '.join(parts)
    except Exception:
        return 'status=? (讀取回應摘要時發生例外)'


def _cookie_diag_elapsed_since_last_update():
    # cookie.txt(資料庫)最後一次被寫入(不管是誰寫的)距現在多久, 拿來跟「已經連續刷新失敗幾輪」對照,
    # 方便判斷卡住的是「暫時競爭」還是「已經卡了一段時間都沒人成功刷新過」
    ts_str = Config.get_cookie_time()
    if ts_str == '尚無紀錄':
        return '未知(尚無紀錄)'
    try:
        ts = datetime.datetime.strptime(ts_str, '%Y-%m-%d %H:%M:%S')
        minutes = int((datetime.datetime.now() - ts).total_seconds() // 60)
        if minutes < 60:
            return str(minutes) + ' 分鐘前'
        return str(minutes // 60) + ' 小時 ' + str(minutes % 60) + ' 分鐘前'
    except (ValueError, TypeError):
        return '未知(時間格式無法解析)'


def warm_up_cookie_session():
    # v25.2.3 新增, 正式功能: aniGamerPlus 從頭到尾只跟 ani.gamer.com.tw 交握, 跟真實使用者「先經過
    # www.gamer.com.tw 入口站, 再進動畫瘋」的瀏覽動線不同; 長時間沒有任何請求時, BAHARUNE 會被動畫瘋判定
    # 為登入 session 已過期(不是被其他執行緒搶走, 單純是閒置太久), 之後即使收到 deleted 也救不回來,
    # 只能手動重新登入——補上這段模擬瀏覽的保溫路徑, 定期發請求維持 session 存活, 降低這種情況發生的頻率。
    # 只單純發請求、順便處理可能夾帶的 cookie 刷新, 不建立/依附任何 Anime 物件(呼叫時未必對應到特定一集),
    # 由 aniGamerPlus.py 的 _cookie_warm_up_worker() 背景執行緒定期呼叫, 且只在「沒有下載正在進行中」時才會
    # 真的呼叫這裡, 避免這裡發出的額外請求跟真正的下載/排程檢查搶用併發名額或互相干擾
    #
    # 這裡發出的請求也可能夾帶 BAHARUNE 輪換, 若跟另一個 Anime 實例的「解鎖影片」交握(見 _device_activation_lock
    # 定義處說明)同時發生, 會讓交握中途讀到的 cookie 被這裡悄悄換掉——交握用的還是換掉前的舊值, 不一定會收到
    # 一般的「BAHARUNE deleted」提示(部分端點只會直接回傳空內容, 這種情況下 __request() 內建的刷新/重讀邏輯
    # 完全不會被觸發, 因為它得先看到 deleted 才會啟動), 因而莫名其妙下載失敗。用同一把鎖把兩者序列化, 且用
    # 非阻塞方式嘗試(有交握正在進行就直接跳過, 不用等), 因為有下載在跑時, 那份下載本身發出的請求就已經足夠
    # 讓 session 保持活躍, 不需要這裡的額外保溫
    if not _device_activation_lock.acquire(blocking=False):
        return
    try:
        settings = Config.read_settings()
        cookies = dict(Config.read_cookie())  # 複製一份, 避免直接改到 Config 內部快取的同一個 dict 物件
        if not cookies.get('BAHAID'):
            return  # 遊客身份沒有 BAHARUNE 可以刷新, 不需要模擬瀏覽
        impersonate_type = 'firefox' if 'firefox' in settings['ua'].lower() else 'chrome'
        session_kwargs = {'impersonate': impersonate_type}
        ja3 = settings.get('ja3', '')
        akamai = settings.get('akamai', '')
        if ja3 and akamai:
            session_kwargs['ja3'] = ja3
            session_kwargs['akamai'] = akamai
        session = cffi_requests.Session(**session_kwargs)
        headers = {'User-Agent': settings['ua'], 'Accept-Language': 'zh-TW,zh;q=0.9,en-US;q=0.8,en;q=0.6'}
        for url in ('https://www.gamer.com.tw/', 'https://ani.gamer.com.tw/'):
            resp = session.get(url, headers=headers, cookies=cookies, timeout=10)
            cookies.update(dict(session.cookies))  # 帶著這一站拿到的最新 cookie 繼續下一站, 模擬同一次瀏覽過程
            set_cookie = resp.headers.get('set-cookie', '')
            if 'BAHARUNE' not in set_cookie:
                continue
            if 'deleted' in set_cookie:
                err_print(0, 'Cookie除錯', 'Cookie保溫請求收到 deleted: ' + _cookie_diag_response_summary(resp, url),
                          no_sn=True, display=False)
                continue
            if Config.should_refresh_cookie():
                Config.renew_cookies(cookies, log=False)
                err_print(0, 'Cookie除錯', 'Cookie保溫請求觸發刷新: ' + _cookie_diag_response_summary(resp, url),
                          no_sn=True, status=2)
    except Exception as e:
        # 這只是額外的保溫請求, 任何失敗都不該影響主流程, 安靜記錄就好
        err_print(0, 'Cookie除錯', 'Cookie保溫請求發生例外(不影響其他功能): ' + str(e), no_sn=True, display=False)
    finally:
        _device_activation_lock.release()


class Anime:
    def __init__(self, sn, debug_mode=False, gost_port=34173, manual=False):
        # manual: 這個任務是 Dashboard/CLI 手動提交, 還是排程自動迴圈觸發的, 供下載完成/失敗通知判斷要送
        # download_manual_* 還是 download_schedule_* 類別(見 Config.send_notification())
        self._manual = manual
        self._settings = Config.read_settings()
        self._cookies = dict(Config.read_cookie())  # 複製一份, 避免多個並發任務共用同一個 dict 物件參照
                                                      # (見 warm_up_cookie_session() 的同款註解)
        # 除錯用(受隱藏開關 Config.is_debug_mode_enabled() 控制, 見 Config.py 的 toggle_debug_mode()):
        # 任務一開始讀到的到底是登入身份還是遊客身份, 是排查「後來變遊客」問題的第一個檢查點——
        # 如果這裡就已經是遊客, 代表問題出在 cookie.txt/資料庫本身或 Config.read_cookie() 的解析,
        # 跟後面 __request() 裡的刷新流程(497行起)無關, 不用往那邊找
        if Config.is_debug_mode_enabled():
            if self._cookies.get('BAHAID'):
                err_print(sn, 'Cookie狀態', '任務啟動時讀取到登入身份 cookie', display=False)
            else:
                err_print(sn, 'Cookie狀態', '任務啟動時讀取到的是遊客身份 (無 BAHAID), 本次任務全程將以遊客身份執行',
                          status=1)
        self._working_dir = self._settings['working_dir']
        self._bangumi_dir = self._settings['bangumi_dir']
        self._temp_dir = self._settings['temp_dir']
        self._gost_port = str(gost_port)

        self._session = requests.session()
        self._impersonate_type = 'firefox' if 'firefox' in self._settings['ua'].lower() else 'chrome'
        cffi_session_kwargs = {'impersonate': self._impersonate_type}
        self._using_custom_ja3 = False
        ja3 = self._settings.get('ja3', '')
        akamai = self._settings.get('akamai', '')
        if ja3 and akamai:
            # 自訂 ja3/akamai 指紋: 取代 curl_cffi 內建的罐頭指紋, 需與取得 cookie 的瀏覽器一致 (用 ja3.zone/check 採集)
            cffi_session_kwargs['ja3'] = ja3
            cffi_session_kwargs['akamai'] = akamai
            self._using_custom_ja3 = True
        elif ja3 or akamai:
            err_print(0, 'ja3/akamai設定錯誤', 'ja3 與 akamai 必須同時填寫, 已忽略自訂指紋, 改用內建指紋',
                      status=1, no_sn=True)
        self._cffi_session = cffi_requests.Session(**cffi_session_kwargs)
        self._title = ''
        self._sn = sn
        self._bangumi_name = ''
        self._bangumi_name_orig = ''
        self._episode = ''
        self._episode_list = {}
        self._device_id = ''
        self._playlist = {}
        self._m3u8_dict = {}
        self.local_video_path = ''
        self._video_filename = ''
        self._ffmpeg_path = ''
        self.video_resolution = 0
        self.video_size = 0
        self.realtime_show_file_size = False
        self.upload_succeed_flag = False
        # 無參數 callable, 回傳 True 代表使用者已經終止這個任務(見 __download_only() 的 cancel_check),
        # 供 __ffmpeg_download_mode()/__segment_download_mode() 在下載進行中定期檢查, 中斷已經在下載中的任務
        # (v25.2.2 前只會擋下「還沒開始下載」的任務, 已經在下載中的會放著跑完, 這裡改成連下載中也能真的中止);
        # 只有手動任務(__download_only() 有帶 cancel_check 進來)才會設定, 排程下載一律是 None、不受影響
        self.cancel_check = None
        self._danmu = False
        self._proxies = {}
        self._upload_time = None  # 該集的上架時間(datetime), 供「取得當前新番更新時間」功能使用, 延遲解析

        self.season_title_filter = re.compile('第[零一二三四五六七八九十]{1,3}季$')
        self.extra_title_filter = re.compile(r'\[(特別篇|中文配音)\]$')
        # 番劇類型標籤(不只 extra_title_filter 涵蓋的特別篇/中文配音, 電影/中文電影也算), 專供 __get_bangumi_name()/download()
        # 判斷「番劇名尾端的 [xxx] 是不是類型標籤」時使用, 範圍比 extra_title_filter 廣, 兩者用途不同不能合併
        # (extra_title_filter 在 download() 的分類子資料夾邏輯裡有特定意義: 只代表「歸進 Specials 資料夾」, 電影另有專屬判斷不能混用)
        self._type_marker_filter = re.compile(r'\[(特別篇|中文配音|中文電影|電影)\]$')
        # 去除集數後綴後, 標題尾端若還殘留任何 [xxx] 標籤 (例如 [年齡限制版]、[先行版] 等), 一律視為與集數無關的多餘分類標籤並去除
        # 但 [特別篇]/[中文配音]/[電影]/[中文電影] 這類「番劇類型」標籤不在此列(見 _type_marker_filter), 必須保留,
        # 否則同一部番劇的正篇/中文配音/特別篇/電影會被歸進同一個資料夾(番劇名經過這裡處理後失去區分依據), 詳見 download() 內的分類邏輯
        self.trailing_bracket_filter = re.compile(r'\s*\[[^\[\]]*\]\s*$')

        if self._settings['use_mobile_api']:
            err_print(sn, '解析模式', 'APP解析', display=False)
        else:
            err_print(sn, '解析模式', 'Web解析', display=False)

        if debug_mode:
            print('當前為debug模式')
        else:
            if self._settings['use_proxy']:  # 使用代理
                self.__init_proxy()
            self.__init_header()  # http header
            self.__get_src()  # 獲取網頁, 產生 self._src (BeautifulSoup)
            self.__get_title()  # 提取頁面標題
            self.__get_bangumi_name()  # 提取本番名字
            self.__get_episode()  # 提取劇集碼，str
            # 提取劇集列表，結構 {'episode': sn}，儲存到 self._episode_list, sn 為 int, 考慮到 劇場版 sp 等存在, key 為 str
            self.__get_episode_list()

    def __init_proxy(self):
        if self._settings['use_gost']:
            # 需要使用 gost 的情況, 代理到 gost
            os.environ['HTTP_PROXY'] = 'http://127.0.0.1:' + self._gost_port
            os.environ['HTTPS_PROXY'] = 'http://127.0.0.1:' + self._gost_port
            self._proxies = {'https': 'http://127.0.0.1:' + self._gost_port,
                             'http': 'http://127.0.0.1:' + self._gost_port}
        else:
            # 無需 gost 的情況
            os.environ['HTTP_PROXY'] = self._settings['proxy']
            os.environ['HTTPS_PROXY'] = self._settings['proxy']
            self._proxies = {'https': self._settings['proxy'],
                             'http': self._settings['proxy']}

        if self._settings['no_proxy_akamai']:
            os.environ['NO_PROXY'] = "127.0.0.1,localhost,bahamut.akamaized.net"
        else:
            os.environ['NO_PROXY'] = "127.0.0.1,localhost"

    def renew(self):
        self.__get_src()
        self.__get_title()
        self.__get_bangumi_name()
        self.__get_episode()
        self.__get_episode_list()
        self._upload_time = None  # 重新抓取後上架時間快取失效, 下次 get_upload_time() 會重新解析

    def get_sn(self):
        return self._sn

    def get_bangumi_name(self):
        if self._bangumi_name == '':
            self.__get_bangumi_name()
        return self._bangumi_name

    def __get_episode_display(self):
        # 集數補零/特殊集數(電影、特別篇無編號)的處理, 從 __get_filename() 抽出來共用,
        # 供通知訊息的 get_notify_header() 一起使用, 避免同一份邏輯重複維護
        if re.match(r'^[+-]?\d+(\.\d+){0,1}$', self._episode) and self._settings['zerofill'] > 1:
            if re.match(r'^\d+\.\d+$', self._episode):
                a = re.findall(r'^\d+\.', self._episode)[0][:-1]
                b = re.findall(r'\.\d+$', self._episode)[0]
                episode = a.zfill(self._settings['zerofill']) + b
            else:
                episode = self._episode.zfill(self._settings['zerofill'])
        else:
            episode = self._episode

        if episode in ("電影", "特別篇"):
            return ''
        return '[' + episode + ']'

    def get_notify_episode_display(self):
        # 供通知模板組 @episode@ token 用(NotifyDB.render_notify_message): __get_episode_display() 是私有方法,
        # 這裡對外提供一個公開版本, 讓 aniGamerPlus.py 等外部呼叫點也能拿到跟 get_notify_header() 同一份格式化結果
        return self.__get_episode_display()

    def get_notify_header(self):
        # 通知訊息裡用來識別「是哪一集」的那一行: 名稱(可能是原始解析到的、手動任務自訂的、或 sn_list.txt
        # <重新命名> 標籤設定的, 三者都已經反映在 self._bangumi_name 裡) + [集數] + 副檔名。
        # 刻意不使用 __get_filename() 產出的完整檔名, 因為那個還會帶進「影片檔名前綴/後綴」這類純粹是檔名
        # 客製化用途的設定, 對通知訊息裡的人類讀者來說沒有意義、只會讓訊息變得又長又雜
        episode_display = self.__get_episode_display()
        name = self.get_bangumi_name()
        ext = self._settings['video_filename_extension']
        if episode_display:
            return name + ' ' + episode_display + ' .' + ext
        return name + ' .' + ext

    def get_episode(self):
        if self._episode == '':
            self.__get_episode()
        return self._episode

    def get_episode_list(self):
        if self._episode_list == {}:
            self.__get_episode_list()
        return self._episode_list

    def get_upload_time(self):
        # 取得該集在網頁上顯示的「上架時間」(datetime), 供「取得當前新番更新時間」功能使用
        # APP API 模式的回傳資料沒有這個欄位, 一律回傳 None
        if self._upload_time is None:
            self.__get_upload_time()
        return self._upload_time

    def __get_upload_time(self):
        if self._settings['use_mobile_api']:
            return
        try:
            text = self._src.find('p', 'uploadtime').get_text()
            match = re.search(r'(\d{4})/(\d{2})/(\d{2}) (\d{2}):(\d{2})', text)
            if match:
                year, month, day, hour, minute = map(int, match.groups())
                self._upload_time = datetime.datetime(year, month, day, hour, minute)
        except (AttributeError, TypeError, ValueError):
            # 找不到該標籤, 或頁面結構異常導致無法取得純文字, 一律視為無法取得上架時間
            pass

    def get_title(self):
        return self._title

    def get_filename(self):
        if self.video_resolution == 0:
            return self.__get_filename(self._settings['download_resolution'])
        else:
            return self.__get_filename(str(self.video_resolution))

    def __get_src(self):
        if self._settings['use_mobile_api']:
            self._src = self.__request_json(f'https://api.gamer.com.tw/mobile_app/anime/v4/video.php?sn={self._sn}', no_cookies=True)
        else:
            req = f'https://ani.gamer.com.tw/animeVideo.php?sn={self._sn}'
            f = self.__request(req, no_cookies=True, use_cffi=True)
            self._src = BeautifulSoup(f.content, "lxml")

    def __get_title(self):
        if self._settings['use_mobile_api']:
            try:
                self._title = self._src['data']['anime']['title']
            except KeyError:
                err_print(self._sn, 'ERROR: 該 sn 下真的有動畫？', status=1)
                self._episode_list = {}
                raise ForceStopError('該 sn 下沒有動畫')
        else:
            soup = self._src
            try:
                self._title = soup.find('div', 'anime_name').h1.string  # 提取標題（含有集數）
            except (TypeError, AttributeError):
                # 該sn下沒有動畫
                err_print(self._sn, 'ERROR: 該 sn 下真的有動畫？', status=1)
                self._episode_list = {}
                raise ForceStopError('該 sn 下沒有動畫')

    def __get_bangumi_name(self):
        self._bangumi_name = self._title.replace('[' + self.get_episode() + ']', '').strip()  # 提取番劇名（去掉集數後綴）
        while self.trailing_bracket_filter.search(self._bangumi_name):
            # 去除標題尾端殘留的 [年齡限制版]/[先行版]/[特別篇]/[中文配音]/[電影]/[中文電影] 等與集數無關的額外標籤。
            # self._bangumi_name 是對外公開的番劇名稱(檔名/通知/主控台顯示等到處都會用到), 一律去除乾淨,
            # 不應該讓 [電影] 這類類型標籤外洩到檔名或通知裡; 分類子資料夾需要用到的類型標籤改用
            # download() 內部自己算的 self._bangumi_name_orig(見下方), 兩者用途分開不衝突
            self._bangumi_name = self.trailing_bracket_filter.sub('', self._bangumi_name)
        self._bangumi_name = re.sub(r'\s+', ' ', self._bangumi_name)  # 去除重複空格

    def __get_episode(self):  # 提取集數

        def get_ep():
            # 20210719 動畫瘋的版本位置又瞎蹦躂
            # https://github.com/miyouzi/aniGamerPlus/issues/109
            # 先查看有沒有數字, 如果沒有再查看有沒有中括號, 如果都沒有直接放棄, 把集數填作 1
            self._episode = re.findall(r'\[\d*\.?\d* *\.?[A-Z,a-z]*(?:電影)?\]', self._title)
            if len(self._episode) > 0:
                self._episode = str(self._episode[0][1:-1])
            elif len(re.findall(r'\[.+?\]', self._title)) > 0:
                self._episode = re.findall(r'\[.+?\]', self._title)
                self._episode = str(self._episode[0][1:-1])
            else:
                self._episode = "1"

        # 20200320 發現多版本標籤後置導致原集數提取方法失效
        # https://github.com/miyouzi/aniGamerPlus/issues/36
        # self._episode = re.findall(r'\[.+?\]', self._title)  # 非貪婪匹配
        # self._episode = str(self._episode[-1][1:-1])  # 考慮到 .5 集和 sp、ova 等存在，以str儲存
        if self._settings['use_mobile_api']:
            get_ep()
        else:
            soup = self._src
            try:
                #  適用於存在劇集列表
                self._episode = str(soup.find('li', 'playing').a.string)
            except AttributeError:
                # 如果這個sn就一集, 不存在劇集列表的情況
                # https://github.com/miyouzi/aniGamerPlus/issues/36#issuecomment-605065988
                # self._episode = re.findall(r'\[.+?\]', self._title)  # 非貪婪匹配
                # self._episode = str(self._episode[0][1:-1])  # 考慮到 .5 集和 sp、ova 等存在，以str儲存
                get_ep()

    def __get_episode_list(self):
        # 每次都從空字典重新建立, 不要累加在舊資料上——這個方法不是只在 __init__ 呼叫一次, renew()(下載失敗重試時會呼叫)
        # 也會再呼叫一次。若不清空, 第二次呼叫時 self._episode_list 已經有上一輪的所有集數, 下面判斷「是否為重複集數編號」
        # (特別篇/中文配音等需要用 index_counter 配合 <p> 標籤消歧義的邏輯)會把幾乎每一集都誤判成重複, index_counter
        # 不斷遞增卻沒有相應變多的 <p> 標籤可以對應, 最終讀取 p[index_counter[ep]] 時 IndexError: list index out of range
        self._episode_list = {}
        if self._settings['use_mobile_api']:
            for _type in self._src['data']['anime']['episodes']:
                for _sn in self._src['data']['anime']['episodes'][_type]:
                    if _type == '0': # 本篇
                        self._episode_list[str(_sn['episode'])] = int(_sn["videoSn"])
                    elif _type == '1': # 電影
                        self._episode_list['電影'] = int(_sn["videoSn"])
                    elif _type == '2': # 特別篇
                        self._episode_list[f'特別篇{_sn["episode"]}'] = int(_sn["videoSn"])
                    elif _type == '3': # 中文配音
                        self._episode_list[f'中文配音{_sn["episode"]}'] = int(_sn["videoSn"])
                    else: # 中文電影
                        self._episode_list['中文電影'] = int(_sn["videoSn"])
        else:
            try:
                season = self._src.find('section', 'season')
                # https://github.com/miyouzi/aniGamerPlus/issues/9
                # 樣本 https://ani.gamer.com.tw/animeVideo.php?sn=10210
                # 20190413 動畫瘋將特別篇分離
                #
                # v25.2.0 修正: 分類前綴改用「這個 <a> 在 DOM 上實際隸屬哪個 <p> 分類標籤(本篇/特別篇/中文配音/...)」
                # 直接判斷, 不再用「這個集數編號出現第幾次」去反推對應第幾個 <p> 標籤——舊版寫法假設每個分類的集數編號
                # 都完整對齊(例如本篇/特別篇/中文配音都剛好有相同的 1~N 集), 一旦分類之間集數多寡不一致(常見情況:
                # 特別篇通常只有 1~2 集, 中文配音卻有跟本篇一樣多集), 出現次數會提前對不齊, 導致集數較少的分類用完後,
                # 集數較多的分類的集數全部被誤標成前一個分類的名稱(例如中文配音第 2 集以後全部被誤標成「特別篇2」...）
                current_category = None
                for tag in season.find_all(['p', 'a']):
                    if tag.name == 'p':
                        current_category = tag.get_text(strip=True)
                        continue
                    sn = int(tag['href'].replace('?sn=', ''))
                    ep = str(tag.string)
                    label = current_category + ep if current_category and current_category != '本篇' else ep
                    # 正常情況下同一分類不會有重複編號; 保留防呆避免真的遇到重複時互相覆蓋(而不是直接消失一集)
                    dedup_label, suffix = label, 1
                    while dedup_label in self._episode_list:
                        suffix += 1
                        dedup_label = label + '-' + str(suffix)
                    self._episode_list[dedup_label] = sn
            except AttributeError:
                # 當只有一集時，不存在劇集列表，self._episode_list 只有本身
                self._episode_list[self._episode] = self._sn

    def __init_header(self):
        # 僞裝為瀏覽器
        host = 'ani.gamer.com.tw'
        origin = 'https://' + host
        ua = self._settings['ua']  # cookie 自動刷新需要 UA 一致
        ref = 'https://' + host + '/animeVideo.php?sn=' + str(self._sn)
        lang = 'zh-TW,zh;q=0.9,en-US;q=0.8,en;q=0.6'
        accept = 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8'
        accept_encoding = 'gzip, deflate'
        cache_control = 'max-age=0'
        self._mobile_header = {
            "User-Agent": "Animad/1.16.16 (tw.com.gamer.android.animad; build:328; Android 9) okHttp/4.4.0",
            "X-Bahamut-App-Android": "tw.com.gamer.android.animad",
            "X-Bahamut-App-Version": "328",
            "Accept-Encoding": "gzip",
            "Connection": "Keep-Alive"
        }
        self._web_header = {
                "User-Agent": ua,
                "referer": ref,
                "Accept-Language": lang,
                "Accept": accept,
                "Accept-Encoding": accept_encoding,
                "Cache-Control": cache_control,
                "Origin": origin
            }
        if self._settings['use_mobile_api']:
            self._req_header = self._mobile_header
        else:
            self._req_header = self._web_header

    def __request(self, req, no_cookies=False, show_fail=True, max_retry=3, addition_header=None, use_cffi = None):
        if use_cffi is None:
            # 預設依 use_mobile_api 自動選擇: Web API 用 curl_cffi 模擬瀏覽器指紋以維持整個 session 的指紋一致性
            # Mobile API 則維持原生 requests, 避免 curl_cffi 的瀏覽器專屬標頭 (sec-ch-ua 等) 與 App UA 互相矛盾, 反而更可疑
            use_cffi = not self._settings['use_mobile_api']
        # 設置 header
        current_header = self._req_header
        if addition_header is None:
            addition_header = {}
        if len(addition_header) > 0:
            for key in addition_header.keys():
                current_header[key] = addition_header[key]

        # 獲取頁面
        error_cnt = 0
        ja3_fallback_applied = False
        if self._cookies and not no_cookies:
            cookies = self._cookies
        else:
            cookies = {}
        while True:
            try:
                if use_cffi:
                    # https://github.com/miyouzi/aniGamerPlus/issues/249 pyhttpx 版本過舊已不再維護, 改用 curl_cffi 模擬瀏覽器指紋繞過反爬蟲
                    # curl_cffi 底層是 libcurl(原生 C 擴充), 不像純 Python 的 requests/socket 那樣完全受 gevent monkey-patch
                    # 影響——等待連線建立的階段還算能與 gevent 協作, 但實際「快速收資料」的階段是在 libcurl 內部的緊湊迴圈裡跑,
                    # 不會主動讓出控制權給 gevent 的事件迴圈。多個分段並發下載時, 這會讓 Dashboard 自己的網頁請求(共用同一個
                    # 事件迴圈)被排擠延遲, 網速越快、卡頓越明顯, 只有全部下載完(不再有 curl_cffi 呼叫在跑)才會恢復正常
                    # 解法: 把這個呼叫丟到 gevent 專屬的執行緒池(真正的 OS 執行緒, 不是 greenlet)裡執行, .get() 本身是
                    # gevent-aware 的等待, 讓事件迴圈在等待期間仍能正常處理其他 greenlet(例如 Dashboard 的網頁請求)
                    f = gevent.get_hub().threadpool.spawn(
                        self._cffi_session.get, req, headers=current_header, cookies=cookies, timeout=10,
                        proxies=self._proxies
                    ).get()
                else:
                    f = self._session.get(req, headers=current_header, cookies=cookies, timeout=10)
            except (requests.exceptions.RequestException, cffi_requests.exceptions.RequestException) as e:
                if error_cnt >= max_retry >= 0:
                    raise TryTooManyTimeError('任務狀態: sn=' + str(self._sn) + ' 請求失敗次數過多！請求鏈接：\n%s' % req)
                err_detail = 'ERROR: 請求失敗！except：\n' + str(e) + '\n3s後重試(最多重試' + str(max_retry) + '次)'
                if show_fail:
                    err_print(self._sn, '任務狀態', err_detail)
                time.sleep(3)
                error_cnt += 1
            except NotImplementedError as e:
                # curl_cffi 不支援切換自訂 ja3/akamai 指紋裡的某個 TLS 擴展 (例如採集時剛好抓到 session resumption 的握手,
                # 帶有 curl_cffi 目前無法程式化切換的擴展編號), 自動退回內建罐頭指紋重試這次請求, 避免整個任務直接失敗
                if use_cffi and self._using_custom_ja3 and not ja3_fallback_applied:
                    ja3_fallback_applied = True
                    err_print(self._sn, 'ja3/akamai指紋錯誤',
                              '自訂指紋包含 curl_cffi 不支援的 TLS 擴展 (' + str(e) + '), 本次請求已自動退回內建指紋繼續, '
                              '建議重新採集或清空 Dashboard 的 ja3/akamai 設定',
                              status=1)
                    self._cffi_session = cffi_requests.Session(impersonate=self._impersonate_type)
                else:
                    raise
            else:
                break
        # 處理 cookie
        resp_session_cookies = self._cffi_session.cookies if use_cffi else self._session.cookies
        if not self._cookies:
            # 當實例中尚無 cookie, 則讀取
            self._cookies = resp_session_cookies
        elif 'nologinuser' not in self._cookies.keys() and 'BAHAID' not in self._cookies.keys():
            # 處理遊客cookie
            if 'nologinuser' in resp_session_cookies.keys():
                # self._cookies['nologinuser'] = resp_session_cookies['nologinuser']
                self._cookies = resp_session_cookies
        else:  # 如果用戶提供了 cookie, 則處理cookie刷新
            # 只有動畫瘋官方網域 (ani.gamer.com.tw / api.gamer.com.tw) 且 set-cookie 內容確實包含 BAHARUNE (登入憑證輪換用cookie)
            # 才視為登入cookie刷新事件。避免 CDN (bahamut.akamaized.net) 或 Cloudflare 的 __cf_bm 等無關 cookie
            # 被誤判為登入狀態變更 —— 大量並發請求(例如影片分段下載, 每個 chunk 都可能帶有 set-cookie)若都觸發這段邏輯,
            # 會造成短時間內反覆寫入 cookie.txt 並重新請求首頁, 可能被判定為異常使用行為
            if 'gamer.com.tw' in req and 'set-cookie' in f.headers.keys() and 'BAHARUNE' in f.headers.get('set-cookie', ''):  # 發現server響應了set-cookie
                if 'deleted' in f.headers.get('set-cookie'):
                    # set-cookie刷新cookie只有一次機會, 如果其他線程先收到, 則此處會返回 deleted
                    # 等待其他線程刷新了cookie, 重新讀入cookie

                    if self._settings['use_mobile_api'] and 'X-Bahamut-App-Android' in self._req_header:
                        # 使用移動API將無法進行 cookie 刷新, 改回 header 刷新 cookie
                        err_print(self._sn, '嘗試切換回 Web Header 刷新 Cookie', display=False)
                        self._req_header = self._web_header
                        self.__request('https://ani.gamer.com.tw/')  # 再次嘗試獲取新 cookie
                    else:
                        err_print(self._sn, '收到cookie重置響應', display=False)
                        if Config.is_debug_mode_enabled():
                            # 除錯用: 收到 BAHARUNE=deleted 當下這個回應的狀態碼/CDN 相關標頭, 用來分辨這是
                            # 正常的「刷新競爭被搶先」, 還是回應其實被 CDN/WAF 攔截轉成了挑戰頁(例如
                            # cf-mitigated 標頭, 或 status 不是預期的 200); 同時記錄 cookie.txt 已經卡了多久
                            # 沒被任何人成功更新過, 方便跟後面連續好幾輪都失敗的情況對照
                            err_print(self._sn, 'Cookie除錯',
                                      '收到 deleted 回應詳情: ' + _cookie_diag_response_summary(f, req) +
                                      ' | cookie.txt 已 ' + _cookie_diag_elapsed_since_last_update() + ' 未更新')
                        time.sleep(2)
                        try_counter = 0
                        succeed_flag = False
                        while try_counter < 3:  # 嘗試讀三次, 不行就算了
                            # 用 .get() 而非直接索引: 這個分支只保證 self._cookies 裡有 nologinuser 或 BAHAID
                            # 其中之一, 訪客 session 可能根本沒有 BAHARUNE 這個 key, 直接索引會拋出 KeyError
                            old_BAHARUNE = self._cookies.get('BAHARUNE')
                            self._cookies = dict(Config.read_cookie())  # 複製一份, 理由同 __init__
                            err_print(self._sn, '讀取cookie',
                                      'cookie.txt最後修改時間: ' + Config.get_cookie_time() + ' 第' + str(try_counter) + '次嘗試',
                                      display=False)
                            if old_BAHARUNE != self._cookies.get('BAHARUNE'):
                                # 新cookie讀取成功 (因為有可能其他線程接到了新cookie)
                                succeed_flag = True
                                err_print(self._sn, '讀取cookie', '新cookie讀取成功', display=False)
                                break
                            else:
                                err_print(self._sn, '讀取cookie', '新cookie讀取失敗', display=False)
                                random_wait_time = random.uniform(2, 5)
                                time.sleep(random_wait_time)
                                try_counter = try_counter + 1
                        if not succeed_flag:
                            self._cookies = {}
                            fail_detail = ''
                            if Config.is_debug_mode_enabled():
                                fail_detail = '(cookie.txt 已 ' + _cookie_diag_elapsed_since_last_update() + ' 未更新)'
                            err_print(0, '用戶cookie更新失敗! 使用遊客身份訪問' + fail_detail, status=1, no_sn=True)
                            # 這裡讀取失敗有可能只是併發搶刷新名額競爭下的暫時性失利, 不代表cookie真的已失效,
                            # 故只重置記憶體快取(本次請求以遊客身份繼續), 保留 cookie.txt 不刪除,
                            # 避免其他仍在下載中的執行緒存取該檔案時失敗 (見 Config.invalid_cookie())
                            Config.invalid_cookie(remove_file=False)

                        if self._settings['use_mobile_api'] and 'X-Bahamut-App-Android' not in self._req_header:
                            # 即使切換 header cookie 也無法刷新, 那麼恢復 header, 好歹廣告只有 3s
                            self._req_header = self._mobile_header

                else:
                    # 本線程收到了新cookie: 不管下面的節流閥是否放行, 都要先把伺服器剛給的新值套用到「這個
                    # 執行緒自己」的記憶體 cookie —— 否則被節流擋下的執行緒會繼續帶著已經被伺服器換掉的舊值
                    # 送出下一次請求, 幾乎必定馬上收到 deleted, 且併發量一旦超過節流間隔, cookie.txt 永遠追不上
                    # 伺服器端實際的輪換進度(這就是除錯紀錄觀察到「cookie.txt 連續數小時未更新」的成因)
                    self._cookies.update(resp_session_cookies)

                    if Config.should_refresh_cookie():
                        # 20220115 簡化 cookie 刷新邏輯
                        # 限流: 同一時間只允許一組「寫檔+重打首頁」動作執行, 避免多執行緒併發時反覆寫檔+
                        # 重新請求首頁 (見 Config.should_refresh_cookie); 只節流這兩個較重的動作, 不節流上面
                        # 的本地套用
                        err_print(self._sn, '收到新cookie', display=False)

                        Config.renew_cookies(self._cookies, log=False)

                        key_list_str = ', '.join(resp_session_cookies.keys())
                        err_print(self._sn, f'用戶cookie刷新 {key_list_str} ', display=False)

                        self.__request('https://ani.gamer.com.tw/')
                        # 20210724 動畫瘋一步到位刷新 Cookie
                        if 'BAHARUNE' in f.headers.get('set-cookie'):
                            err_print(0, '用戶cookie已更新', status=2, no_sn=True)
                            if Config.is_debug_mode_enabled():
                                # 除錯用: 記錄一次「正常成功刷新」當下的回應摘要, 供跟之後如果又發生 deleted
                                # 的情況比對兩者的狀態碼/CDN 標頭是否有明顯差異
                                err_print(self._sn, 'Cookie除錯', '刷新成功回應詳情: ' + _cookie_diag_response_summary(f, req),
                                          display=False)
                            if self._settings['use_mobile_api']:
                                # 當使用 APP API 臨時切換至 Web API 更新 Cookie 時，Cookie 更新成功再切換回 App Header
                                self._req_header = self._mobile_header
                                err_print(self._sn, '切換回 App Header 進行影片解析', display=False)

        return f

    def __request_json(self, req, no_cookies=False, show_fail=True, max_retry=3, addition_header=None, use_cffi = None):
        resp = self.__request(req, no_cookies, show_fail, max_retry, addition_header, use_cffi)
        try:
            return resp.json()
        except ValueError:
            # 診斷用: API 端點預期回傳 JSON, 但內容解析失敗(常見於直接收到空內容)——印出狀態碼/CDN 相關標頭/
            # 內容片段(見 _cookie_diag_response_summary), 取代原本只有一句 JSONDecodeError 訊息、看不出伺服器
            # 實際回了什麼的情況; 印完照樣往外拋出, 不改變原本的錯誤處理流程
            err_print(self._sn, 'API回應診斷', '非預期的非JSON回應: ' + _cookie_diag_response_summary(resp, req), status=1)
            raise

    def __get_m3u8_dict(self):
        # m3u8獲取模塊參考自 https://github.com/c0re100/BahamutAnimeDownloader
        def get_device_id():
            # v25.2.0 起改成每次下載前都先強製作廢舊的裝置ID, 換一組全新的再下載(使用者實測環境 cookie 每天都會失效,
            # 而 Config.get_or_fetch_device_id() 的「cookie/指紋是否已變更」過期偵測只在程式重新啟動時才會執行一次,
            # 執行期間 cookie 中途自動刷新後, 舊裝置ID會一路沿用到下次重啟, 跟已經換過的 cookie 對不上, 導致每次
            # 下載一開始就收到 code=1007 裝置驗證異常; 強制每次都換新裝置ID可以確保裝置ID永遠對應目前的 cookie,
            # 代價是提高了同一帳號短時間內申請多組裝置ID的頻率(原本刻意避免這種模式, 詳見 Config.py 的相關註解),
            # 若之後改善成「偵測到 cookie 已刷新就重新申請裝置ID」而不是每次都換, 可以拿掉這行 invalidate
            Config.invalidate_device_id()

            def fetch():
                req = 'https://ani.gamer.com.tw/ajax/getdeviceid.php'
                return self.__request_json(req)['deviceid']
            self._device_id = Config.get_or_fetch_device_id(fetch)
            return self._device_id

        def get_playlist():
            if self._settings['use_mobile_api']:
                req = f'https://api.gamer.com.tw/mobile_app/anime/v3/m3u8.php?videoSn={str(self._sn)}&device={self._device_id}'
            else:
                # 20260817: 舊版 ani.gamer.com.tw/ajax/m3u8.php 已被動畫瘋停用(固定回 404 File not found),
                # 改用網頁播放器實際發出的新端點取代——透過瀏覽器開發者工具的網路分頁, 對照播放頁面實際發出的
                # 請求才找到(舊版程式碼已無從得知, 這支端點沒有公開文件); deviceTypeUseCases=1 對應瀏覽器
                # 實測固定帶的值, 回應改成巢狀的 srcUseCases 陣列包裝(見 parse_playlist() 對應的解析寫法)。
                # 注意參數名稱是 deviceid(全小寫、無底線), 不是這支程式其他端點慣用的 device——送錯參數名稱
                # 會被伺服器視為缺少必要參數, 回傳 400 INVALID_ARGUMENT
                req = f'https://api.gamer.com.tw/anime/v1/video_src.php?videoSn={str(self._sn)}&deviceid={self._device_id}&deviceTypeUseCases=1'
            self._playlist = self.__request_json(req)

        def random_string(num):
            chars = 'abcdefghijklmnopqrstuvwxyz0123456789'
            random.seed(int(round(time.time() * 1000)))
            result = []
            for i in range(num):
                result.append(chars[random.randint(0, len(chars) - 1)])
            return ''.join(result)

        def gain_access():
            if self._settings['use_mobile_api']:
                req = f'https://ani.gamer.com.tw/ajax/token.php?adID=0&sn={str(self._sn)}&device={self._device_id}'
            else:
                req = 'https://ani.gamer.com.tw/ajax/token.php?adID=0&sn=' + str(
                    self._sn) + "&device=" + self._device_id + "&hash=" + random_string(12)
            # 返回基礎信息, 用於判斷是不是VIP
            return self.__request_json(req)

        def unlock():
            req = 'https://ani.gamer.com.tw/ajax/unlock.php?sn=' + str(self._sn) + "&ttl=0"
            f = self.__request(req)  # 無響應正文

        def check_lock():
            req = 'https://ani.gamer.com.tw/ajax/checklock.php?device=' + self._device_id + '&sn=' + str(self._sn)
            f = self.__request(req)

        def start_ad():
            if self._settings['use_mobile_api']:
                req = f"https://api.gamer.com.tw/mobile_app/anime/v1/stat_ad.php?schedule=-1&sn={str(self._sn)}"
            else:
                req = "https://ani.gamer.com.tw/ajax/videoCastcishu.php?sn=" + str(self._sn) + "&s=194699"
            f = self.__request(req)  # 無響應正文

        def skip_ad():
            if self._settings['use_mobile_api']:
                req = f"https://api.gamer.com.tw/mobile_app/anime/v1/stat_ad.php?schedule=-1&ad=end&sn={str(self._sn)}"
            else:
                req = "https://ani.gamer.com.tw/ajax/videoCastcishu.php?sn=" + str(self._sn) + "&s=194699&ad=end"
            f = self.__request(req)  # 無響應正文

        def video_start():
            req = "https://ani.gamer.com.tw/ajax/videoStart.php?sn=" + str(self._sn)
            f = self.__request(req)

        def check_no_ad(error_count=10):
            if error_count == 0:
                err_print(self._sn, '廣告去除失敗! 請向開發者提交 issue!', status=1)
                raise ForceStopError('廣告去除失敗')

            req = "https://ani.gamer.com.tw/ajax/token.php?sn=" + str(
                self._sn) + "&device=" + self._device_id + "&hash=" + random_string(12)
            resp = self.__request_json(req)
            if 'time' in resp.keys():
                if not resp['time'] == 1:
                    err_print(self._sn, '廣告似乎還沒去除, 追加等待2秒, 剩餘重試次數 ' + str(error_count), status=1)
                    time.sleep(2)
                    skip_ad()
                    video_start()
                    check_no_ad(error_count=error_count - 1)
                else:
                    # 通過廣告檢查
                    if error_count != 10:
                        ads_time = (10-error_count)*2 + ad_time + 2
                        err_print(self._sn, '通過廣告時間' + str(ads_time) + '秒, 記錄到配置檔案', status=2)
                        if self._settings['use_mobile_api']:
                            self._settings['mobile_ads_time'] = ads_time
                        else:
                            self._settings['ads_time'] = ads_time
                        Config.write_settings(self._settings)  # 保存到配置文件
            else:
                err_print(self._sn, '遭到動畫瘋地區限制, 你的IP可能不被動畫瘋認可!', status=1)
                raise ForceStopError('遭到動畫瘋地區限制')

        def parse_playlist():
            playlist_url = ""
            if self._settings['use_mobile_api']:
                playlist_url = self._playlist['data']['src']
            else:
                # 對應 get_playlist() 的新端點回應格式: {"data": {"srcUseCases": [{"deviceType": 1,
                # "src": {"playlist": "..."}}]}}——固定取第一筆(目前只請求 deviceTypeUseCases=1 一種)
                if 'data' not in self._playlist:
                    # 診斷用: 回應格式跟預期不同(例如改回錯誤物件 {"error": {...}}), 印出完整原始內容,
                    # 取代原本只有一句無說明的 KeyError, 才能看出伺服器實際回了什麼
                    err_print(self._sn, 'API回應診斷', 'video_src.php 回應內容不含 data: ' + str(self._playlist)[:500],
                              status=1)
                playlist_url = self._playlist['data']['srcUseCases'][0]['src']['playlist']
            f = self.__request(playlist_url, no_cookies=True, addition_header={'origin': 'https://ani.gamer.com.tw'})
            url_prefix = re.sub(r'playlist.+', '', playlist_url)  # m3u8 URL 前綴
            m3u8_list = re.findall(r'=\d+x\d+\n.+', f.content.decode())  # 將包含分辨率和 m3u8 文件提取
            m3u8_dict = {}
            for i in m3u8_list:
                key = re.findall(r'=\d+x\d+', i)[0]  # 提取分辨率
                key = re.findall(r'x\d+', key)[0][1:]  # 提取縱向像素數，作為 key
                value = re.findall(r'.*chunklist.+', i)[0]  # 提取 m3u8 文件
                value = url_prefix + value  # 組成完整的 m3u8 URL
                m3u8_dict[key] = value
            self._m3u8_dict = m3u8_dict

        # 「解鎖影片」交握全程序列化(見 _device_activation_lock 定義處說明), 避免同一 device_id 同時對多部影片交握而觸發 code=1007。
        # 這把鎖是全域的, 批次任務好幾集排隊等交握是常態; 使用者若在還輪到這一集之前就終止了任務, 不該讓它繼續乾等
        # 這把鎖, 改用短逾時輪詢, 每次沒搶到鎖都檢查一次是否已被終止, 搶到鎖之後也再檢查一次(搶到的當下可能剛好
        # 也是終止的那一刻), 這樣「還沒排到」的集數能在終止當下立刻放棄、不用等到真的輪到自己交握才發現要取消
        while not _device_activation_lock.acquire(timeout=1):
            if self.cancel_check and self.cancel_check():
                return
        try:
            if self.cancel_check and self.cancel_check():
                return
            get_device_id()
            # 診斷用: 印出這次交握實際用的 device_id 與指紋狀態, 方便比對「同一次執行內, 不同集數是否真的用了同一組身分」
            # (self._using_custom_ja3 只反映建構 session 當下有沒有設定自訂指紋; 若途中因 curl_cffi 不支援的 TLS 擴展
            # 觸發自動退回內建指紋, self._cffi_session 會被替換掉但這個布林值不會跟著變回 False, 這行本身無法偵測到那種情況,
            # 那種情況要看有沒有出現下面 NotImplementedError 分支印出的「ja3/akamai指紋錯誤」訊息)
            err_print(self._sn, '裝置身分診斷',
                      'device_id=' + str(self._device_id) + ' 使用自訂ja3/akamai=' + str(self._using_custom_ja3))
            user_info = gain_access()
            if not self._settings['use_mobile_api']:
                unlock()
                check_lock()
                unlock()
                unlock()

            # 收到錯誤反饋
            # 可能是限制級動畫要求登陸
            if 'error' in user_info.keys():
                msg = '《' + self._title + '》 '
                msg = msg + 'code=' + str(user_info['error']['code']) + ' message: ' + user_info['error']['message']
                err_print(self._sn, '收到錯誤', msg, status=1)
                if str(user_info['error']['code']) == '1007':
                    # 「裝置驗證異常」實測是這組 device_id 本身被標記, 不是暫時性的請求問題;
                    # 清掉裝置ID讓下一次重試(或下一個任務)能申請到全新的, 並拋出可重試的例外(不是 ForceStopError)
                    Config.invalidate_device_id()
                    err_print(self._sn, '裝置驗證異常', '已清除裝置ID, 稍後重試時將自動申請一組新的', status=1)
                    Config.send_notification('system_device_error', '系統通知', error_message=msg, finish_time=NotifyDB.now_str())
                    raise DeviceVerificationError(msg)
                raise ForceStopError(msg)

            if not user_info['vip']:
                # 如果用戶不是 VIP, 那麼等待廣告(20s)
                # 20200513 網站更新，最低廣告更新時間從8s增加到20s https://github.com/miyouzi/aniGamerPlus/issues/41
                # 20200806 網站更新，最低廣告更新時間從20s增加到25s https://github.com/miyouzi/aniGamerPlus/issues/55

                if self._settings['only_use_vip']:
                     err_print(self._sn, '非VIP','因為已設定只使用VIP下載，故強制停止', status=1, no_sn=True)
                     raise ForceStopError('已設定只使用VIP下載, 但目前帳號並非VIP')

                if self._settings['use_mobile_api']:
                    ad_time = self._settings['mobile_ads_time']  # APP解析廣告解析時間不同
                else:
                    ad_time = self._settings['ads_time']

                err_print(self._sn, '正在等待', '《' + self.get_title() + '》 由於不是VIP賬戶, 正在等待'+str(ad_time)+'s廣告時間')
                start_ad()
                # 非VIP廣告等待動輒20~25秒, 拆成每秒檢查一次是否已被終止(比照分段下載等待迴圈的做法), 而不是
                # 整段 sleep 完全無法中斷, 讓終止任務至少不用在這裡多等快半分鐘
                for _ in range(int(ad_time)):
                    if self.cancel_check and self.cancel_check():
                        return
                    time.sleep(1)
                skip_ad()
            else:
                err_print(self._sn, '開始下載', '《' + self.get_title() + '》 識別到VIP賬戶, 立即下載')

            if self.cancel_check and self.cancel_check():
                return
            if not self._settings['use_mobile_api']:
                video_start()
                check_no_ad()
            get_playlist()
            parse_playlist()
        finally:
            _device_activation_lock.release()

    def get_m3u8_dict(self):
        if not self._m3u8_dict:
            self.__get_m3u8_dict()
        return self._m3u8_dict

    def get_season_num(self, zh_num):
        zh2digit_table = {'零': 0, '一': 1, '二': 2, '兩': 2, '三': 3, '四': 4, '五': 5, '六': 6, '七': 7, '八': 8, '九': 9, '十': 10}

        # 位數遞增，由高位開始取
        digit_num = 0
        # 結果
        result = 0
        # 暫時存儲的變量
        tmp = 0

        while digit_num < len(zh_num):
            tmp_zh = zh_num[digit_num]
            tmp_num = zh2digit_table.get(tmp_zh, None)
            if tmp_num >= 10:
                if tmp == 0:
                    tmp = 1
                result = result + tmp_num * tmp
                tmp = 0
            elif tmp_num is not None:
                tmp = tmp * 10 + tmp_num
            digit_num += 1

        result = result + tmp
        return result

    def __get_filename(self, resolution, without_suffix=False):
        episode = self.__get_episode_display()  # 已含中括號, 電影/特別篇時為空字串

        if self._settings['add_bangumi_name_to_video_filename']:
            # 如果用戶需要番劇名
            bangumi_name = self._settings['customized_video_filename_prefix'] \
                           + self._bangumi_name \
                           + self._settings['customized_bangumi_name_suffix']

            filename = bangumi_name + episode  # 有番劇名的文件名
        else:
            # 如果用戶不要將番劇名添加到文件名
            filename = self._settings['customized_video_filename_prefix'] + episode

        # 添加分辨率後綴
        if self._settings['add_resolution_to_video_filename']:
            filename = filename + '[' + resolution + 'P]'

        if without_suffix:
            return filename  # 截止至清晰度的文件名, 用於 __get_temp_filename()

        # 添加用戶後綴及擴展名
        filename = filename + self._settings['customized_video_filename_suffix'] \
                   + '.' + self._settings['video_filename_extension']
        legal_filename = Config.legalize_filename(filename)  # 去除非法字符
        filename = legal_filename
        return filename

    def __get_temp_filename(self, resolution, temp_suffix):
        filename = self.__get_filename(resolution, without_suffix=True)
        # temp_filename 為臨時文件名，下載完成後更名正式文件名
        temp_filename = filename + self._settings['customized_video_filename_suffix'] + '.' + temp_suffix \
                        + '.' + self._settings['video_filename_extension']
        temp_filename = Config.legalize_filename(temp_filename)
        return temp_filename

    def __segment_download_mode(self, resolution=''):
        # 設定文件存放路徑
        filename = self.__get_filename(resolution)
        merging_filename = self.__get_temp_filename(resolution, temp_suffix='MERGING')

        output_file = os.path.join(self._bangumi_dir, filename)  # 完整輸出路徑
        merging_file = os.path.join(self._temp_dir, merging_filename)

        url_path = os.path.split(self._m3u8_dict[resolution])[0]  # 用於構造完整 chunk 鏈接
        temp_dir = os.path.join(self._temp_dir, str(self._sn) + '-downloading-by-aniGamerPlus')  # 臨時目錄以 sn 命令
        if not os.path.exists(temp_dir):  # 創建臨時目錄
            os.makedirs(temp_dir)
        m3u8_path = os.path.join(temp_dir, str(self._sn) + '.m3u8')  # m3u8 存放位置
        m3u8_text = self.__request(self._m3u8_dict[resolution], no_cookies=True).text  # 請求 m3u8 文件
        with open(m3u8_path, 'w', encoding='utf-8') as f:  # 保存 m3u8 文件在本地
            f.write(m3u8_text)
            pass
        key_uri = re.search(r'(?<=AES-128,URI=")(.*)(?=")', m3u8_text).group()  # 把 key 的鏈接提取出來
        original_key_uri = key_uri

        if not re.match(r'http.+', key_uri):
            # https://github.com/miyouzi/aniGamerPlus/issues/46
            # 如果不是完整的URI
            key_uri = url_path + '/' + key_uri  # 組成完成的 URI

        m3u8_key_path = os.path.join(temp_dir, 'key.m3u8key')  # key 的存放位置
        with open(m3u8_key_path, 'wb') as f:  # 保存 key
            f.write(self.__request(key_uri, no_cookies=True).content)

        chunk_list = re.findall(r'media_b.+ts.*', m3u8_text)  # chunk

        limiter = threading.Semaphore(self._settings['multi_downloading_segment'])  # chunk 併發下載限制器
        total_chunk_num = len(chunk_list)
        finished_chunk_counter = 0
        failed_flag = False

        def download_chunk(uri):
            chunk_name = re.findall(r'media_b.+ts', uri)[0]  # chunk 文件名
            chunk_local_path = os.path.join(temp_dir, chunk_name)  # chunk 路徑
            nonlocal failed_flag

            try:
                with open(chunk_local_path, 'wb') as f:
                    f.write(self.__request(uri, no_cookies=True,
                                           show_fail=False,
                                           max_retry=self._settings['segment_max_retry']).content)
            except TryTooManyTimeError:
                failed_flag = True
                err_print(self._sn, '下載狀態', 'Bad segment=' + chunk_name, status=1)
                limiter.release()
                sys.exit(1)
            except BaseException as e:
                failed_flag = True
                err_print(self._sn, '下載狀態', 'Bad segment=' + chunk_name + ' 發生未知錯誤: ' + str(e), status=1)
                limiter.release()
                sys.exit(1)

            # 顯示完成百分比
            nonlocal finished_chunk_counter
            finished_chunk_counter = finished_chunk_counter + 1
            progress_rate = float(finished_chunk_counter / total_chunk_num * 100)
            progress_rate = round(progress_rate, 2)
            # 使用者終止任務時, 上層 download() 的等待迴圈(見下方 cancel_check 分支)不會強制中斷已經在跑的
            # 分段執行緒, 讓它們各自跑完釋放限流號誌即可; 但呼叫端(worker()/__download_only())一偵測到
            # video_size=0 就會立刻清掉 Config.tasks_progress_rate[sn] 這個監控項目, 這些被放著跑完的分段
            # 執行緒之後才寫入進度時, 項目已經不在了會拋出 KeyError——這裡只是進度顯示用途, 找不到就跳過即可
            if int(self._sn) in Config.tasks_progress_rate:
                Config.tasks_progress_rate[int(self._sn)]['rate'] = progress_rate

            if self.realtime_show_file_size:
                sys.stdout.write('\r正在下載: sn=' + str(self._sn) + ' ' + filename + ' ' + str(progress_rate) + '%  ')
                sys.stdout.flush()
            limiter.release()

        if self.realtime_show_file_size:
            # 是否實時顯示文件大小, 設計僅 cui 下載單個文件或線程數=1時適用
            sys.stdout.write('正在下載: sn=' + str(self._sn) + ' ' + filename)
            sys.stdout.flush()
        else:
            err_print(self._sn, '正在下載', filename + ' title=' + self._title)

        chunk_tasks_list = []
        for chunk in chunk_list:
            chunk_uri = url_path + '/' + chunk
            task = threading.Thread(target=download_chunk, args=(chunk_uri,))
            chunk_tasks_list.append(task)
            task.daemon = True
            limiter.acquire()
            task.start()

        for task in chunk_tasks_list:  # 等待所有任務完成
            while True:
                if failed_flag:
                    err_print(self._sn, '下載失敗', filename, status=1)
                    self.video_size = 0
                    shutil.rmtree(temp_dir, ignore_errors=True)  # 清除已下載的分段暫存檔, 避免連續失敗時暫存目錄堆積
                    return
                if self.cancel_check and self.cancel_check():
                    # 已經在下載中的分段(daemon 執行緒)不強制中斷, 讓它們各自跑完釋放限流號誌即可, 不用特地等待;
                    # 這裡只是不再繼續等待其餘分段、直接放棄, 不會走到後面的 ffmpeg 合併步驟
                    err_print(self._sn, '下載狀態', filename + ' 使用者終止任務, 中止下載', status=1)
                    self.video_size = 0
                    shutil.rmtree(temp_dir, ignore_errors=True)  # 清除已下載的分段暫存檔
                    return
                if task.is_alive():
                    time.sleep(1)
                else:
                    break

        # m3u8 本地化
        # replace('\\', '\\\\') 為轉義win路徑
        m3u8_text_local_version = m3u8_text.replace(original_key_uri, os.path.join(temp_dir, 'key.m3u8key')).replace('\\', '\\\\')
        for chunk in chunk_list:
            chunk_filename = re.findall(r'media_b.+ts', chunk)[0]  # chunk 文件名
            chunk_path = os.path.join(temp_dir, chunk_filename).replace('\\', '\\\\')  # chunk 本地路徑
            m3u8_text_local_version = m3u8_text_local_version.replace(chunk, chunk_path)
        with open(m3u8_path, 'w', encoding='utf-8') as f:  # 保存本地化的 m3u8
            f.write(m3u8_text_local_version)

        if self.realtime_show_file_size:
            sys.stdout.write('\n')
            sys.stdout.flush()
        err_print(self._sn, '下載狀態', filename + ' 下載完成, 正在解密合併……')
        Config.tasks_progress_rate[int(self._sn)]['status'] = '下載完成'

        # 構造 ffmpeg 命令
        ffmpeg_cmd = [self._ffmpeg_path,
                      '-allowed_extensions', 'ALL',
                      '-i', m3u8_path,
                      '-c', 'copy', merging_file,
                      '-y']

        if self._settings['faststart_movflags']:
            # 將 metadata 移至視頻文件頭部
            # 此功能可以更快的在線播放視頻
            ffmpeg_cmd[7:7] = iter(['-movflags', 'faststart'])

        if self._settings['audio_language']:
            if self._title.find('中文') == -1:
                ffmpeg_cmd[7:7] = iter(['-metadata:s:a:0', 'language=jpn'])
            else:
                ffmpeg_cmd[7:7] = iter(['-metadata:s:a:0', 'language=chi'])

        # 執行 ffmpeg
        run_ffmpeg = subprocess.Popen(ffmpeg_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        while run_ffmpeg.poll() is None:
            # 分段下載階段的取消只會放棄等待、不強制中斷已在跑的分段執行緒(見上面的說明), 但合併階段
            # 換成單一 ffmpeg 進程在跑, 沒有理由讓使用者取消後還乾等它跑完——比照 __ffmpeg_download_mode()
            # 的作法, 定期檢查取消旗標, 有的話直接 kill 掉並清除暫存檔, 不讓已取消的任務被當成下載完成
            if self.cancel_check and self.cancel_check():
                err_print(self._sn, '下載狀態', filename + ' 使用者終止任務, 中止合併', status=1)
                run_ffmpeg.kill()
                run_ffmpeg.wait()  # 等待進程實際結束, 釋放檔案鎖定, 才能刪除暫存檔
                self.video_size = 0
                shutil.rmtree(temp_dir, ignore_errors=True)  # 清除已下載的分段暫存檔
                if os.path.exists(merging_file):
                    os.remove(merging_file)  # 清除合併到一半的暫存檔
                return
            time.sleep(1)
        _, stderr = run_ffmpeg.communicate()

        if run_ffmpeg.returncode != 0:
            # 合併失敗(壞分段/磁碟滿等原因)不能繼續往下刪掉舊檔、把不完整的合併結果標記成功——比照
            # __ffmpeg_download_mode() 的作法, 只記錄失敗、保留原有 output_file、不更動 self.video_size
            # (維持 __init__ 的預設值 0), 讓呼叫端既有的 `video_size < 5 判定失敗` 邏輯正確觸發重試
            err_print(self._sn, '下載失敗',
                      filename + ' ffmpeg_return_code=' + str(run_ffmpeg.returncode) + ' ' + str(stderr), status=1)
            return

        # 記錄文件大小，單位為 MB
        self.video_size = int(os.path.getsize(merging_file) / float(1024 * 1024))
        # 重命名
        err_print(self._sn, '下載狀態', filename + ' 解密合併完成, 本集 ' + str(self.video_size) + 'MB, 正在移至番劇目錄……')
        if os.path.exists(output_file):
            os.remove(output_file)

        if self._settings['use_copyfile_method']:
            shutil.copyfile(merging_file, output_file)  # 適配rclone掛載盤
            os.remove(merging_file)  # 刪除臨時合併文件
        else:
            shutil.move(merging_file, output_file)  # 此方法在遇到rclone掛載盤時會出錯

        # 刪除臨時目錄
        shutil.rmtree(temp_dir, ignore_errors=True)

        self.local_video_path = output_file  # 記錄保存路徑, FTP上傳用
        self._video_filename = filename  # 記錄文件名, FTP上傳用

        err_print(self._sn, '下載完成', filename, status=2)

    def __ffmpeg_download_mode(self, resolution=''):
        # 設定文件存放路徑
        filename = self.__get_filename(resolution)
        downloading_filename = self.__get_temp_filename(resolution, temp_suffix='DOWNLOADING')

        output_file = os.path.join(self._bangumi_dir, filename)  # 完整輸出路徑
        downloading_file = os.path.join(self._temp_dir, downloading_filename)

        # 構造 ffmpeg 命令
        ffmpeg_cmd = [self._ffmpeg_path,
                      '-user_agent',
                      self._settings['ua'],
                      '-headers', "Origin: https://ani.gamer.com.tw",
                      '-i', self._m3u8_dict[resolution],
                      '-c', 'copy', downloading_file,
                      '-y']

        if os.path.exists(downloading_file):
            os.remove(downloading_file)  # 清理任務失敗的屍體

        # subprocess.call(ffmpeg_cmd, creationflags=0x08000000)  # 僅windows
        run_ffmpeg = subprocess.Popen(ffmpeg_cmd, stdout=subprocess.PIPE, bufsize=204800, stderr=subprocess.PIPE)
        cancelled_flag = threading.Event()  # 使用者取消時由 check_ffmpeg_alive() 設定, 主執行緒藉此避免
        # kill 掉的 process 讓 communicate() 回傳非 0 return code, 又額外印出一則矛盾的「下載失敗」訊息

        def check_ffmpeg_alive():
            # 應對ffmpeg卡死, 資源限速等，若 1min 中內文件大小沒有增加超過 3M, 則判定卡死
            if self.realtime_show_file_size:  # 是否實時顯示文件大小, 設計僅 cui 下載單個文件或線程數=1時適用
                sys.stdout.write('正在下載: sn=' + str(self._sn) + ' ' + filename)
                sys.stdout.flush()
            else:
                err_print(self._sn, '正在下載', filename + ' title=' + self._title)

            time.sleep(2)
            time_counter = 1
            pre_temp_file_size = 0
            while run_ffmpeg.poll() is None:

                if self.cancel_check and self.cancel_check():
                    err_print(self._sn, '下載狀態', filename + ' 使用者終止任務, 中止下載', status=1)
                    cancelled_flag.set()
                    run_ffmpeg.kill()
                    run_ffmpeg.wait()  # 等待進程實際結束, 釋放檔案鎖定, 才能刪除暫存檔
                    if os.path.exists(downloading_file):
                        os.remove(downloading_file)  # 清除下載到一半的暫存檔
                    return

                if self.realtime_show_file_size:
                    # 實時顯示文件大小
                    if os.path.exists(downloading_file):
                        size = os.path.getsize(downloading_file)
                        size = size / float(1024 * 1024)
                        size = round(size, 2)
                        sys.stdout.write(
                            '\r正在下載: sn=' + str(self._sn) + ' ' + filename + '    ' + str(size) + 'MB      ')
                        sys.stdout.flush()
                    else:
                        sys.stdout.write('\r正在下載: sn=' + str(self._sn) + ' ' + filename + '    文件尚未生成  ')
                        sys.stdout.flush()

                if time_counter % 60 == 0 and os.path.exists(downloading_file):
                    temp_file_size = os.path.getsize(downloading_file)
                    a = temp_file_size - pre_temp_file_size
                    if a < (3 * 1024 * 1024):
                        err_msg_detail = downloading_filename + ' 在一分鐘內僅增加' + str(
                            int(a / float(1024))) + 'KB 判定為卡死, 任務失敗!'
                        err_print(self._sn, '下載失敗', err_msg_detail, status=1)
                        run_ffmpeg.kill()
                        return
                    pre_temp_file_size = temp_file_size
                time.sleep(1)
                time_counter = time_counter + 1

        ffmpeg_checker = threading.Thread(target=check_ffmpeg_alive)  # 檢查線程
        ffmpeg_checker.daemon = True  # 如果 Anime 線程被 kill, 檢查進程也應該結束
        ffmpeg_checker.start()
        run = run_ffmpeg.communicate()
        return_str = str(run[1])

        if self.realtime_show_file_size:
            sys.stdout.write('\n')
            sys.stdout.flush()

        if run_ffmpeg.returncode == 0 and (return_str.find('Failed to open segment') < 0):
            # 執行成功 (ffmpeg正常結束, 每個分段都成功下載)
            if os.path.exists(output_file):
                os.remove(output_file)
            # 記錄文件大小，單位為 MB
            self.video_size = int(os.path.getsize(downloading_file) / float(1024 * 1024))
            err_print(self._sn, '下載狀態', filename + '本集 ' + str(self.video_size) + 'MB, 正在移至番劇目錄……')

            if self._settings['use_copyfile_method']:
                shutil.copyfile(downloading_file, output_file)  # 適配rclone掛載盤
                os.remove(downloading_file)  # 刪除臨時合併文件
            else:
                shutil.move(downloading_file, output_file)  # 此方法在遇到rclone掛載盤時會出錯

            self.local_video_path = output_file  # 記錄保存路徑, FTP上傳用
            self._video_filename = filename  # 記錄文件名, FTP上傳用
            err_print(self._sn, '下載完成', filename, status=2)
        elif cancelled_flag.is_set():
            # 使用者終止任務: check_ffmpeg_alive() 已經印過「使用者終止任務, 中止下載」, kill 掉的 process
            # 讓這裡的 communicate() 回傳非 0 return code, 不能再多印一則矛盾的「下載失敗」訊息誤導成真的失敗
            pass
        else:
            err_msg_detail = filename + ' ffmpeg_return_code=' + str(
                run_ffmpeg.returncode) + ' Bad segment=' + str(return_str.find('Failed to open segment'))
            err_print(self._sn, '下載失敗', err_msg_detail, status=1)

    def download(self, resolution='', save_dir='', bangumi_tag='', realtime_show_file_size=False, rename='', classify=True):
        self.realtime_show_file_size = realtime_show_file_size
        if not resolution:
            resolution = self._settings['download_resolution']

        if save_dir:
            self._bangumi_dir = save_dir  # 用於 cui 用戶指定下載在當前目錄

        # 預先保留原始標題
        self._bangumi_name_orig = self._title.replace('[' + self.get_episode() + ']', '').strip()  # 提取番劇名（去掉集數後綴）
        while self.trailing_bracket_filter.search(self._bangumi_name_orig) and not self._type_marker_filter.search(self._bangumi_name_orig):
            # 去除標題尾端殘留的 [年齡限制版]/[先行版] 等與集數無關的額外標籤, 保留 [特別篇]/[中文配音]/[電影]/[中文電影]
            # 供下方 season/extra 判斷分類子資料夾使用
            self._bangumi_name_orig = self.trailing_bracket_filter.sub('', self._bangumi_name_orig)
        self._bangumi_name_orig = re.sub(r'\s+', ' ', self._bangumi_name_orig)  # 去除重複空格

        if rename:
            bangumi_name = self._bangumi_name
            # 適配多版本的番劇
            version = re.findall(r'\[.+?\]', self._bangumi_name)  # 在番劇名中尋找是否存在多版本標記
            if version:  # 如果這個番劇是多版本的
                version = str(version[-1])  # 提取番劇版本名稱
                bangumi_name = bangumi_name.replace(version, '').strip()  # 沒有版本名稱的 bangumi_name, 且頭尾無空格
            # 如果設定重命名了番劇
            # 將其中的番劇名換成用戶設定的, 且不影響版本號後綴(如果有)
            self._title = self._title.replace(bangumi_name, rename)
            self._bangumi_name = self._bangumi_name.replace(bangumi_name, rename)

        # 下載任務開始
        Config.tasks_progress_rate[int(self._sn)] = {'rate': 0, 'filename': '《'+self.get_title()+'》', 'status': '正在解析'}

        try:
            self.__get_m3u8_dict()  # 獲取 m3u8 列表
        except TryTooManyTimeError:
            # 如果在獲取 m3u8 過程中發生意外, 則取消此次下載
            err_print(self._sn, '下載狀態', '獲取 m3u8 失敗!', status=1)
            self.video_size = 0
            return

        if self.cancel_check and self.cancel_check():
            # 使用者終止任務時, 可能是在 __get_m3u8_dict() 的裝置交握/解析階段就已經被終止(見該函式內的
            # cancel_check 檢查點), 這種情況 self._m3u8_dict 會是空的、還沒真的走到後面的分段/ffmpeg 下載,
            # 這裡要提早攔下來, 不然帶著空字典繼續往下走會在 __segment_download_mode()/__ffmpeg_download_mode()
            # 選解析度那一步噴出難以理解的 KeyError, 而不是乾淨地被判定成「使用者終止任務」
            err_print(self._sn, '下載狀態', '《' + self.get_title() + '》 使用者終止任務, 中止下載', status=1)
            self.video_size = 0
            return

        # 用 with 包住: Popen 當 context manager 使用時, 離開區塊會自動關閉 stdout/stderr 管道並 wait()
        # 該行程結束, 正確回收子行程——這裡每次 download() 呼叫都會建一個新的檢查行程, 長時間批次下載
        # (連續處理數十上百集)若不正確回收, 會累積殘留的行程/管道控制代碼
        with subprocess.Popen('ffmpeg -h', shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE) as check_ffmpeg:
            ffmpeg_in_path = bool(check_ffmpeg.stdout.readlines())  # 查找 ffmpeg 是否已放入系統 path
        if ffmpeg_in_path:
            self._ffmpeg_path = 'ffmpeg'
        else:
            # print('沒有在系統PATH中發現ffmpeg，嘗試在所在目錄尋找')
            if 'Windows' in platform.system():
                self._ffmpeg_path = os.path.join(self._working_dir, 'ffmpeg.exe')
                if not os.path.exists(self._ffmpeg_path):
                    _ensure_windows_ffmpeg(self._ffmpeg_path)  # 缺少時自動下載一份, 失敗則沿用下方既有的錯誤處理
            else:
                self._ffmpeg_path = os.path.join(self._working_dir, 'ffmpeg')
            if not os.path.exists(self._ffmpeg_path):
                err_print(0, '本項目依賴於ffmpeg, 但ffmpeg未找到', status=1, no_sn=True)
                raise FileNotFoundError  # 如果本地目錄下也沒有找到 ffmpeg 則丟出異常

        # 創建存放番劇的目錄，去除非法字符
        if bangumi_tag:  # 如果指定了番劇分類
            self._bangumi_dir = os.path.join(self._bangumi_dir, Config.legalize_filename(bangumi_tag))
        if classify:  # 控制是否建立番劇文件夾
            if self._settings['classify_season']:  # 控制是否建立番劇季度子文件夾
                season = re.findall(self.season_title_filter, self._bangumi_name_orig)
                extra = re.findall(self.extra_title_filter, self._bangumi_name_orig)
                if season:
                    season_num_string = ''.join(season).replace('第','').replace('季','')
                    season_num = self.get_season_num(season_num_string)
                    root_bangumi_dir = self._bangumi_name_orig.replace(str(season[0]),'') # remove season name for bangumi root dir
                    root_bangumi_dir = "".join(root_bangumi_dir.rstrip()) # remove tail space if exists
                    sub_dir = "Season "+str(season_num) # add season sub folder
                elif extra:
                    root_bangumi_dir = self._bangumi_name_orig.replace("["+str(extra[0])+"]",'') # remove extra name for bangumi root dir
                    root_bangumi_dir = "".join(root_bangumi_dir.rstrip()) # remove tail space if exists
                    sub_dir = "Specials" # add special sub folder if the bangumi type is "特別篇" or "中文配音"
                elif self.get_episode() == "電影":
                    root_bangumi_dir = self._bangumi_name_orig.replace("[電影]",'') # remove 電影 for bangumi root dir
                    sub_dir = "Movie" # add movie sub folder if the bangumi type is "電影"
                else:
                    root_bangumi_dir = self._bangumi_name_orig # for bangumi root dir
                    root_bangumi_dir = "".join(root_bangumi_dir.rstrip()) # remove tail space if exists
                    sub_dir = "Season 1" # as season 1 if there is no matching season
                # 如果設定重命名了番劇
                # 將其中的番劇根目錄名換成用戶設定的
                if rename:
                    root_bangumi_dir = self._bangumi_name
                self._bangumi_dir = os.path.join(self._bangumi_dir, Config.legalize_filename(root_bangumi_dir), sub_dir)
            else:
                # 未開啟季度子資料夾分類時, 沒有 Season/Specials/Movie 子資料夾可以區分類型,
                # 改用仍保留 [特別篇]/[中文配音]/[電影]/[中文電影] 標籤的 self._bangumi_name_orig 當資料夾名,
                # 避免同一部番劇的正篇/中文配音/特別篇/電影被歸進同一個資料夾 (self._bangumi_name 已不含這類標籤)
                folder_name = self._bangumi_name if rename else self._bangumi_name_orig
                self._bangumi_dir = os.path.join(self._bangumi_dir, Config.legalize_filename(folder_name))

        if not os.path.exists(self._bangumi_dir):
            try:
                os.makedirs(self._bangumi_dir)  # 按番劇創建文件夾分類
            except FileExistsError as e:
                err_print(self._sn, '下載狀態', '欲創建的番劇資料夾已存在 ' + str(e), display=False)

        if not os.path.exists(self._temp_dir):  # 建立臨時文件夾
            try:
                os.makedirs(self._temp_dir)
            except FileExistsError as e:
                err_print(self._sn, '下載狀態', '欲創建的臨時資料夾已存在 ' + str(e), display=False)

        # 如果不存在指定清晰度，則選取最近可用清晰度
        if resolution not in self._m3u8_dict.keys():
            if self._settings['lock_resolution']:
                # 如果用戶設定鎖定清晰度, 則下載取消
                err_msg_detail = '指定清晰度不存在, 因當前鎖定了清晰度, 下載取消. 可用的清晰度: ' + 'P '.join(self._m3u8_dict.keys()) + 'P'
                err_print(self._sn, '任務狀態', err_msg_detail, status=1)
                return

            resolution_list = map(lambda x: int(x), self._m3u8_dict.keys())
            resolution_list = list(resolution_list)
            flag = 9999
            closest_resolution = 0
            for i in resolution_list:
                a = abs(int(resolution) - i)
                if a < flag:
                    flag = a
                    closest_resolution = i
            # resolution_list.sort()
            # resolution = str(resolution_list[-1])  # 選取最高可用清晰度
            resolution = str(closest_resolution)
            err_msg_detail = '指定清晰度不存在, 選取最近可用清晰度: ' + resolution + 'P'
            err_print(self._sn, '任務狀態', err_msg_detail, status=1)
        self.video_resolution = int(resolution)

        # 解析完成, 開始下載
        Config.tasks_progress_rate[int(self._sn)]['status'] = '正在下載'
        Config.tasks_progress_rate[int(self._sn)]['filename'] = self.get_filename()

        if self._settings['segment_download_mode']:
            self.__segment_download_mode(resolution)
        else:
            self.__ffmpeg_download_mode(resolution)

        # 任務完成, 從任務進度表中刪除
        del Config.tasks_progress_rate[int(self._sn)]

        if self.video_size < 5:
            # __segment_download_mode()/__ffmpeg_download_mode() 內部各種失敗情況(分段壞掉、ffmpeg合併失敗、
            # 使用者主動終止等)都是直接 return, 不會拋例外, 所以這裡一定要自己檢查 video_size 才知道是不是真的
            # 下載成功——過去沒有這道判斷, 不管有沒有真的成功都照樣往下送出「下載完成 @file_size@ MB」的成功通知,
            # 使用者終止任務或下載失敗時反而會收到一則內容矛盾的「下載完成 0 MB」訊息
            if self.cancel_check and self.cancel_check():
                # 只有手動任務才有「終止任務」功能(見 aniGamerPlus.py 的 cancel_check 說明, 排程任務目前沒有
                # 對應的 UI), 額外送一則專屬的「已取消」通知; 一般性失敗則不在這裡送通知, 交給呼叫端
                # (worker()/__download_only())既有的失敗通知邏輯處理, 避免同一次失敗被兩邊各自送出一則通知
                Config.send_notification(
                    'download_manual_cancelled', '消息',
                    animation_name=self.get_bangumi_name(),
                    episode=self.get_notify_episode_display(),
                    finish_time=NotifyDB.now_str(),
                )
            return

        # 下載彈幕
        if self._danmu:
            try:
                full_filename = os.path.join(self._bangumi_dir, self.__get_filename(resolution)).replace('.' + self._settings['video_filename_extension'], '.ass')
                d = Danmu(self._sn, full_filename, Config.read_cookie())
                d.download(self._settings['danmu_ban_words'])
            except BaseException as e:
                err_print(self._sn, '彈幕異常', '下載彈幕時發生未知錯誤: '+str(e), status=1)
                err_print(self._sn, '彈幕異常', '異常詳情:\n'+traceback.format_exc(), status=1, display=False)

        # 下載完成通知: CQ/Telegram/Discord 共用同一份可自訂模板(見 NotifyDB.py), 差別只在送出管道跟語法
        category = 'download_manual_success' if self._manual else 'download_schedule_success'
        notify_now = NotifyDB.now_str()
        notify_context = dict(
            animation_name=self.get_bangumi_name(),
            episode=self.get_notify_episode_display(),
            file_size=str(self.video_size),
            download_time=notify_now,
            new_sn_time=notify_now,
            finish_time=notify_now,
        )

        # 推送 CQ 通知: CQ 沒有 Telegram HTML/Discord markdown 的分別, 借用已經轉換好的 Discord markdown 版本
        # (符號比原始 HTML 標籤更不突兀), 不需要額外的 HTML 跳脫
        if self._settings['coolq_notify']:
            try:
                msg = (Config.notify_title('消息') + '\n'
                       + NotifyDB.render_notify_message(category, 'discord', **notify_context))
                if self._settings['coolq_settings']['message_suffix']:
                    # 追加用戶信息
                    msg = msg + '\n\n' + self._settings['coolq_settings']['message_suffix']

                for query in self._settings['coolq_settings']['query']:
                    if '?' not in query:
                        query = query + '?'
                    else:
                        query = query + '&'
                    req = query + self._settings['coolq_settings']['msg_argument_name'] + '=' + quote(msg)
                    self.__request(req, no_cookies=True)
            except BaseException as e:
                err_print(self._sn, 'CQ NOTIFY ERROR', 'Exception: ' + str(e), status=1)

        # 推送 Telegram/Discord 下載完成通知(共用 Config.send_notification(), 依「通知類別」設定決定是否送出,
        # 各自的模板/HTML跳脫/markdown轉換都在 send_notification 內部處理)
        Config.send_notification(category, '消息', **notify_context)

    def upload(self, bangumi_tag='', debug_file=''):
        first_connect = True  # 標記是否是第一次連接, 第一次連接會刪除臨時緩存目錄
        tmp_dir = str(self._sn) + '-uploading-by-aniGamerPlus'

        if debug_file:
            self.local_video_path = debug_file

        if not os.path.exists(self.local_video_path):  # 如果文件不存在,直接返回失敗
            return self.upload_succeed_flag

        if not self._video_filename:  # 用於僅上傳, 將文件名提取出來
            self._video_filename = os.path.split(self.local_video_path)[-1]

        socket.setdefaulttimeout(20)  # 超時時間20s

        if self._settings['ftp']['tls']:
            ftp = FTP_TLS()  # FTP over TLS
        else:
            ftp = FTP()

        def connect_ftp(show_err=True):
            ftp.encoding = 'utf-8'  # 解決中文亂碼
            err_counter = 0
            connect_flag = False
            while err_counter <= 3:
                try:
                    ftp.connect(self._settings['ftp']['server'], self._settings['ftp']['port'])  # 連接 FTP
                    ftp.login(self._settings['ftp']['user'], self._settings['ftp']['pwd'])  # 登陸
                    connect_flag = True
                    break
                except ftplib.error_temp as e:
                    if show_err:
                        if 'Too many connections' in str(e):
                            detail = self._video_filename + ' 當前FTP連接數過多, 5分鐘後重試, 最多重試三次: ' + str(e)
                            err_print(self._sn, 'FTP狀態', detail, status=1)
                        else:
                            detail = self._video_filename + ' 連接FTP時發生錯誤, 5分鐘後重試, 最多重試三次: ' + str(e)
                            err_print(self._sn, 'FTP狀態', detail, status=1)
                    err_counter = err_counter + 1
                    for i in range(5 * 60):
                        time.sleep(1)
                except BaseException as e:
                    if show_err:
                        detail = self._video_filename + ' 在連接FTP時發生無法處理的異常:' + str(e)
                        err_print(self._sn, 'FTP狀態', detail, status=1)
                    break

            if not connect_flag:
                err_print(self._sn, '上傳失敗', self._video_filename, status=1)
                return connect_flag  # 如果連接失敗, 直接放棄

            ftp.voidcmd('TYPE I')  # 二進制模式

            if self._settings['ftp']['cwd']:
                try:
                    ftp.cwd(self._settings['ftp']['cwd'])  # 進入用戶指定目錄
                except ftplib.error_perm as e:
                    if show_err:
                        err_print(self._sn, 'FTP狀態', '進入指定FTP目錄時出錯: ' + str(e), status=1)

            if bangumi_tag:  # 番劇分類
                try:
                    ftp.cwd(bangumi_tag)
                except ftplib.error_perm:
                    try:
                        ftp.mkd(bangumi_tag)
                        ftp.cwd(bangumi_tag)
                    except ftplib.error_perm as e:
                        if show_err:
                            err_print(self._sn, 'FTP狀態', '創建目錄番劇目錄時發生異常, 你可能沒有權限創建目錄: ' + str(e), status=1)

            # 歸類番劇
            ftp_bangumi_dir = Config.legalize_filename(self._bangumi_name)  # 保證合法
            try:
                ftp.cwd(ftp_bangumi_dir)
            except ftplib.error_perm:
                try:
                    ftp.mkd(ftp_bangumi_dir)
                    ftp.cwd(ftp_bangumi_dir)
                except ftplib.error_perm as e:
                    if show_err:
                        detail = '你可能沒有權限創建目錄(用於分類番劇), 視頻文件將會直接上傳, 收到異常: ' + str(e)
                        err_print(self._sn, 'FTP狀態', detail, status=1)

            # 刪除舊的臨時文件夾
            nonlocal first_connect
            if first_connect:  # 首次連接
                remove_dir(tmp_dir)
                first_connect = False  # 標記第一次連接已完成

            # 創建新的臨時文件夾
            # 創建臨時文件夾是因為 pure-ftpd 在續傳時會將文件名更改成不可預測的名字
            # 正常中斷傳輸會把名字改回來, 但是意外掉線不會, 為了處理這種情況
            # 需要獲取 pure-ftpd 未知文件名的續傳緩存文件, 為了不和其他視頻的緩存文件混淆, 故建立一個臨時文件夾
            try:
                ftp.cwd(tmp_dir)
            except ftplib.error_perm:
                ftp.mkd(tmp_dir)
                ftp.cwd(tmp_dir)

            return connect_flag

        def exit_ftp(show_err=True):
            try:
                ftp.quit()
            except BaseException as e:
                if show_err and self._settings['ftp']['show_error_detail']:
                    err_print(self._sn, 'FTP狀態', '將強制關閉FTP連接, 因為在退出時收到異常: ' + str(e))
                ftp.close()

        def remove_dir(dir_name):
            try:
                ftp.rmd(dir_name)
            except ftplib.error_perm as e:
                if 'Directory not empty' in str(e):
                    # 如果目錄非空, 則刪除內部文件
                    ftp.cwd(dir_name)
                    del_all_files()
                    ftp.cwd('..')
                    ftp.rmd(dir_name)  # 刪完內部文件, 刪除文件夾
                elif 'No such file or directory' in str(e):
                    pass
                else:
                    # 其他非空目錄報錯
                    raise e

        def del_all_files():
            try:
                for file_need_del in ftp.nlst():
                    if not re.match(r'^(\.|\.\.)$', file_need_del):
                        ftp.delete(file_need_del)
                        # print('刪除了文件: ' + file_need_del)
            except ftplib.error_perm as resp:
                if not str(resp) == "550 No files found":
                    raise

        if not connect_ftp():  # 連接 FTP
            return self.upload_succeed_flag  # 如果連接失敗

        err_print(self._sn, '正在上傳', self._video_filename + ' title=' + self._title + '……')
        try_counter = 0
        video_filename = self._video_filename  # video_filename 將可能會儲存 pure-ftpd 緩存文件名
        max_try_num = self._settings['ftp']['max_retry_num']
        local_size = os.path.getsize(self.local_video_path)  # 本地文件大小
        while try_counter <= max_try_num:
            try:
                if try_counter > 0:
                    # 傳輸遭中斷後處理
                    detail = self._video_filename + ' 發生異常, 重連FTP, 續傳文件, 將重試最多' + str(max_try_num) + '次……'
                    err_print(self._sn, '上傳狀態', detail, status=1)
                    if not connect_ftp():  # 重連
                        return self.upload_succeed_flag

                    # 解決操蛋的 Pure-Ftpd 續傳一次就改名導致不能再續傳問題.
                    # 一般正常關閉文件傳輸 Pure-Ftpd 會把名字改回來, 但是遇到網絡意外中斷, 那麼就不會改回文件名, 留着臨時文件名
                    # 本段就是處理這種情況
                    try:
                        for i in ftp.nlst():
                            if 'pureftpd-upload' in i:
                                # 找到 pure-ftpd 緩存, 直接抓緩存來續傳
                                video_filename = i
                    except ftplib.error_perm as resp:
                        if not str(resp) == "550 No files found":  # 非文件不存在錯誤, 拋出異常
                            raise
                # 斷點續傳
                try:
                    # 需要 FTP Server 支持續傳
                    ftp_binary_size = ftp.size(video_filename)  # 遠程文件字節數
                except ftplib.error_perm:
                    # 如果不存在文件
                    ftp_binary_size = 0
                except OSError:
                    try_counter = try_counter + 1
                    continue

                ftp.voidcmd('TYPE I')  # 二進制模式
                conn = ftp.transfercmd('STOR ' + video_filename, ftp_binary_size)  # ftp服務器文件名和offset偏移地址
                with open(self.local_video_path, 'rb') as f:
                    f.seek(ftp_binary_size)  # 從斷點處開始讀取
                    while True:
                        block = f.read(1048576)  # 讀取1M
                        conn.sendall(block)  # 送出 block
                        if not block:
                            time.sleep(3)  # 等待一下, 讓sendall()完成
                            break

                conn.close()

                err_print(self._sn, '上傳狀態', '檢查遠端文件大小是否與本地一致……')
                exit_ftp(False)
                connect_ftp(False)
                # 不重連的話, 下面查詢遠程文件大小會返回 None, 懵逼...
                # sendall()沒有完成將會 500 Unknown command
                err_counter = 0
                remote_size = 0
                while err_counter < 3:
                    try:
                        remote_size = ftp.size(video_filename)  # 遠程文件大小
                        break
                    except ftplib.error_perm as e1:
                        err_print(self._sn, 'FTP狀態', 'ftplib.error_perm: ' + str(e1))
                        remote_size = 0
                        break
                    except OSError as e2:
                        err_print(self._sn, 'FTP狀態', 'OSError: ' + str(e2))
                        remote_size = 0
                        connect_ftp(False)  # 掉線重連
                        err_counter = err_counter + 1

                if remote_size is None:
                    err_print(self._sn, 'FTP狀態', 'remote_size is None')
                    remote_size = 0
                # 遠程文件大小獲取失敗, 可能文件不存在或者抽風
                # 那上面獲取遠程字節數將會是0, 導致重新下載, 那麼此時應該清空緩存目錄下的文件
                # 避免後續找錯文件續傳
                if remote_size == 0:
                    del_all_files()

                if remote_size != local_size:
                    # 如果遠程文件大小與本地不一致
                    # print('remote_size='+str(remote_size))
                    # print('local_size ='+str(local_size))
                    detail = self._video_filename + ' 在遠端為' + str(
                        round(remote_size / float(1024 * 1024), 2)) + 'MB' + ' 與本地' + str(
                        round(local_size / float(1024 * 1024), 2)) + 'MB 不一致! 將重試最多' + str(max_try_num) + '次'
                    err_print(self._sn, '上傳狀態', detail, status=1)
                    try_counter = try_counter + 1
                    continue  # 續傳

                # 順利上傳完後
                ftp.cwd('..')  # 返回上級目錄, 即退出臨時目錄
                try:
                    # 如果同名文件存在, 則刪除
                    ftp.size(self._video_filename)
                    ftp.delete(self._video_filename)
                except ftplib.error_perm:
                    pass
                ftp.rename(tmp_dir + '/' + video_filename, self._video_filename)  # 將視頻從臨時文件移出, 順便重命名
                remove_dir(tmp_dir)  # 刪除臨時目錄
                self.upload_succeed_flag = True  # 標記上傳成功
                break

            except ConnectionResetError as e:
                if self._settings['ftp']['show_error_detail']:
                    detail = self._video_filename + ' 在上傳過程中網絡被重置, 將重試最多' + str(max_try_num) + '次' + ', 收到異常: ' + str(e)
                    err_print(self._sn, '上傳狀態', detail, status=1)
                try_counter = try_counter + 1
            except TimeoutError as e:
                if self._settings['ftp']['show_error_detail']:
                    detail = self._video_filename + ' 在上傳過程中超時, 將重試最多' + str(max_try_num) + '次, 收到異常: ' + str(e)
                    err_print(self._sn, '上傳狀態', detail, status=1)
                try_counter = try_counter + 1
            except socket.timeout as e:
                if self._settings['ftp']['show_error_detail']:
                    detail = self._video_filename + ' 在上傳過程socket超時, 將重試最多' + str(max_try_num) + '次, 收到異常: ' + str(e)
                    err_print(self._sn, '上傳狀態', detail, status=1)
                try_counter = try_counter + 1

        if not self.upload_succeed_flag:
            err_print(self._sn, '上傳失敗', self._video_filename + ' 放棄上傳!', status=1)
            exit_ftp()
            return self.upload_succeed_flag

        err_print(self._sn, '上傳完成', self._video_filename, status=2)
        exit_ftp()  # 登出 FTP
        return self.upload_succeed_flag

    def get_info(self):
        err_print(self._sn, '顯示資訊')
        indent = '                    '
        err_print(0, indent+'影片標題:', '\"' + self.get_title() + '\"', no_sn=True, display_time=False)
        err_print(0, indent+'番劇名稱:', '\"' + self.get_bangumi_name() + '\"', no_sn=True, display_time=False)
        err_print(0, indent+'劇集標題:', '\"' + self.get_episode() + '\"', no_sn=True, display_time=False)
        err_print(0, indent+'參考檔名:', '\"' + self.get_filename() + '\"', no_sn=True, display_time=False)
        err_print(0, indent+'可用解析度', 'P '.join(self.get_m3u8_dict().keys()) + 'P\n', no_sn=True, display_time=False)

    def enable_danmu(self):
        self._danmu = True

    def set_resolution(self, resolution):
        self.video_resolution = int(resolution)


if __name__ == '__main__':
    a = Anime('40035')
    # print(a.get_m3u8_dict())
    a.download('360')
