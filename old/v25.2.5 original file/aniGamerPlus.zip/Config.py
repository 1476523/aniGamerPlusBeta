#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# @Time    : 2019/1/5 20:23
# @Author  : Miyouzi
# @File    : Config.py
# @Software: PyCharm

import os, json, re, sys, requests, time, random, chardet, secrets, shutil, html
import sqlite3
import socket
import threading
import subprocess
import tempfile
from contextlib import closing
from urllib.parse import quote
from urllib.parse import urlencode
import NotifyDB
import GossipDB
import AccountVault

# 你猜猜看我是 .exe 或是 .py 檔案
if getattr(sys, 'frozen', False):
    working_dir = os.path.dirname(sys.executable)
else:
    working_dir = os.path.dirname(os.path.realpath(__file__))

config_path = os.path.join(working_dir, 'config.json')
sn_list_path = os.path.join(working_dir, 'sn_list.txt')
cookie_path = os.path.join(working_dir, 'cookie.txt')
device_id_path = os.path.join(working_dir, 'device_id.txt')
dashboard_secret_key_path = os.path.join(working_dir, 'dashboard_secret.key')
# 手動任務暫存紀錄檔: 手動任務(不像排程任務會寫入 aniGamer.db)全程只存在記憶體裡, 意外關機/當機會不留痕跡地遺失
# 提交時寫入、任務終結(成功或確定放棄重試)時移除, 讓程式啟動時能還原上次意外中斷的手動任務
# 分成兩份檔案: 單集類(single/latest/largest-sn, 一次提交對應一次下載)與批次類(all/range, 一次提交會展開成多個並行下載,
# 還原時只能整批重新送出, 可能重新下載到當機前已完成的集數, 不像單集類那麼精準)
manual_single_tasks_path = os.path.join(working_dir, 'manual_single_tasks.json')
manual_batch_tasks_path = os.path.join(working_dir, 'manual_batch_tasks.json')
_manual_tasks_lock = threading.Lock()
logs_dir = os.path.join(working_dir, 'logs')
# 「監視公告」功能(v25.1.6): 三份檔案, 前兩份只寫入不刪除(永久紀錄), 第三份是實際生效中的暫存工作檔
gossip_log_path = os.path.join(working_dir, 'gossip_log.jsonl')  # 每次偵測到的 gossip 公告原文, 全部append, 永不刪除
gossip_disposition_log_path = os.path.join(working_dir, 'gossip_disposition_log.jsonl')  # 每則公告的解析/處置紀錄, 全部append, 永不刪除
gossip_pending_path = os.path.join(working_dir, 'gossip_pending.json')  # 目前生效中的臨時排程覆蓋/追蹤狀態, 完成後依保存天數清理
_gossip_files_lock = threading.Lock()

# v25.1.8: config.json/sn_list.txt/cookie.txt/device_id.txt/dashboard_secret.key/manual_*_tasks.json
# 全部改存進 aniGamer.db(各自一張表), 目的是利用 SQLite 的原子寫入根除「寫到一半當機/斷電導致檔案整個變亂碼」的問題
# (使用者曾遇到電腦意外衝突重啟後 sn_list.txt 與 config.json 整份亂碼)。logs/ 這次不動, 風險評估後留到下一版
db_path = os.path.join(working_dir, 'aniGamer.db')
_config_db_lock = threading.Lock()  # 保護以下這批新表的讀寫; 與 aniGamerPlus.py 的 db_locker(保護 anime 表)是各自獨立的鎖,
                                     # 避免 Config.py 反向 import aniGamerPlus.py 造成循環引用; 靠 sqlite3.connect 的
                                     # timeout 讓兩把鎖各自持有連線時, 對方不會立刻踩到 "database is locked"


def _get_db_connection():
    return sqlite3.connect(db_path, timeout=10)


_SINGLE_TASK_COLUMNS = ('mode', 'resolution', 'classify', 'thread', 'danmu', 'bilingual', 'rename', 'ep_range')
_BATCH_TASK_COLUMNS = _SINGLE_TASK_COLUMNS + ('completed_episodes',)


def _manual_task_values(columns, params):
    values = {
        'mode': params.get('mode'), 'resolution': params.get('resolution'),
        'classify': int(bool(params.get('classify'))), 'thread': params.get('thread'),
        'danmu': int(bool(params.get('danmu'))), 'bilingual': int(bool(params.get('bilingual'))),
        'rename': params.get('rename', ''), 'ep_range': json.dumps(params.get('ep_range') or []),
    }
    if 'completed_episodes' in columns:
        values['completed_episodes'] = json.dumps(params.get('completed_episodes') or [])
    return [values[c] for c in columns]


def _write_manual_task_row(table_name, columns, sn, params):
    col_names = ','.join(['sn'] + list(columns) + ['created_at'])
    placeholders = ','.join(['?'] * (len(columns) + 1)) + ", datetime('now','localtime')"
    with closing(_get_db_connection()) as conn:
        conn.execute('INSERT OR REPLACE INTO ' + table_name + ' (' + col_names + ') VALUES (' + placeholders + ')',
                     tuple([int(sn)] + _manual_task_values(columns, params)))
        conn.commit()


def _migrate_legacy_manual_tasks_blob(cursor, table_name, columns):
    # v25.1.8~v25.1.9 的 manual_*_tasks 表結構是 (sn, params), params 整包塞一個 JSON 字串;
    # v25.2.0 改成每個欄位各自一個 column, 這裡偵測舊結構並就地轉換(整批搬進新結構的同一張表, 不是新建一張
    # 平行的表), 沒有舊結構(全新安裝, 或已經是新結構)就直接跳過, 交給後面的 CREATE TABLE IF NOT EXISTS 處理
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (table_name,))
    if cursor.fetchone() is None:
        return
    existing_cols = {row[1] for row in cursor.execute('PRAGMA table_info(' + table_name + ')').fetchall()}
    if 'params' not in existing_cols:
        return  # 已經是新結構, 或是比這個版本更新的結構, 不需要(也不應該)轉換
    legacy_rows = cursor.execute('SELECT sn, params FROM ' + table_name).fetchall()
    cursor.execute('DROP TABLE ' + table_name)
    col_defs = ','.join(c + (' INTEGER' if c in ('classify', 'thread', 'danmu', 'bilingual') else ' TEXT')
                         for c in columns)
    cursor.execute('CREATE TABLE ' + table_name + ' (sn INTEGER PRIMARY KEY,' + col_defs + ',created_at TIMESTAMP)')
    col_names = ','.join(['sn'] + list(columns) + ['created_at'])
    placeholders = ','.join(['?'] * (len(columns) + 1)) + ", datetime('now','localtime')"
    for sn, params_json in legacy_rows:
        try:
            params = json.loads(params_json)
        except (TypeError, json.JSONDecodeError):
            continue
        cursor.execute('INSERT OR REPLACE INTO ' + table_name + ' (' + col_names + ') VALUES (' + placeholders + ')',
                        tuple([sn] + _manual_task_values(columns, params)))


def _ensure_config_tables():
    # 在 Config.py 被 import 的當下就確保這批表存在(而不是等到 read_settings() 第一次被呼叫才建表),
    # 因為 Dashboard/Server.py 在自己的模組層級就會呼叫 get_or_create_dashboard_secret_key()
    # (用來設定 app.secret_key), 不能依賴「一定先呼叫過 read_settings()」這個順序假設。
    # CREATE TABLE IF NOT EXISTS 本身冪等且便宜, 重複呼叫沒有副作用
    with closing(_get_db_connection()) as conn:
        cursor = conn.cursor()
        _do_ensure_config_tables(conn, cursor)


def _do_ensure_config_tables(conn, cursor):
    # 拆成獨立函式讓外層 _ensure_config_tables() 能用 with closing(...) 包住整個連線生命週期(確保建表過程中
    # 任何一步拋例外, 連線都會被關閉, 不會洩漏), 而不用把下面這一長串 CREATE TABLE 全部往右重新縮排一層
    #
    # 舊版(v25.1.8~v25.1.9)整包 JSON 塞進一個 content 欄位的表, 保留供 _get_config_row() 偵測並一次性轉存到
    # 下面的 config_kv(逐鍵一列), 讓 DB 瀏覽器打開時每一列都能直接看懂/直接改, 不會看到一長串難以閱讀的 blob
    cursor.execute('CREATE TABLE IF NOT EXISTS config ('
                    'id INTEGER PRIMARY KEY CHECK (id=1),'
                    'content TEXT NOT NULL,'
                    'updated_at TIMESTAMP)')
    cursor.execute('CREATE TABLE IF NOT EXISTS config_kv ('
                    'key TEXT PRIMARY KEY,'
                    'value TEXT NOT NULL,'
                    'updated_at TIMESTAMP)')
    # 舊版(v25.1.8~v25.2.0 初期)整份 sn_list.txt 塞成一個 content 欄位的表; v25.2.0 起改成 sn_list_lines
    # 逐行拆開存放(見下方), 這張表保留當作每次寫入時同步更新的備份鏡像(不是權威來源), 供意外時人工比對用
    cursor.execute('CREATE TABLE IF NOT EXISTS sn_list ('
                    'id INTEGER PRIMARY KEY CHECK (id=1),'
                    'content TEXT NOT NULL,'
                    'updated_at TIMESTAMP)')
    # sn_list_lines: sn_list.txt 逐行拆開存放, 取代整份文字塞一個欄位的做法, 讓 DB 瀏覽器打開時每一列都能直接看懂;
    # 因為 sn_list.txt 除了追蹤項目(entry)外, 還有 @分類標籤(tag)、整行註解(comment)、空白行(blank)這些單靠
    # 「一個 sn 一列」無法還原的排版資訊(使用者常拿整行註解當分類底下的小節標題, 例如 "#週一(共6部)"), 這裡改成
    # 逐「行」而不是逐「sn」存放, line_type 分辨這行原本是哪一種, 存迴文字(排程頁面文字編輯器顯示/編輯用)時
    # 才能盡量還原使用者原本的排版, 不會因為正規化而把註解/空行整批弄丟
    cursor.execute('CREATE TABLE IF NOT EXISTS sn_list_lines ('
                    'id INTEGER PRIMARY KEY AUTOINCREMENT,'
                    'sort_order INTEGER NOT NULL,'
                    'line_type TEXT NOT NULL,'  # tag / entry / comment / blank / raw
                    'sn INTEGER,'
                    'mode TEXT,'
                    'rename TEXT,'
                    'schedule_weekday INTEGER,'
                    'schedule_hour INTEGER,'
                    'schedule_minute INTEGER,'
                    'trailing_comment TEXT,'
                    'text TEXT)')
    cursor.execute('DROP TABLE IF EXISTS sn_list_view')  # v25.2.0 中途改用 sn_list_lines 取代, 這張表已不再使用
    cursor.execute('CREATE TABLE IF NOT EXISTS cookie ('
                    'id INTEGER PRIMARY KEY CHECK (id=1),'
                    'content TEXT,'
                    'last_invalid_content TEXT,'
                    'updated_at TIMESTAMP)')
    cursor.execute('CREATE TABLE IF NOT EXISTS device_id ('
                    'id INTEGER PRIMARY KEY CHECK (id=1),'
                    'device_id TEXT,'
                    'fingerprint TEXT,'
                    'created_at TIMESTAMP)')
    cursor.execute('CREATE TABLE IF NOT EXISTS dashboard_secret ('
                    'id INTEGER PRIMARY KEY CHECK (id=1),'
                    'secret_key TEXT NOT NULL)')
    # manual_*_tasks: v25.2.0 起改成每個欄位各自一個 column(而不是整包塞進 params 這個 JSON 欄位), 只有
    # ep_range/completed_episodes 這種本質上是清單的欄位還是存 JSON 文字(通常就幾個字短短一串, 不影響閱讀);
    # 先轉換可能存在的舊結構, 新結構的 CREATE TABLE IF NOT EXISTS 才不會因為表已存在而跳過建立正確欄位
    _migrate_legacy_manual_tasks_blob(cursor, 'manual_single_tasks', _SINGLE_TASK_COLUMNS)
    _migrate_legacy_manual_tasks_blob(cursor, 'manual_batch_tasks', _BATCH_TASK_COLUMNS)
    cursor.execute('CREATE TABLE IF NOT EXISTS manual_single_tasks ('
                    'sn INTEGER PRIMARY KEY,'
                    'mode TEXT,'
                    'resolution TEXT,'
                    'classify INTEGER,'
                    'thread INTEGER,'
                    'danmu INTEGER,'
                    'bilingual INTEGER,'
                    'rename TEXT,'
                    'ep_range TEXT,'
                    'created_at TIMESTAMP)')
    cursor.execute('CREATE TABLE IF NOT EXISTS manual_batch_tasks ('
                    'sn INTEGER PRIMARY KEY,'
                    'mode TEXT,'
                    'resolution TEXT,'
                    'classify INTEGER,'
                    'thread INTEGER,'
                    'danmu INTEGER,'
                    'bilingual INTEGER,'
                    'rename TEXT,'
                    'ep_range TEXT,'
                    'completed_episodes TEXT,'
                    'created_at TIMESTAMP)')
    cursor.execute('CREATE TABLE IF NOT EXISTS format_reference ('
                    'key TEXT PRIMARY KEY,'
                    'content TEXT NOT NULL,'
                    'note TEXT)')
    conn.commit()


_ensure_config_tables()
NotifyDB.seed_placeholder_reference()  # 通用字符參考列表每次啟動都覆蓋成最新內建清單, 見 NotifyDB.py
GossipDB.import_legacy_files_if_needed(gossip_log_path, gossip_disposition_log_path, gossip_pending_path)


def _flatten_config(settings_dict):
    # config.json 目前的巢狀結構最多一層(ftp/dashboard/coolq_settings/notify_categories 這幾個 dict,
    # 底下都是純量, 沒有再更深的巢狀), 這裡把這一層也展開成獨立的列, key 用 "上層.下層" 表示從屬關係,
    # 例如 dashboard.port、ftp.server, 這樣 DB 瀏覽器打開時連巢狀設定都能一眼看到值、直接改, 不用
    # 再解一層 JSON 字串。純量/清單值(例如 danmu_ban_words 這種 list)不展開, 原樣存一列
    flat = {}
    for key, value in settings_dict.items():
        if isinstance(value, dict):
            for sub_key, sub_value in value.items():
                flat[key + '.' + sub_key] = sub_value
        else:
            flat[key] = value
    return flat


def _unflatten_config(flat_dict):
    # _flatten_config() 的反向操作: 把 "上層.下層" 的 key 收回成巢狀 dict, 沒有 "." 的 key 直接當頂層純量/清單值。
    # 只靠 key 名稱本身判斷要不要收回巢狀(頂層設定鍵目前都不含 "."), 新舊資料列(展開前/展開後)同時存在時
    # 也能正確合併還原, 不需要額外的一次性搬遷步驟——config_kv 每次寫入都是整批比對砍掉多餘舊鍵(見
    # _set_config_row 的 stale_key 清理), 舊式整包塞一個 dict 的列在下一次寫入後就會被展開後的新鍵取代掉
    settings = {}
    for key, value in flat_dict.items():
        if '.' in key:
            parent, child = key.split('.', 1)
            settings.setdefault(parent, {})[child] = value
        else:
            settings[key] = value
    return settings


def _get_config_row():
    # 優先讀 config_kv(v25.2.0 起, 每個設定鍵各自一列, 巢狀設定也展開到底層各自一列); 若還是空的, 代表資料庫裡
    # 只有 v25.1.8~v25.1.9 遺留的舊版 config 表(整包塞一個 content 欄位), 讀到後就地轉存成 config_kv(舊表保留不刪除)
    with _config_db_lock:
        with closing(_get_db_connection()) as conn:
            kv_rows = conn.execute('SELECT key, value FROM config_kv').fetchall()
            legacy_row = None
            if not kv_rows:
                legacy_row = conn.execute('SELECT content FROM config WHERE id=1').fetchone()

    if kv_rows:
        flat = {key: json.loads(value) for key, value in kv_rows}
        settings = _unflatten_config(flat)
        return json.dumps(settings, ensure_ascii=False)
    if legacy_row is None:
        return None
    try:
        legacy_settings = json.loads(re.sub(r'\\', '\\\\\\\\', legacy_row[0]))
    except json.JSONDecodeError:
        return legacy_row[0]  # 內容已損毀, 原樣回傳交給呼叫端既有的錯誤處理(__read_settings_file 的 try/except)
    _set_config_row(legacy_settings)
    return legacy_row[0]


def _set_config_row(settings_dict):
    # 展開成扁平鍵值(巢狀設定也拆到底層各自一列)寫進 config_kv, 而不是整包塞成一個 JSON 字串,
    # 讓 DB 瀏覽器打開時每一列都能直接看懂/直接改
    flat = _flatten_config(settings_dict)
    with _config_db_lock:
        with closing(_get_db_connection()) as conn:
            existing_keys = {row[0] for row in conn.execute('SELECT key FROM config_kv').fetchall()}
            new_keys = set(flat.keys())
            for key, value in flat.items():
                conn.execute("INSERT OR REPLACE INTO config_kv (key, value, updated_at) "
                             "VALUES (?, ?, datetime('now','localtime'))",
                             (key, json.dumps(value, ensure_ascii=False)))
            for stale_key in existing_keys - new_keys:  # 設定升級時被移除的舊鍵(例如已下架的 Plex 功能), 同步清掉
                conn.execute('DELETE FROM config_kv WHERE key=?', (stale_key,))
            conn.commit()


def get_log_settings():
    # 供 ColorPrint.py 讀取 save_logs/quantity_of_logs 用; 刻意不呼叫 read_settings()(會觸發 __color_print,
    # 而 __color_print 最終會呼叫 ColorPrint.err_print(), 這個函式在模組匯入期就需要用到 log_settings,
    # 呼叫 read_settings() 會有循環呼叫的風險), 只做最基本的直接讀取, 讀不到就回退預設值
    settings = {'save_logs': True, 'quantity_of_logs': 7}
    content = _get_config_row()
    if content is None and os.path.exists(config_path):
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                content = f.read()
        except BaseException:
            content = None
    if content:
        try:
            parsed = json.loads(re.sub(r'\\', '\\\\\\\\', content))
            settings['save_logs'] = parsed.get('save_logs', True)
            settings['quantity_of_logs'] = parsed.get('quantity_of_logs', 7)
        except json.JSONDecodeError:
            pass
    return settings


_SN_LIST_LINE_COLUMNS = ('line_type', 'sn', 'mode', 'rename', 'schedule_weekday', 'schedule_hour',
                          'schedule_minute', 'trailing_comment', 'text')


def _parse_sn_list_lines(content, quiet=False):
    # 把 sn_list 原始文字逐「行」拆解成結構化清單(而不是逐「sn」), 這是 sn_list_lines 表的權威資料來源。
    # 逐行而非逐 sn 的原因: sn_list.txt 除了追蹤項目(entry)外, 常見還有 @分類標籤(tag)、整行都是注釋拿來當
    # 小節標題用的行(comment, 例如 "#週一(共6部)")、純粹排版用的空白行(blank)——這些若只存「一個 sn 一列」
    # 會直接遺失, 因此每一行都存一列, line_type 分辨這行原本是哪一種; 萬一遇到無法辨識的行(理論上不該發生),
    # 用 raw 類型原樣保留整行文字, 保證不會憑空遺失使用者寫的東西
    lines = []
    for raw_line in content.splitlines():
        lstripped = raw_line.lstrip()
        if lstripped.startswith('@'):
            lines.append({'line_type': 'tag', 'text': lstripped[1:].strip()})
            continue
        stripped = raw_line.strip()
        if not stripped:
            lines.append({'line_type': 'blank'})
            continue
        if stripped.startswith('#'):
            lines.append({'line_type': 'comment', 'text': stripped[1:].strip()})
            continue

        trailing_comment = None
        body = raw_line
        comment_match = re.search(r'#(.*)$', raw_line)
        if comment_match:
            trailing_comment = comment_match.group(1).strip() or None
            body = raw_line[:comment_match.start()]
        body = re.sub(r' +', ' ', body).strip()
        parts = body.split(' ')
        if not parts[0] or not re.match(r'^\d+$', parts[0]):
            lines.append({'line_type': 'raw', 'text': raw_line})
            continue

        sn = int(parts[0])
        angle_matches = re.findall(r'<[^<>]*>', body)
        star_matches = re.findall(r'\*[^*]*\*', body)
        dollar_matches = re.findall(r'\$[^$]*\$', body)
        has_duplicate_rename = len(angle_matches) > 1
        has_duplicate_schedule_tag = len(star_matches) > 1 or len(dollar_matches) > 1
        if has_duplicate_rename and not quiet:
            __color_print(0, 'sn_list設定錯誤', f'sn={sn} 存在多組 <...> 標籤, 已忽略重新命名設定',
                          status=1, no_sn=True)
        if has_duplicate_schedule_tag and not quiet:
            __color_print(0, 'sn_list設定錯誤', f'sn={sn} 存在多組 *...* 或 $...$ 標籤, 已忽略排程設定, 改為一般全數檢查',
                          status=1, no_sn=True)

        mode = None
        if len(parts) > 1 and re.match(r'^(all|latest|largest-sn)$', parts[1]):
            mode = parts[1]

        rename = ''
        if not has_duplicate_rename and re.match(r'.*<.*>.*', body):
            rename = re.findall(r'<.*>', body)[0][1:-1]

        weekday_match = None if has_duplicate_schedule_tag else re.search(r'\*([一二三四五六日])\*', body)
        time_match = None if has_duplicate_schedule_tag else re.search(r'\$(\d{1,2}):(\d{2})\$', body)
        schedule_weekday = schedule_hour = schedule_minute = None
        if weekday_match and time_match:
            hour, minute = int(time_match.group(1)), int(time_match.group(2))
            if 0 <= hour <= 23 and 0 <= minute <= 59:
                schedule_weekday = ZH_TO_WEEKDAY[weekday_match.group(1)]
                schedule_hour, schedule_minute = hour, minute
            elif not quiet:
                __color_print(0, 'sn_list排程設定錯誤',
                              f'sn={sn} 自定義時間 {hour:02d}:{minute:02d} 不合法, 已忽略排程設定, 改為一般全數檢查',
                              status=1, no_sn=True)
        elif (weekday_match or time_match) and not quiet:
            __color_print(0, 'sn_list排程設定錯誤', f'sn={sn} 自定義星期與自定義時間必須同時填寫, 已忽略排程設定, 改為一般全數檢查',
                          status=1, no_sn=True)

        lines.append({
            'line_type': 'entry', 'sn': sn, 'mode': mode, 'rename': rename,
            'schedule_weekday': schedule_weekday, 'schedule_hour': schedule_hour,
            'schedule_minute': schedule_minute, 'trailing_comment': trailing_comment,
        })
    return lines


def _render_sn_list_lines(rows):
    # _parse_sn_list_lines() 的反向操作: 把結構化的行清單組回 sn_list.txt 格式的文字, 供排程頁面文字編輯器
    # 顯示/編輯用。不保證跟使用者原始輸入逐字元一致(例如多餘空格會被normalize掉), 但每一行的「種類」與
    # 內容(標籤/追蹤項目/注釋/空行)都會保留, 不會整批消失
    out = []
    for row in rows:
        lt = row['line_type']
        if lt == 'tag':
            out.append('@' + (row.get('text') or ''))
        elif lt == 'comment':
            out.append('#' + (row.get('text') or ''))
        elif lt == 'blank':
            out.append('')
        elif lt == 'raw':
            out.append(row.get('text') or '')
        elif lt == 'entry':
            parts = [str(row['sn'])]
            if row.get('mode'):
                parts.append(row['mode'])
            line = ' '.join(parts)
            if row.get('rename'):
                line += ' <' + row['rename'] + '>'
            if row.get('schedule_weekday') and row.get('schedule_hour') is not None:
                line += ' *' + WEEKDAY_TO_ZH[row['schedule_weekday']] + '*'
                line += ' $%02d:%02d$' % (row['schedule_hour'], row['schedule_minute'])
            if row.get('trailing_comment'):
                line += ' #' + row['trailing_comment']
            out.append(line)
    return '\n'.join(out)


def _get_sn_list_row():
    with _config_db_lock:
        with closing(_get_db_connection()) as conn:
            rows = conn.execute('SELECT ' + ','.join(_SN_LIST_LINE_COLUMNS) +
                                 ' FROM sn_list_lines ORDER BY sort_order').fetchall()
            legacy_row = None
            if not rows:
                legacy_row = conn.execute('SELECT content FROM sn_list WHERE id=1').fetchone()

    if rows:
        return _render_sn_list_lines([dict(zip(_SN_LIST_LINE_COLUMNS, r)) for r in rows])
    if legacy_row is None:
        return None
    # 資料庫裡只有 v25.1.8~v25.2.0 初期遺留的舊版 sn_list 表(整份文字塞一個 content 欄位):
    # 讀到後就地轉存成 sn_list_lines(舊表保留不刪除)
    _set_sn_list_row(legacy_row[0])
    return legacy_row[0]


def _set_sn_list_row(content):
    content = content or ''
    lines = _parse_sn_list_lines(content)
    with _config_db_lock:
        with closing(_get_db_connection()) as conn:
            conn.execute('DELETE FROM sn_list_lines')
            for i, line in enumerate(lines):
                conn.execute(
                    'INSERT INTO sn_list_lines (sort_order, line_type, sn, mode, rename, schedule_weekday, '
                    'schedule_hour, schedule_minute, trailing_comment, text) VALUES (?,?,?,?,?,?,?,?,?,?)',
                    (i, line['line_type'], line.get('sn'), line.get('mode'), line.get('rename'),
                     line.get('schedule_weekday'), line.get('schedule_hour'), line.get('schedule_minute'),
                     line.get('trailing_comment'), line.get('text')))
            # sn_list 表同步保留一份原始文字備份鏡像(非權威來源, 純粹供意外時人工比對, 見 _ensure_config_tables 的說明)
            conn.execute("INSERT OR REPLACE INTO sn_list (id, content, updated_at) "
                         "VALUES (1, ?, datetime('now','localtime'))", (content,))
            conn.commit()


def _get_cookie_row():
    # 回傳 (content, last_invalid_content, updated_at) 或 None(尚無資料列)
    with _config_db_lock:
        with closing(_get_db_connection()) as conn:
            row = conn.execute('SELECT content, last_invalid_content, updated_at FROM cookie WHERE id=1').fetchone()
    return row


def _set_cookie_content(content):
    # 寫入有效 cookie 內容, 同步更新 updated_at(取代原本檔案 mtime 的角色, 只在真的寫入新內容時更新)
    with _config_db_lock:
        with closing(_get_db_connection()) as conn:
            conn.execute("INSERT INTO cookie (id, content, updated_at) VALUES (1, ?, datetime('now','localtime')) "
                         "ON CONFLICT(id) DO UPDATE SET content=excluded.content, updated_at=excluded.updated_at",
                         (content,))
            conn.commit()


def _mark_cookie_invalid():
    # 取代原本「將 cookie.txt 更名為 invalid_cookie.txt」的除錯用途: 把目前內容搬進 last_invalid_content 保留供人工檢查,
    # 同時清空 content, 讓下次 read_cookie() 視同沒有有效 cookie(等同於原本「檔案已被搬走」的效果)
    with _config_db_lock:
        with closing(_get_db_connection()) as conn:
            row = conn.execute('SELECT content FROM cookie WHERE id=1').fetchone()
            current_content = row[0] if row else None
            conn.execute("INSERT INTO cookie (id, content, last_invalid_content, updated_at) "
                         "VALUES (1, '', ?, datetime('now','localtime')) "
                         "ON CONFLICT(id) DO UPDATE SET content='', last_invalid_content=excluded.last_invalid_content, "
                         "updated_at=excluded.updated_at", (current_content,))
            conn.commit()


def _get_device_id_row():
    # 回傳 (device_id, fingerprint, created_at) 或 None(尚無資料列)
    with _config_db_lock:
        with closing(_get_db_connection()) as conn:
            row = conn.execute('SELECT device_id, fingerprint, created_at FROM device_id WHERE id=1').fetchone()
    return row


def _set_device_id_row(new_device_id, fingerprint):
    with _config_db_lock:
        with closing(_get_db_connection()) as conn:
            conn.execute("INSERT INTO device_id (id, device_id, fingerprint, created_at) "
                         "VALUES (1, ?, ?, datetime('now','localtime')) "
                         "ON CONFLICT(id) DO UPDATE SET device_id=excluded.device_id, fingerprint=excluded.fingerprint, "
                         "created_at=excluded.created_at", (new_device_id, fingerprint))
            conn.commit()


aniGamerPlus_version = 'v25.2.5'


def notify_title(suffix):
    # 通知訊息開頭的標題, 統一帶上「客製強化版」與目前版本號, 例如 notify_title('消息') ->
    # '【aniGamerPlus 客製強化版 v25.2.0 消息】', 避免各處各自組字串導致版本號更新時漏改或格式不一致
    return '【aniGamerPlus 客製強化版 ' + aniGamerPlus_version + ' ' + suffix + '】'
latest_config_version = 18.3  # v25.2.1 新增 system_path_unreachable 通知類別、check_prerelease_version/
                               # skipped_version_tag/skipped_prerelease_tag/custom_dir_shortcuts 四個欄位;
                               # v25.2.2 再新增 skipped_version_hash/skipped_prerelease_hash/download_retry_count 三個欄位;
                               # v25.2.3 再新增 debug_mode(隱藏除錯開關, 見 is_debug_mode_enabled()/toggle_debug_mode());
                               # 再新增 download_manual_cancelled 通知類別(手動任務被使用者主動終止時發送, 取代過去
                               # 誤發送「下載完成 0 MB」成功通知的問題, 見 Anime.py download() 的說明)
                               # 前一次(17.5→17.6)就是因為忘了調高這個值才補的教訓, 這裡照著提醒調高——之後新增任何
                               # __update_settings() 裡的欄位補完邏輯, 都要記得同步調高這個版本號
latest_database_version = 3.1  # v25.1.8: 新增 config/sn_list/cookie/device_id/dashboard_secret/manual_*_tasks/
                                # format_reference 這幾張表; v25.2.0: config/sn_list/manual_*_tasks 內部改成逐欄位
                                # 存放(config_kv 取代整包 JSON 的 config 表, 巢狀設定如 dashboard/ftp 也展開到底層
                                # 各自一列; sn_list_lines 取代整份文字塞一個欄位的 sn_list 表, 逐「行」存放以保留
                                # @分類標籤/整行注釋/空行; manual_*_tasks 拆成真正的欄位), 新增
                                # gossip_log/gossip_events/gossip_pending(見 GossipDB.py, 取代舊版
                                # gossip_*.jsonl/json 三份散落檔案)——這些建表/轉存動作都在 Config.py/GossipDB.py
                                # import 時的 _ensure_config_tables()/_ensure_tables() 完成, 這裡只是讓
                                # __update_database() 印出版本升級訊息並保持版本號語意一致
cookie = None
_last_cookie_refresh_time = 0.0  # 上次執行「登入cookie刷新」的時間戳記, 用於限流
_cookie_refresh_lock = threading.Lock()
cookie_refresh_min_interval = 90  # 登入cookie刷新最小間隔(秒), 避免短時間內被誤觸發多次而遭判定為異常使用行為
device_id = None
_device_id_lock = threading.Lock()
max_multi_thread = 5
max_multi_downloading_segment = 5
tasks_progress_rate = {}  # 儲存任務進度, 供面板使用,
# 格式: {sn: {'rate': 任務進度百分比(float), 'status': 任務狀態, 'filename': 文件名} }
# 任務狀態有:  '正在下載' '正在解密合併' '正在移至番劇目錄' '任務失敗, 等待重啓' '等待下載'

# 排程下載連續失敗次數(v25.2.2 新增), 格式: {ep_sn: int}。每次 aniGamerPlus.py 的 worker() 下載失敗時 +1,
# 下載成功時歸零(從字典移除); _start_queued_workers() 排入下載執行緒前會檢查, 達到 settings['download_retry_count']
# 就不再啟動這個 ep_sn 的下載(直接從 queue 移除), 避免 Cookie 過期這類持續性錯誤被每次排程檢查無限重試、
# 對動畫瘋送出大量注定失敗的請求。Dashboard 儲存新 Cookie 時(見 /cookie 路由)會清空這個字典, 讓所有項目
# 重新獲得完整的重試次數——這是設計上刻意配合的行為: 使用者更新 Cookie 通常就是為了解決這類卡住的下載
download_failure_counts = {}
# 保護 download_failure_counts 的讀取-修改-寫回(+1)與 /cookie 路由的整批 clear() 這兩種操作,
# 避免 worker() 正在讀舊值準備 +1 寫回的同一瞬間, 使用者剛好更新 Cookie 觸發 clear(), 讓 clear() 的
# 效果被那筆還沒寫回的 +1 部分蓋掉(使用者原本預期重置成 0, 結果變成 1)——單純的 dict[key]=value 賦值
# 本身雖然是原子操作, 但這裡是「先讀、算好新值、再寫回」的複合操作, 中間有機會被其他執行緒插隊
download_failure_counts_lock = threading.Lock()

# 已經印過「任務暫停...已連續失敗」訊息、通知過使用者的 sn 集合(v25.2.3 新增)。找到更新後持續追蹤下載結果
# 的機制(aniGamerPlus.py 的 _scheduled_check_worker)每 30 秒才會重新檢查一次, 若沒有這個集合擋著,
# 同一個已經暫停中的 sn 會每 30 秒被 _start_queued_workers() 重新判斷一次、重複印出同一則暫停訊息,
# 最長可以連續洗版到 _scheduled_retry_deadline(2 小時)——這裡只用來擋「重複印訊息」, 不影響
# download_failure_counts 本身的暫停判斷邏輯; 下載成功或使用者更新 Cookie(見 download_failure_counts
# 的說明與 Dashboard /cookie 路由)時都要跟 download_failure_counts 同步清空, 讓下次再暫停時能重新通知一次
download_paused_notified = set()

# 維護模式: 執行「取得當前新番更新時間」等需要獨佔網路資源的 Dashboard 操作時設置,
# 主循環與自訂排程背景執行緒會暫停排入新的檢查/下載任務(不影響已在進行中的任務), 操作結束後清除
maintenance_mode = threading.Event()

# 「取得當前新番更新時間」背景任務的進度與結果, 供 Dashboard 輪詢
# 格式: {'status': 'idle'|'running'|'done'|'cancelled'|'error', 'total': int, 'done': int,
#        'current_sn': int, 'current_title': str, 'results': [...], 'cancel': bool, 'error': str}
schedule_scan_state = {'status': 'idle'}

# 「資料庫整頓」背景任務的進度與結果, 供 Dashboard 輪詢, 格式同上(以 'removed' 取代 'results')
db_cleanup_state = {'status': 'idle'}

# 「掃描集數」背景任務的進度與結果, 供 Dashboard 輪詢
# 格式: {'status': 'idle'|'running'|'done'|'cancelled'|'error', 'sn': int, 'anime_name': str,
#        'groups': {'main': [...], 'dub': [...], 'special': [...]}, 'cancel': bool, 'error': str}
# 每個 group 內為 [{'label': 原始集數標籤(提交用), 'display': 補零/半集格式化後顯示用文字}, ...]
episode_scan_state = {'status': 'idle'}

# 「快速取得Cookie / UA-JA3-Akamai」背景任務的進度與結果, 供 Dashboard 輪詢
# 格式: {'status': 'idle'|'running'|'done'|'cancelled'|'error', 'pid': int(子行程PID, 供取消時精準關閉整棵行程樹用),
#        'value': str(cookie 模式), 'ua'/'ja3'/'akamai': str(fingerprint 模式), 'error': str}
quick_fetch_state = {'status': 'idle'}

# 「重新檢查排程更新」背景任務的進度與結果, 供 Dashboard 輪詢
# 格式: {'status': 'idle'|'running'|'awaiting_confirmation'|'done'|'cancelled'|'error',
#        'phase': 'checking'|'awaiting_confirmation'|'downloading',
#        'total_sn': int, 'checked_sn': int, 'current_sn': int,
#        'candidates': [{'ep_sn': int, 'series_sn': int, 'anime_name': str,
#                        'episode_display': str, 'title': str}, ...],   # 檢查階段找到、等待使用者逐項決定的更新
#        'tasks': [{'ep_sn': int, 'series_sn': int, 'status': str, 'rate': float, 'filename': str}, ...],
#        'marked_done': [{'ep_sn': int, 'title': str}, ...],            # 使用者選擇「標記為已下載」而未實際下載的集數
#        'total_progress': int(0~100), 'cancel': bool, 'error': str}
full_recheck_state = {'status': 'idle'}

# 下載目錄/暫存目錄設定的是網路磁碟/UNC 路徑時, NAS 關機或網路斷線期間 read_settings() 會暫時退回程式所在
# 資料夾底下的預設目錄(見 read_settings() 對 bangumi_dir/temp_dir 的處理), 過去這個退回完全沒有任何提示,
# 檔案可能悄悄下載到本機而使用者毫無所覺; 這裡把當下狀態記下來供通知與 Dashboard 顯示
# 格式: {'bangumi_dir_unreachable': bool, 'temp_dir_unreachable': bool,
#        'configured_bangumi_dir': str, 'configured_temp_dir': str,
#        'fallback_bangumi_dir': str, 'fallback_temp_dir': str}
path_fallback_state = {'bangumi_dir_unreachable': False, 'temp_dir_unreachable': False,
                        'configured_bangumi_dir': '', 'configured_temp_dir': '',
                        'fallback_bangumi_dir': '', 'fallback_temp_dir': ''}
_path_fallback_notified = set()  # 已針對哪些欄位送過「連不到」通知(reachable->unreachable 邊緣觸發一次), 恢復後清除

# 檢查最新版本的結果快取: 啟動時檢查一次, 之後由 aniGamerPlus.py 的 _version_check_worker() 每 10 分鐘更新一次,
# 供 Dashboard 的 /data/update_check/status 讀取(過去只印在主控台與 Telegram/Discord, 網頁上完全看不到)
# 格式: {'checked_at': str, 'update_available': bool, 'is_prerelease': bool, 'tag_name': str, 'body': str(純文字),
#        'body_html': str(供 Dashboard 彈窗顯示, 保留 <details> 摺疊), 'body_hash': str(內容雜湊, 供偵測
#        使用者略過此版本通知後 GitHub 上內容是否又被編輯過), 'html_url': str, 'notified_tag': str}
update_check_state = {'checked_at': '', 'update_available': False, 'is_prerelease': False,
                       'tag_name': '', 'body': '', 'body_html': '', 'body_hash': '',
                       'html_url': '', 'notified_tag': ''}

# 手動批次任務(Dashboard 手動任務的 all/range 下載模式)的進度與結果, 供 Dashboard 輪詢並提供失敗重試/終止
# 純記憶體狀態(不落地存檔), 程式重啟即重置, 跟 full_recheck_state 同等級
# {str(batch_sn): {'anime_name': str, 'status': 'running'|'done', 'cancel': bool,
#                   'tasks': [{'ep_sn': int, 'label': str, 'status': str, 'rate': float, 'filename': str}, ...],
#                   'total_progress': int(0~100)}}
manual_batch_progress = {}

# 手動單集任務(Dashboard 手動任務的 single/latest/largest-sn 下載模式)的進度與結果(v25.2.2 新增),
# 供 Dashboard 輪詢並提供失敗重試, 補上過去單集任務只有送出當下一個「已提交」提示、下載真正成功或失敗
# 完全看不到結果的缺口(批次模式一直都有這個進度視窗, 這裡是讓單集模式跟進同樣的體驗)。
# 純記憶體狀態(不落地存檔), 程式重啟即重置, 跟 manual_batch_progress 同等級
# key 用「使用者提交當下輸入的 sn」(latest/largest-sn 模式下不等於實際下載的那一集, 見 aniGamerPlus.py
# __cui() 的解析邏輯——提交當下只知道這個值, 還沒解析出最終集數, 沒辦法拿還沒算出來的值當 key)
# {str(sn): {'anime_name': str, 'filename': str, 'status': 'running'|'done'|'failed'|'cancelled', 'rate': float,
#            'cancel': bool, 'ep_sn': int(實際下載的集數), '_dl_params': {...}}}
manual_single_progress = {}

# 排程下載插隊用: 手動批次任務進行期間, 若排程檢查(含自訂排程/「重新檢查所有排程更新」)偵測到新更新,
# 會把新啟動的那幾個 sn 記在這裡; 只要這個集合不是空的, 批次類手動任務就會暫停啟動新的下載(見 __download_only()
# 的 defer_for_priority), 直到排程那幾個任務全部處理完(不論成功失敗)才會被清空、手動任務才會繼續。
# 純記憶體狀態, 不落地存檔; 跟 tasks_progress_rate 同等級, 不另外上鎖(GIL 保護下的 set 加/刪/長度判斷已足夠)
scheduled_priority_pending_sns = set()


def scheduled_priority_active():
    return bool(scheduled_priority_pending_sns)


WEEKDAY_TO_ZH = {1: '一', 2: '二', 3: '三', 4: '四', 5: '五', 6: '六', 7: '日'}
ZH_TO_WEEKDAY = {v: k for k, v in WEEKDAY_TO_ZH.items()}


def __color_print(sn, err_msg, detail='', status=0, no_sn=False, display=True):
    # 避免與 ColorPrint.py 相互調用產生問題
    try:
        err_print(sn, err_msg, detail=detail, status=status, no_sn=no_sn, display=display)
    except UnboundLocalError:
        from ColorPrint import err_print
        err_print(sn, err_msg, detail=detail, status=status, no_sn=no_sn, display=display)


def get_max_multi_thread():
    return max_multi_thread


def legalize_filename(filename):
    # 文件名合法化
    legal_filename = re.sub(r'\|+', '｜', filename)  # 處理 | , 轉全型｜
    legal_filename = re.sub(r'\?+', '？', legal_filename)  # 處理 ? , 轉中文 ？
    legal_filename = re.sub(r'\*+', '＊', legal_filename)  # 處理 * , 轉全型＊
    legal_filename = re.sub(r'<+', '＜', legal_filename)  # 處理 < , 轉全型＜
    legal_filename = re.sub(r'>+', '＞', legal_filename)  # 處理 < , 轉全型＞
    legal_filename = re.sub(r'\"+', '＂', legal_filename)  # 處理 " , 轉全型＂
    legal_filename = re.sub(r':+', '：', legal_filename)  # 處理 : , 轉中文：
    legal_filename = re.sub(r'\\', '＼', legal_filename)  # 處理 \ , 轉全型＼
    legal_filename = re.sub(r'/', '／', legal_filename)  # 處理 / , 轉全型／
    return legal_filename


def get_working_dir():
    return working_dir


def get_config_path():
    return config_path


def get_sn_list_content():
    # 返回 sn_list 所有內容, 包括註釋, 提供給 Web 控制台
    return _get_sn_list_content_lazy()


def __init_settings():
    settings = {'bangumi_dir': '',
                'temp_dir': '',
                'custom_dir_shortcuts': [],  # Dashboard「選擇目錄」瀏覽器裡使用者自訂的喜好路徑(常見於網路路徑,
                                             # 因為那種路徑沒有磁碟機代號可以列出來, 存起來才能重複使用不用每次手打)
                'classify_bangumi': True,  # 控制是否建立番劇目錄
                'classify_season': False,  # 控制是否建立季度子目錄
                'check_frequency': 5,  # 檢查 cd 時間, 單位分鐘
                'download_cd': 60,  # 下載冷卻時間(秒)
                'download_retry_count': 5,  # 排程下載連續失敗幾次後暫停自動重試(見 download_failure_counts
                                            # 的說明), 避免 Cookie 過期等持續性錯誤被無限重試洗版; 更新 Cookie
                                            # (Dashboard「Cookie」欄位存檔)後會自動重置, 重新給所有項目機會
                'parse_sn_cd': 5,  # sn 頁面(即播放界面)解析冷卻時間
                'download_resolution': '1080',  # 下載分辨率
                'lock_resolution': False,  # 鎖定分辨率, 如果分辨率不存在, 則宣佈下載失敗
                'only_use_vip': False,  # 鎖定 VIP 賬號下載
                'default_download_mode': 'latest',  # 僅下載最新一集，另一個模式是 'all' 下載所有及日後更新
                'use_copyfile_method': False,  # 轉移視頻至番劇目錄時是否使用複製法, 使用 True 以兼容 rclone 掛載盤
                'multi-thread': 1,  # 最大併發下載數
                'multi_upload': 3,  # 最大併發上傳數
                'segment_download_mode': True,  # 由 aniGamerPlus 下載分段, False 為 ffmpeg 下載
                'multi_downloading_segment': 2,  # 在上面配置為 True 時有效, 每個視頻併發下載分段數
                'segment_max_retry': 8,  # 在分段下載模式時有效, 每個分段最大重試次數, -1 為 無限重試
                'add_bangumi_name_to_video_filename': True,
                'add_resolution_to_video_filename': True,  # 是否在文件名中添加清晰度說明
                'customized_video_filename_prefix': '【動畫瘋】',  # 用戶自定前綴
                'debug_mode': False,  # 隱藏除錯開關(v25.2.3): 不做成一般設定項按鈕, 由 Dashboard「影片檔名前綴」
                                       # 輸入框輸入 toc.icu 並按 Enter 觸發切換(見 aniGamerPlus.js), 開啟時額外印出
                                       # cookie 讀取/刷新流程的診斷訊息(見 Anime.py __init__、Config.read_cookie())
                'customized_bangumi_name_suffix': '',  # 用戶自定義番劇名後綴 (在劇集名之前)
                'customized_video_filename_suffix': '',  # 用戶自定後綴
                'video_filename_extension': 'mp4',  # 視頻擴展名/封裝格式
                'zerofill': 1,  # 劇集名補零, 此項填補足位數, 小於等於 1 即不補零
                # cookie的自動刷新對 UA 有檢查
                'ua': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36",
                # ja3/akamai 指紋(可空), 若填寫需與取得 cookie 的瀏覽器一致(可用 ja3.zone/check 採集), 用於取代 curl_cffi 內建的罐頭指紋
                'ja3': '',
                'akamai': '',
                'use_proxy': False,
                'proxy': 'http://user:passwd@example.com:1000',  # 代理功能, config_version v13.0 刪除鏈式代理
                "no_proxy_akamai": False,  # 不代理 akamai CDN
                'upload_to_server': False,
                'ftp': {  # 將文件上傳至遠程服務器
                    'server': '',
                    'port': '',
                    'user': '',
                    'pwd': '',
                    'tls': True,
                    'cwd': '',  # 文件存放目錄, 登陸後首先進入的目錄
                    'show_error_detail': False,
                    'max_retry_num': 15
                },
                'user_command': 'shutdown -s -t 60',
                'coolq_notify': False,
                'coolq_settings': {
                    'msg_argument_name': 'message',
                    'message_suffix': '追加的資訊',
                    'query': [
                        'http://127.0.0.1:5700/send_group_msg?access_token=abc&group_id=12345678',
                        'http://127.0.0.1:5700/send_group_msg?access_token=abc&group_id=87654321'
                    ]
                },
                'telebot_notify': False,
                'telebot_token': "",
                'telebot_use_chat_id': False,
                'telebot_chat_id': "",
                'discord_notify': False,
                'discord_token': '',
                # 通知類別開關: Telegram/Discord 共用同一組(兩邊都靠 send_notification() 統一判斷是否要送出),
                # 預設全開以維持舊版「只要開啟 telebot_notify/discord_notify 就一定收到下載完成通知」的既有行為
                'notify_categories': {
                    'download_manual_success': True,
                    'download_manual_failed': True,
                    'download_manual_cancelled': True,
                    'download_schedule_success': True,
                    'download_schedule_failed': True,
                    'gossip_pause': True,
                    'gossip_delay': True,
                    'gossip_extra_episode': True,
                    'gossip_other': True,
                    'system_cookie_invalid': True,
                    'system_device_error': True,
                    'system_new_version': True,
                    'system_daily_digest': True,
                    'system_path_unreachable': True,
                },
                'faststart_movflags': False,
                'audio_language': False,
                'use_mobile_api': False,
                'danmu': False,
                'danmu_ban_words': [],
                'check_latest_version': True,  # 是否檢查最新版本(啟動時 + 每 10 分鐘定期)
                'check_prerelease_version': True,  # 是否一併檢查 GitHub 上的預告版本(pre-release)
                'skipped_version_tag': '',  # 使用者按下「略過此版本通知」的正式版 tag(只抑制自動彈窗)
                'skipped_prerelease_tag': '',  # 同上, 預告版本各自獨立略過
                'skipped_version_hash': '',  # 略過當下的內容雜湊(見 Config.update_check_state['body_hash']),
                'skipped_prerelease_hash': '',  # tag 沒變但 GitHub 上內容被編輯過時, 雜湊對不上就視為新內容重新提示
                'read_sn_list_when_checking_update': True,
                'read_config_when_checking_update': True,
                'ads_time': 25,
                'mobile_ads_time': 25,
                'use_dashboard': True,
                'dashboard': {
                    'host': '127.0.0.1',
                    'port': 5000,
                    'SSL': False,
                    'BasicAuth': False,
                    'username': 'admin',
                    'password': 'admin'
                },
                'save_logs': True,
                'quantity_of_logs': 7,
                'gossip_monitor': False,
                'gossip_retention_days': 30,
                'gossip_dynamic_schedule': False,
                'config_version': latest_config_version,
                'database_version': latest_database_version
                }
    _set_config_row(settings)
    return settings


def __update_settings(old_settings):  # 升級配置文件
    new_settings = old_settings.copy()
    if 'check_latest_version' not in new_settings.keys():  # v2.0 新增檢查更新開關
        new_settings['check_latest_version'] = True

    if 'tls' not in new_settings['ftp'].keys():  # v2.0 新增 FTP over TLS 開關
        new_settings['ftp']['tls'] = True

    if 'upload_to_server' not in new_settings.keys():  # v2.0 新增上傳開關
        new_settings['upload_to_server'] = False

    if 'use_proxy' not in new_settings.keys():  # v2.0 新增代理開關
        new_settings['use_proxy'] = False

    if 'show_error_detail' not in new_settings['ftp'].keys():  # v2.0 新增顯示FTP傳輸錯誤開關
        new_settings['ftp']['show_error_detail'] = False

    if 'max_retry_num' not in new_settings['ftp'].keys():  # v2.0 新增顯示FTP重傳嘗試數
        new_settings['ftp']['max_retry_num'] = 10

    if 'read_sn_list_when_checking_update' not in new_settings.keys():  # v2.0 新增開關: 每次檢查更新時讀取sn_list
        new_settings['read_sn_list_when_checking_update'] = True

    if 'multi_upload' not in new_settings.keys():  # v2.0 新增最大並行上傳任務數
        new_settings['multi_upload'] = 3

    if 'read_config_when_checking_update' not in new_settings.keys():  # v2.0 新增開關: 每次檢查更新時讀取config.json
        new_settings['read_config_when_checking_update'] = True

    if 'add_bangumi_name_to_video_filename' not in new_settings.keys():  # v3.0 新增開關, 文件名可以單純用劇集命名
        new_settings['add_bangumi_name_to_video_filename'] = True

    if 'segment_download_mode' not in new_settings.keys():  # v3.1 新增分段下載模式開關
        new_settings['segment_download_mode'] = True

    if 'multi_downloading_segment' not in new_settings.keys():  # v3.1 新增分段下載模式下每個視頻併發下載分段數
        new_settings['multi_downloading_segment'] = 2

    new_settings['database_version'] = latest_database_version  # v3.2 新增數據庫版本號

    if 'save_logs' not in new_settings.keys():  # v4.0 新增日誌開關
        new_settings['save_logs'] = True

    if 'quantity_of_logs' not in new_settings.keys():  # v4.0 新增日誌數量配置(一天一日誌)
        new_settings['quantity_of_logs'] = 7

    if 'temp_dir' not in new_settings.keys():  # v4.0 新增緩存目錄選項
        new_settings['temp_dir'] = ''

    if 'lock_resolution' not in new_settings.keys():
        new_settings['lock_resolution'] = False  # v4.1 新增分辨率鎖定開關

    if 'ua' not in new_settings.keys():  # v4.2 新增 UA 配置
        new_settings['ua'] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.96 Safari/537.36"

    if 'classify_bangumi' not in new_settings.keys():
        new_settings['classify_bangumi'] = True  # v5.0 新增是否建立番劇目錄開關

    if 'classify_season' not in new_settings.keys():
        new_settings['classify_season'] = False  # 新增是否建立番劇季度子目錄

    if 'use_copyfile_method' not in new_settings.keys():
        # v6.0 新增視頻轉移方法開關, 配置 True 以適配 rclone 掛載盤
        new_settings['use_copyfile_method'] = False

    if 'zerofill' not in new_settings.keys():
        # v6.0 新增劇集名補零, 該項數字為補足位數, 默認為 1, 小於等於 1 即不補 0
        new_settings['zerofill'] = 1

    if 'customized_bangumi_name_suffix' not in new_settings.keys():
        # v7.0 新增自定義番劇名後綴
        new_settings['customized_bangumi_name_suffix'] = ''

    if 'user_command' not in new_settings.keys():
        # v8.0 新增命令行模式完成後, 執行自定義命令
        # 默認命令為一分鐘後關機
        new_settings['user_command'] = 'shutdown -s -t 60'

    if 'segment_download_max_retry' not in new_settings.keys():
        # v9.0 新增分段模式下, 分段重試次數
        new_settings['segment_max_retry'] = 8

    if 'coolq_notify' not in new_settings.keys():
        # v9.0 新增推送通知到CQ的功能
        new_settings['coolq_notify'] = False
        new_settings['coolq_settings'] = {
            'host': '127.0.0.1',
            'port': '5700',
            'SSL': False,
            'api': 'send_group_msg',
            'query': {
                'group_id': '123456789',
            },
            "user_message": ""
        }

    if 'telebot_notify' not in new_settings.keys():
        # 新增推送通知到TG的功能
        new_settings['telebot_notify'] = False
        new_settings['telebot_token'] = ""
        new_settings['telebot_use_chat_id'] = False
        new_settings['telebot_chat_id'] = ""

    if 'discord_notify' not in new_settings.keys():
        # 新增推送通知到TG的功能
        new_settings['discord_notify'] = False
        new_settings['discord_token'] = ''

    for key in ('plex_refresh', 'plex_url', 'plex_token', 'plex_section', 'plex_naming'):
        # v25.1.4 移除 Plex 自動更新／命名功能
        if key in new_settings.keys():
            del new_settings[key]

    if 'faststart_movflags' not in new_settings.keys():
        # v9.0 新增功能: 將 metadata 移至視頻文件頭部
        # 此功能可以更快的在線播放視頻
        new_settings['faststart_movflags'] = False

    if 'video_filename_extension' not in new_settings.keys():
        # v17 新增用戶自定義視頻擴展名
        new_settings['video_filename_extension'] = 'mp4'

    if 'audio_language' not in new_settings.keys():
        # v19 添加音軌日語標籤  #37
        new_settings['audio_language'] = False

    if 'audio_language_jpn' in new_settings.keys():
        del new_settings['audio_language_jpn']

    if 'proxy' not in new_settings.keys() or 'proxies' in new_settings.keys():
        # v20 刪除鏈式代理功能
        if new_settings['proxies']["1"]:
            # 轉移用戶原有配置
            new_settings['proxy'] = new_settings['proxies']["1"]
        else:
            new_settings['proxy'] = 'http://user:passwd@example.com:1000'
        del new_settings['proxies']

    if 'use_dashboard' not in new_settings.keys():
        # v20 上線 Web 控制台
        new_settings['use_dashboard'] = True

    if 'dashboard' not in new_settings.keys():
        new_settings['dashboard'] = {
            'host': '127.0.0.1',
            'port': 5000,
            'SSL': False,
            'BasicAuth': False,
            'username': 'admin',
            'password': 'admin'
        }

    if 'ads_time' not in new_settings.keys():
        new_settings['ads_time'] = 25

    if 'danmu' not in new_settings.keys():
        # 支持下載彈幕
        # https://github.com/miyouzi/aniGamerPlus/pull/66
        new_settings['danmu'] = False

    if 'danmu_ban_words' not in new_settings.keys():
        new_settings['danmu_ban_words'] = []

    if 'use_mobile_api' not in new_settings.keys():
        # v21.0 新增使用APP API #69
        new_settings['use_mobile_api'] = False

    if 'mobile_ads_time' not in new_settings.keys():
        new_settings['mobile_ads_time'] = 25  # 使用APP API非會員廣告等待時間可低至 3s

    if 'message_suffix' not in new_settings['coolq_settings'].keys():
        # v21.1 新增
        new_settings['coolq_settings']['message_suffix'] = "追加的資訊"

    if 'user_message' in new_settings['coolq_settings'].keys():
        # QQ機器人推送通知可以通過配置追加通知內容
        new_settings['coolq_settings']['message_suffix'] = new_settings['coolq_settings']['user_message']
        del new_settings['coolq_settings']['user_message']

    if 'msg_argument_name' not in new_settings['coolq_settings'].keys():
        # v21.1 讓用戶自行構造QQ機器人 URL
        new_settings['coolq_settings']['msg_argument_name'] = "message"

    if 'SSL' in new_settings['coolq_settings'].keys():
        # 繼承用戶配置
        if new_settings['coolq_settings']['SSL']:
            req = 'https://'
        else:
            req = 'http://'
        req = req + new_settings['coolq_settings']['host'] + ':' + new_settings['coolq_settings']['port'] + '/' \
              + new_settings['coolq_settings']['api'] + '?' + urlencode(new_settings['coolq_settings']['query'])

        new_settings['coolq_settings']['query'] = [req]
        del new_settings['coolq_settings']['host']
        del new_settings['coolq_settings']['port']
        del new_settings['coolq_settings']['api']
        del new_settings['coolq_settings']['SSL']

    if 'only_use_vip' not in new_settings.keys():
        new_settings['only_use_vip'] = False

    if 'no_proxy_akamai' not in new_settings.keys():
        # v24.3 添加是否代理 akamai CDN （視頻流）
        new_settings['no_proxy_akamai'] = False

    if 'download_cd' not in new_settings.keys():
        # v24.4 下載冷卻時間(秒)
        new_settings['download_cd'] = 60

    if 'parse_sn_cd' not in new_settings.keys():
        # v24.4 sn解析冷卻時間(秒)
        new_settings['parse_sn_cd'] = 5

    if 'ja3' not in new_settings.keys():
        # v25.1.2 自訂 ja3/akamai 指紋(可空), 取代 curl_cffi 內建罐頭指紋, 需與取得 cookie 的瀏覽器一致
        new_settings['ja3'] = ''

    if 'akamai' not in new_settings.keys():
        # v25.1.2 自訂 ja3/akamai 指紋(可空)
        new_settings['akamai'] = ''

    if 'gossip_monitor' not in new_settings.keys():
        # v25.1.6 新增「監視公告」: 更新終了後偵測動畫瘋首頁 class="gossip" 公告, 記錄並視情況動態調整檢查時間
        # 預設關閉, 使用者需自行到 Dashboard 開啟
        new_settings['gossip_monitor'] = False
        new_settings['gossip_retention_days'] = 30
        new_settings['gossip_dynamic_schedule'] = False

    if 'notify_categories' not in new_settings.keys():
        # v25.1.9 新增通知類別開關(Telegram/Discord 共用), 預設全開維持舊版行為
        new_settings['notify_categories'] = {
            'download_manual_success': True,
            'download_manual_failed': True,
            'download_manual_cancelled': True,
            'download_schedule_success': True,
            'download_schedule_failed': True,
            'gossip_pause': True,
            'gossip_delay': True,
            'gossip_extra_episode': True,
            'gossip_other': True,
            'system_cookie_invalid': True,
            'system_device_error': True,
            'system_new_version': True,
        }

    if 'system_daily_digest' not in new_settings['notify_categories'].keys():
        # v25.2.1 新增「每日新番通知」類別開關, 預設開啟(既有 notify_categories 整組缺失的舊版設定
        # 已經在上面那個 if 區塊一併補上這個鍵, 這裡只補「notify_categories 已存在但缺這個新鍵」的情況)
        new_settings['notify_categories']['system_daily_digest'] = True

    if 'system_path_unreachable' not in new_settings['notify_categories'].keys():
        # v25.2.1 新增「路徑無法存取」類別開關(下載目錄/暫存目錄設定成網路磁碟時連不到會通知), 預設開啟
        new_settings['notify_categories']['system_path_unreachable'] = True

    if 'download_manual_cancelled' not in new_settings['notify_categories'].keys():
        # v25.2.3 新增「手動任務-已取消」類別開關(使用者主動終止手動任務時發送), 預設開啟
        new_settings['notify_categories']['download_manual_cancelled'] = True

    if 'check_prerelease_version' not in new_settings.keys():
        # v25.2.1 新增: 檢查 GitHub 上的預告版本(pre-release), 預設開啟
        new_settings['check_prerelease_version'] = True
        new_settings['skipped_version_tag'] = ''
        new_settings['skipped_prerelease_tag'] = ''

    if 'custom_dir_shortcuts' not in new_settings.keys():
        # v25.2.1 新增: 「選擇目錄」瀏覽器裡使用者自訂的喜好路徑
        new_settings['custom_dir_shortcuts'] = []

    if 'skipped_version_hash' not in new_settings.keys():
        # v25.2.2 新增: 「略過此版本通知」改成同時記住當下的內容雜湊, 見 send_new_version_notification()
        # 上方的說明; 舊版只有 tag 沒有 hash, 這裡補上空字串, 效果等同於「還沒略過任何內容雜湊」,
        # 不會因為升級後突然多出一個沒被使用者主動略過的 tag 就被視為已略過
        new_settings['skipped_version_hash'] = ''
        new_settings['skipped_prerelease_hash'] = ''

    if 'download_retry_count' not in new_settings.keys():
        # v25.2.2 新增: 排程下載連續失敗達這個次數後暫停自動重試, 預設 5 次
        new_settings['download_retry_count'] = 5

    if 'debug_mode' not in new_settings.keys():
        # v25.2.3 新增: 隱藏除錯開關, 預設關閉
        new_settings['debug_mode'] = False

    new_settings['config_version'] = latest_config_version
    _set_config_row(new_settings)
    msg = '配置文件從 v' + str(old_settings['config_version']) + ' 升級到 v' + str(latest_config_version) + ' 你的有效配置不會丟失!'
    __color_print(0, msg, status=2, no_sn=True)


def __update_database(old_version):
    with closing(_get_db_connection()) as conn:
        cursor = conn.cursor()
        __do_update_database(conn, cursor)
    msg = '資料庫從 v' + str(old_version) + ' 升級到 v' + str(latest_database_version) + ' 內部資料不會丟失'
    __color_print(0, msg, status=2, no_sn=True)


def __do_update_database(conn, cursor):
    # 拆成獨立函式讓外層 __update_database() 能用 with closing(...) 包住整個連線生命週期, 理由同
    # _do_ensure_config_tables()

    def creat_table():
        cursor.execute('CREATE TABLE IF NOT EXISTS anime ('
                       'sn INTEGER PRIMARY KEY NOT NULL,'
                       'title VARCHAR(100) NOT NULL,'
                       'anime_name VARCHAR(100) NOT NULL, '
                       'episode VARCHAR(10) NOT NULL,'
                       'status TINYINT DEFAULT 0,'
                       'remote_status INTEGER DEFAULT 0,'
                       'resolution INTEGER DEFAULT 0,'
                       'file_size INTEGER DEFAULT 0,'
                       'local_file_path VARCHAR(500),'
                       "[CreatedTime] TimeStamp NOT NULL DEFAULT (datetime('now','localtime')))")

    try:
        cursor.execute('SELECT COUNT(*) FROM anime')
    except sqlite3.OperationalError as e:
        if 'no such table' in str(e):
            # 如果不存在表, 則新建
            creat_table()

    try:
        cursor.execute('SELECT COUNT(local_file_path) FROM anime')
    except sqlite3.OperationalError as e:
        if 'no such column' in str(e):
            # 更早期的數據庫沒有 local_file_path , 做兼容
            cursor.execute('ALTER TABLE anime ADD local_file_path VARCHAR(500)')

    try:
        cursor.execute('SELECT COUNT(sn) FROM anime')
    except sqlite3.OperationalError as e:
        if 'no such column' in str(e):
            # 數據庫 v2.0  將 ns 列改名為 sn
            cursor.execute('ALTER TABLE anime RENAME TO animeOld')
            creat_table()
            cursor.execute("INSERT INTO "
                           "anime (sn,title,anime_name,episode,status,remote_status,resolution,file_size,local_file_path,[CreatedTime]) "
                           "SELECT "
                           "ns,title,anime_name,episode,status,remote_status,resolution,file_size,local_file_path,[CreatedTime] "
                           "FROM animeOld")
            cursor.execute('DROP TABLE animeOld')

    cursor.close()
    conn.commit()


def __read_settings_file():
    content = _get_config_row()
    if content is not None:
        # 注意: 這裡不能再對 content 套用 re.sub(r'\\', ..., ...) 幫反斜線加倍——那個修正是給下面
        # 「讀取使用者可能手動編輯過的舊版 config.json 檔案」專用的(人手打的 Windows 路徑會漏跳脫反斜線,
        # 直接 json.loads 會炸掉)。_get_config_row() 回傳的內容(不管是走 config_kv 現代路徑, 還是舊版
        # config 表的 legacy_row)本來就已經是正確跳脫過的合法 JSON, 再套用一次同樣的修正只會把本來正確的
        # 反斜線再加倍一次, 存進資料庫後下次讀取又再加倍——bangumi_dir/temp_dir 因為後面還有 os.path.abspath()
        # 正規化, 多出來的反斜線會被悄悄吃掉沒發現; 但像 custom_dir_shortcuts 這種沒有再被路徑正規化「洗過」
        # 的欄位, 反斜線就會每存一次多一倍, 幾次之後就徹底看不出原本的網路路徑長什麼樣子(實測踩到的 bug)
        try:
            return json.loads(content)
        except json.JSONDecodeError as e:
            __color_print(0, '讀取配置發生異常, 將重置配置! ' + str(e), status=1, no_sn=True)
            return __init_settings()

    # 資料庫裡尚無 config 列: 檢查是否有舊版(客製強化版 v25.1.7 以前, 或全新安裝)遺留的 config.json 可匯入
    if not os.path.exists(config_path):
        return __init_settings()

    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            # 轉義win路徑
            legacy_settings = json.loads(re.sub(r'\\', '\\\\\\\\', f.read()))
    except json.JSONDecodeError:
        # 如果帶有 BOM 頭, 則去除
        try:
            check_encoding(config_path)
            with open(config_path, 'r', encoding='utf-8') as f:
                legacy_settings = json.loads(re.sub(r'\\', '\\\\\\\\', f.read()))
        except BaseException as e:
            # 驗證失敗(檔案已損毀/亂碼, 例如斷電/當機造成寫入中斷): 不把壞掉的內容帶進資料庫, 改用預設值
            __color_print(0, '舊版 config.json 讀取發生異常, 將建立預設配置! ' + str(e), status=1, no_sn=True)
            return __init_settings()
    except BaseException as e:
        __color_print(0, '舊版 config.json 讀取發生異常, 將建立預設配置! ' + str(e), status=1, no_sn=True)
        return __init_settings()

    # 驗證通過(能被正常解析成 JSON), 才寫入資料庫; 原始 config.json 先保留在硬碟上, 不自動刪除/改名,
    # 待使用者確認新版本運作無誤後可自行刪除
    _set_config_row(legacy_settings)

    # 順便檢查 sn_list.txt 是否也是待匯入的舊版遺留檔: 若兩者同時存在, 合併成一行訊息, 並在這裡把
    # sn_list.txt 一併匯入, 避免 _get_sn_list_content_lazy() 稍後又獨立印一次訊息
    sn_list_also_legacy = _get_sn_list_row() is None and os.path.exists(sn_list_path) \
        and os.path.getsize(sn_list_path)
    if sn_list_also_legacy:
        try:
            check_encoding(sn_list_path)
            with open(sn_list_path, 'r', encoding='utf-8') as f:
                legacy_sn_list_content = f.read()
            _parse_sn_list_content(legacy_sn_list_content, legacy_settings)  # 驗證用途, 結果丟棄
        except BaseException:
            sn_list_also_legacy = False  # 驗證失敗: 交還給 _get_sn_list_content_lazy() 自行處理(建立空白清單)
        else:
            _set_sn_list_row(legacy_sn_list_content)

    if sn_list_also_legacy:
        __color_print(0, '偵測到舊版 config.json 與 sn_list.txt, 已驗證並匯入資料庫'
                         '(原始檔案保留, 確認運作正常後可自行刪除)', no_sn=True, status=2)
    else:
        __color_print(0, '偵測到舊版 config.json, 已驗證並匯入資料庫(原始檔案保留, 確認運作正常後可自行刪除)',
                      no_sn=True, status=2)
    return legacy_settings


def _update_path_fallback_state(field, configured, fallback_to):
    # fallback_to=None 代表這次讀取路徑正常可用(或使用者本來就沒設定), 每次 read_settings() 都會呼叫這裡,
    # 路徑恢復連線後會自動解除。field 是 'bangumi_dir' 或 'temp_dir'
    #
    # 注意: 通知一定要另開執行緒送出, 不能在這裡直接呼叫 send_notification()——它內部也會呼叫 read_settings(),
    # 這個函式正是在 read_settings() 裡面被呼叫的, 直接呼叫會無限遞迴
    unreachable = bool(configured) and fallback_to is not None
    path_fallback_state[field + '_unreachable'] = unreachable
    path_fallback_state['configured_' + field] = configured or ''
    path_fallback_state['fallback_' + field] = fallback_to or ''
    if not unreachable:
        _path_fallback_notified.discard(field)
        return
    if field in _path_fallback_notified:
        return  # 同一次「連不到」期間只通知一次, 避免每次 read_settings() 都送一次洗版
    _path_fallback_notified.add(field)  # 先標記再開執行緒, 避免同時多個執行緒重複送出
    label = '下載目錄' if field == 'bangumi_dir' else '暫存目錄'
    threading.Thread(target=_notify_path_unreachable, args=(label, configured, fallback_to), daemon=True).start()


def _notify_path_unreachable(label, configured, fallback_to):
    __color_print(0, '路徑無法存取',
                  label + '「' + configured + '」目前無法存取(網路磁碟未連線?), 本次改用 ' + fallback_to,
                  status=1, no_sn=True)
    send_notification('system_path_unreachable', '系統通知',
                       path_label=label, configured_path=configured, fallback_path=fallback_to,
                       finish_time=NotifyDB.now_str())


def read_settings(config=''):
    if config == '':
        # __read_settings_file() 自己會處理「資料庫尚無設定列」的情況(匯入舊版 config.json 或建立預設值),
        # 這裡不需要再額外判斷 config.json 是否存在
        settings = __read_settings_file()
    else:
        # 用於檢查 web 控制台回傳的配置是否正確
        # 複製一份而非直接引用: write_settings() 內部會呼叫 read_settings(web_config) 正規化後 del 掉部分欄位,
        # 若不復制, 在 Dashboard 資料夾遺失導致 read_settings() 內部遞迴呼叫 write_settings() 的情況下,
        # 會連帶把呼叫端(外層 read_settings())仍在使用、即將回傳的原始 dict 裡的 working_dir 等欄位一併刪掉
        settings = config.copy()

    if 'database_version' in settings.keys():
        if settings['database_version'] < latest_database_version:
            __update_database(settings['database_version'])
            settings['database_version'] = latest_database_version
            _set_config_row(settings)  # 寫回新版本號, 避免下次讀取又誤判成待升級而重複印出訊息
    else:
        # 如果該版本配置下沒有 database_version 項, 則數據庫版本應該是1.0
        __update_database(1.0)
        settings['database_version'] = latest_database_version
        _set_config_row(settings)

    if settings['config_version'] < latest_config_version:
        __update_settings(settings)  # 升級配置
        settings = __read_settings_file()  # 重新載入

    if settings['ftp']['port']:
        settings['ftp']['port'] = int(settings['ftp']['port'])

    # 防呆
    settings['check_frequency'] = int(settings['check_frequency'])
    settings['download_resolution'] = str(settings['download_resolution'])
    settings['multi-thread'] = int(settings['multi-thread'])
    settings['zerofill'] = int(settings['zerofill'])  # 保證為整數
    if not re.match(r'^(all|latest|largest-sn)$', settings['default_download_mode']):
        settings['default_download_mode'] = 'latest'  # 如果輸入非法模式, 將重置為 latest 模式
    if settings['quantity_of_logs'] < 1:  # 日誌數量不可小於 1
        settings['quantity_of_logs'] = 7

    if not settings['ua']:
        # 如果 ua 項目為空
        settings['ua'] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.96 Safari/537.36"

    def _as_real_custom_path(raw, default_dir):
        # read_settings() 可能被連續呼叫兩次(例如 write_settings() 內部又呼叫一次 read_settings() 正規化):
        # 第一次呼叫已經把空值解析成本地預設路徑, 若第二次呼叫把這個「已解析的預設路徑」誤判成「使用者自訂路徑」,
        # 會導致本地 bangumi/temp 資料夾只是還沒建立(全新安裝、尚未有任何下載)就被誤報成「路徑無法存取」。
        # 這裡只有在 raw 值跟預設路徑不同時才視為使用者真的自訂了路徑
        if not raw:
            return ''
        if os.path.normcase(os.path.abspath(raw)) == os.path.normcase(default_dir):
            return ''
        return raw

    # 如果用戶自定了番劇目錄且存在
    _default_bangumi_dir = os.path.join(working_dir, 'bangumi')
    _configured_bangumi_dir = _as_real_custom_path(settings['bangumi_dir'], _default_bangumi_dir)
    if settings['bangumi_dir'] and os.path.exists(settings['bangumi_dir']):
        # 番劇路徑規範化
        settings['bangumi_dir'] = os.path.abspath(settings['bangumi_dir'])
        _update_path_fallback_state('bangumi_dir', _configured_bangumi_dir, None)
    else:
        # 如果用戶沒有有自定番劇目錄或目錄不存在，則保存在本地 bangumi 目錄
        settings['bangumi_dir'] = _default_bangumi_dir
        _update_path_fallback_state('bangumi_dir', _configured_bangumi_dir, settings['bangumi_dir'])

    # 如果用戶自定了緩存目錄且存在
    _default_temp_dir = os.path.join(working_dir, 'temp')
    _configured_temp_dir = _as_real_custom_path(settings['temp_dir'], _default_temp_dir)
    if settings['temp_dir'] and os.path.exists(settings['temp_dir']):
        # 緩存路徑規範化
        settings['temp_dir'] = os.path.abspath(settings['temp_dir'])
        _update_path_fallback_state('temp_dir', _configured_temp_dir, None)
    else:
        # 如果用戶沒有有自定緩存目錄或目錄不存在，則保存在本地 temp 目錄
        settings['temp_dir'] = _default_temp_dir
        _update_path_fallback_state('temp_dir', _configured_temp_dir, settings['temp_dir'])

    settings['working_dir'] = working_dir
    settings['aniGamerPlus_version'] = aniGamerPlus_version

    use_gost = False
    if not (re.match(r'^http://', settings['proxy'].lower())
            or re.match(r'^https://', settings['proxy'].lower())
            or re.match(r'^socks5://', settings['proxy'].lower())  # v12開始原生支持 socks5 代理
            or re.match(r'^socks5h://', settings['proxy'].lower())):  # socks5h 遠程解析域名
        #  如果出現非自身支持的協議
        use_gost = True  # 則啓用gost
    settings['use_gost'] = use_gost
    if not settings['proxy']:
        settings['use_proxy'] = False

    if settings['multi-thread'] > max_multi_thread:
        # 如果線程數超限
        settings['multi-thread'] = max_multi_thread

    if settings['multi_downloading_segment'] > max_multi_downloading_segment:
        # 如果併發分段數超限
        settings['multi_downloading_segment'] = max_multi_downloading_segment

    if settings['video_filename_extension'].lower() == 'flv':
        # flv 格式會輸出異常, 強制重置
        settings['video_filename_extension'] = 'mp4'

    if settings['video_filename_extension'].lower() != 'mp4':
        # 如果封裝格式不是 mp4 則強制關閉 metadata 前置
        settings['faststart_movflags'] = False

    if settings['save_logs']:
        # 刪除過期日誌
        __remove_superfluous_logs(settings['quantity_of_logs'])

    if settings['gossip_retention_days'] < 1:  # 公告保存天數不可小於 1
        settings['gossip_retention_days'] = 30

    if not settings['gossip_monitor']:
        # 機動調整時間的前提是監視公告要先開啟; 就算 config.json 被手動改壞(監視公告關閉但機動調整時間開啟),
        # 這裡也強制修正回來, 不只是靠 Dashboard 前端的欄位相依限制
        settings['gossip_dynamic_schedule'] = False

    if settings['use_dashboard']:
        # 如果啓用的控制台, 那麼檢查是否存在Dashboard目錄
        if not os.path.exists(os.path.join(working_dir, 'Dashboard')):
            # 只影響這次回傳的 settings(讓呼叫端這次不要嘗試啟動一定會失敗的 Dashboard), 刻意不呼叫
            # write_settings() 寫回資料庫: 資料夾缺失通常是一次性/暫時的狀況(例如更新過程中檔案還沒複製完成),
            # 若直接永久停用, 使用者得自己回頭手動打開才能恢復, 資料夾之後補回來也不會自動生效;
            # 維持使用者原本的設定值不動, 下次資料夾存在時這裡的檢查自然就會通過, 不需要手動介入
            settings['use_dashboard'] = False
            __color_print(0, 'Web控制面板', '未發現控制面板所必須的Dashboard資料夾, 本次啟動暫時停用控制面板'
                          '(設定本身不受影響, 資料夾補回來後下次啟動會自動恢復)!', no_sn=True, status=1)

    return settings


def cleanup_stale_temp_files():
    # 程式啟動時呼叫一次, 清理上次意外中斷(當機/斷電/被強制關閉)時來不及清除的殘留暫存檔案
    #
    # temp_dir 可以被使用者自訂成任意現存目錄(見 read_settings() 對 temp_dir 的處理), 不一定是預設的
    # working_dir/temp, 所以這裡刻意不整個清空 temp_dir——貿然清空, 萬一 temp_dir 哪天被誤設定指到別的
    # 有用目錄, 會把不相干的檔案也一起刪掉。只刪除認得出來、確定是 aniGamerPlus 自己建立的殘留物,
    # 命名規則見 Anime.py 的 __segment_download_mode()/__get_temp_filename():
    #   - 子目錄 <sn 數字>-downloading-by-aniGamerPlus: 下載中的 m3u8/加密金鑰/分段暫存檔案
    #   - 檔名帶有 .MERGING. 或 .DOWNLOADING. 標記的檔案: 合併前/合併中的暫存影片
    settings = read_settings()
    temp_dir = settings['temp_dir']
    if not temp_dir or not os.path.exists(temp_dir):
        return
    subdir_pattern = re.compile(r'^\d+-downloading-by-aniGamerPlus$')
    try:
        entries = os.listdir(temp_dir)
    except OSError as e:
        __color_print(0, '暫存檔清理', '讀取暫存目錄時發生錯誤: ' + str(e), no_sn=True, status=1)
        return
    removed_dirs = 0
    removed_files = 0
    for name in entries:
        full_path = os.path.join(temp_dir, name)
        try:
            if os.path.isdir(full_path) and subdir_pattern.match(name):
                shutil.rmtree(full_path, ignore_errors=True)
                removed_dirs += 1
            elif os.path.isfile(full_path) and ('.MERGING.' in name or '.DOWNLOADING.' in name):
                os.remove(full_path)
                removed_files += 1
        except OSError as e:
            __color_print(0, '暫存檔清理', '清理 ' + name + ' 時發生錯誤: ' + str(e), no_sn=True, status=1)
    if removed_dirs or removed_files:
        __color_print(0, '暫存檔清理',
                      '已清除上次意外中斷留下的殘留暫存: ' + str(removed_dirs) + ' 個資料夾, ' + str(removed_files) + ' 個檔案',
                      no_sn=True, status=2)


def check_encoding(file_path):
    # 識別文件編碼, 將非 UTF-8 編碼轉為 UTF-8
    with open(file_path, 'rb') as f:
        data = f.read()
        file_encoding = chardet.detect(data)['encoding']  # 識別文件編碼
        if file_encoding == 'utf-8' or file_encoding == 'ascii':
            # 如果為 UTF-8 編碼, 無需操作
            return
        else:
            # 如果為其他編碼, 則轉為 UTF-8 編碼, 包含處理 BOM 頭
            with open(file_path, 'wb') as f2:
                __color_print(0, '檔案讀取', file_path + ' 編碼為 ' + file_encoding + ' 將轉碼為 UTF-8', no_sn=True, status=1)
                data = data.decode(file_encoding)  # 解碼
                data = data.encode('utf-8')  # 編碼
                f2.write(data)  # 寫入文件
                __color_print(0, '檔案讀取', file_path + ' 轉碼成功', no_sn=True, status=2)


def _parse_sn_list_content(content, settings, quiet=False):
    # 從 sn_list.txt 的相同解析邏輯抽出, 改成對一段字串(而不是檔案物件)操作,
    # 讓匯入舊檔時可以拿同一份邏輯做「驗證」(能不能正常解析), 又能供 read_sn_list() 真正解析使用
    # quiet=True 給只需要解析結果、不需要重複印出設定錯誤警告的呼叫端用(例如驗證階段已經印過一次的情況)
    sn_dict = {}
    bangumi_tag = ''
    for i in content.splitlines(keepends=True):
        if re.match(r'^@.+', i):  # 讀取番劇分類
            bangumi_tag = i[1:-1]
            continue
        elif re.match(r'^@ *', i):
            bangumi_tag = ''
            continue
        i = re.sub(r'#.+\n', '', i).strip()  # 刪除註釋 (# 之後的內容一律視為備註, 不參與下方任何標籤檢查)
        i = re.sub(r' +', ' ', i)  # 去除多餘空格
        a = i.split(" ")
        if not a[0]:  # 跳過純註釋行
            continue
        if re.match(r'^\d+$', a[0]):
            # 檢查是否有重複的 <>、**、$$ 標籤 (同一種標籤在同一行出現超過一次視為設定錯誤, 忽略該標籤避免誤用)
            angle_matches = re.findall(r'<[^<>]*>', i)
            star_matches = re.findall(r'\*[^*]*\*', i)
            dollar_matches = re.findall(r'\$[^$]*\$', i)
            has_duplicate_rename = len(angle_matches) > 1
            has_duplicate_schedule_tag = len(star_matches) > 1 or len(dollar_matches) > 1
            if has_duplicate_rename and not quiet:
                __color_print(0, 'sn_list設定錯誤',
                               f'sn={a[0]} 存在多組 <...> 標籤, 已忽略重新命名設定',
                               status=1, no_sn=True)
            if has_duplicate_schedule_tag and not quiet:
                __color_print(0, 'sn_list設定錯誤',
                               f'sn={a[0]} 存在多組 *...* 或 $...$ 標籤, 已忽略排程設定, 改為一般全數檢查',
                               status=1, no_sn=True)

            rename = ''
            if len(a) > 1:  # 如果有特別指定下載模式
                if re.match(r'^(all|latest|largest-sn)$', a[1]):  # 僅認可合法的模式
                    sn_dict[int(a[0])] = {'mode': a[1]}
                else:
                    sn_dict[int(a[0])] = {'mode': settings['default_download_mode']}  # 非法模式一律替換成默認模式
                # 是否有設定番劇重命名
                if not has_duplicate_rename and re.match(r'.*<.*>.*', i):
                    rename = re.findall(r'<.*>', i)[0][1:-1]
            else:  # 沒有指定下載模式則使用默認設定
                sn_dict[int(a[0])] = {'mode': settings['default_download_mode']}
            bangumi_tag = re.sub(r"( )+$", "", bangumi_tag)
            sn_dict[int(a[0])]['tag'] = bangumi_tag
            sn_dict[int(a[0])]['rename'] = rename

            # 自定義檢查星期/時間: *五* $23:30$ 表示只在每週五 23:30 才主動檢查, 不納入一般全數檢查列隊
            # 兩者必須同時填寫, 只填一個視為無效設定(忽略, 回退成一般全數檢查)
            weekday_match = None if has_duplicate_schedule_tag else re.search(r'\*([一二三四五六日])\*', i)
            time_match = None if has_duplicate_schedule_tag else re.search(r'\$(\d{1,2}):(\d{2})\$', i)
            schedule = None
            if weekday_match and time_match:
                hour, minute = int(time_match.group(1)), int(time_match.group(2))
                if 0 <= hour <= 23 and 0 <= minute <= 59:
                    schedule = {'weekday': ZH_TO_WEEKDAY[weekday_match.group(1)], 'hour': hour, 'minute': minute}
                elif not quiet:
                    __color_print(0, 'sn_list排程設定錯誤',
                                   f'sn={a[0]} 自定義時間 {hour:02d}:{minute:02d} 不合法, 已忽略排程設定, 改為一般全數檢查',
                                   status=1, no_sn=True)
            elif (weekday_match or time_match) and not quiet:
                __color_print(0, 'sn_list排程設定錯誤',
                               f'sn={a[0]} 自定義星期與自定義時間必須同時填寫, 已忽略排程設定, 改為一般全數檢查',
                               status=1, no_sn=True)
            sn_dict[int(a[0])]['schedule'] = schedule
    return sn_dict


def _get_sn_list_content_lazy():
    content = _get_sn_list_row()
    if content is not None:
        return content

    # 資料庫裡尚無 sn_list 列: 檢查硬碟上是否有舊版 sn_list.txt 可匯入
    # 防呆 https://github.com/miyouzi/aniGamerPlus/issues/5
    error_sn_list_path = sn_list_path.replace('sn_list.txt', 'sn_list.txt.txt')
    if os.path.exists(error_sn_list_path):
        os.rename(error_sn_list_path, sn_list_path)

    if not os.path.exists(sn_list_path) or not os.path.getsize(sn_list_path):
        # 檔案不存在或是空的(https://github.com/miyouzi/aniGamerPlus/issues/38), 視同全新安裝
        _set_sn_list_row('')
        return ''

    try:
        check_encoding(sn_list_path)
        with open(sn_list_path, 'r', encoding='utf-8') as f:
            legacy_content = f.read()
        # 驗證: 用既有解析邏輯跑一次確認不會出錯, 才視為有效內容(結果本身丟棄, 只是驗證用途)
        _parse_sn_list_content(legacy_content, read_settings())
    except BaseException as e:
        # 驗證失敗(檔案編碼/格式已損毀, 例如斷電/當機造成寫入中斷): 不把壞掉的內容帶進資料庫
        __color_print(0, '舊版 sn_list.txt 讀取/驗證發生異常, 將建立空白排程清單! ' + str(e), status=1, no_sn=True)
        _set_sn_list_row('')
        return ''

    # 原始 sn_list.txt 先保留在硬碟上, 不自動刪除/改名, 待使用者確認新版本運作無誤後可自行刪除
    _set_sn_list_row(legacy_content)
    __color_print(0, '偵測到舊版 sn_list.txt, 已驗證並匯入資料庫(原始檔案保留, 確認運作正常後可自行刪除)',
                  no_sn=True, status=2)
    return legacy_content


def read_sn_list():
    settings = read_settings()
    content = _get_sn_list_content_lazy()
    if not content:
        return {}
    return _parse_sn_list_content(content, settings)


def test_cookie():
    # 測試cookie.txt是否存在, 是否能正常讀取, 並記錄日誌
    read_cookie(log=True)


def _parse_cookie_content(content):
    # 從內容中找出第一個非空白行解析成 dict(cookie 原本設計上就只有一行有效); 找不到有效行時回傳 None
    for cookie_line in content.splitlines():
        if not cookie_line.strip():
            continue
        cookies = cookie_line.strip()
        cookies = dict([list(map(lambda x: quote(x, safe='') if re.match(r'[\u4e00-\u9fa5]', x) else x, l.split("=", 1))) for l in cookies.split("; ")])
        cookies.pop('ckBH_lastBoard', 404)
        return cookies
    return None


def _get_cookie_row_lazy():
    row = _get_cookie_row()
    if row is not None:
        return row
    return _import_legacy_cookie_file()


def _import_legacy_cookie_file():
    # 資料庫尚無資料列: 檢查硬碟上是否有舊版 cookie.txt(含 cookies.txt/cookie.txt.txt 舊檔名相容)可匯入
    old_cookie_path = cookie_path.replace('cookie.txt', 'cookies.txt')
    if os.path.exists(old_cookie_path):
        os.rename(old_cookie_path, cookie_path)
    error_cookie_path = cookie_path.replace('cookie.txt', 'cookie.txt.txt')
    if os.path.exists(error_cookie_path):
        os.rename(error_cookie_path, cookie_path)

    legacy_content = None
    if os.path.exists(cookie_path) and os.path.getsize(cookie_path):
        try:
            check_encoding(cookie_path)
            with open(cookie_path, 'r', encoding='utf-8') as f:
                raw = f.read()
            if _parse_cookie_content(raw) is not None:  # 驗證: 至少要能解析出一行有效 cookie 才視為可匯入
                legacy_content = raw
        except BaseException as e:
            __color_print(0, '讀取cookie', detail='舊版 cookie.txt 讀取/驗證發生異常, 視為無效: ' + str(e),
                          no_sn=True, status=1)

    _set_cookie_content(legacy_content or '')
    if legacy_content:
        __color_print(0, '讀取cookie', detail='偵測到舊版 cookie.txt, 已驗證並匯入資料庫(原始檔案保留, 確認運作正常後可自行刪除)',
                      no_sn=True, status=2)
    return _get_cookie_row()


def read_cookie(log=False):
    # 如果 cookie 已讀入內存, 則直接返回
    global cookie
    if cookie is not None:
        return cookie

    row = _get_cookie_row_lazy()
    content = row[0] if row and row[0] else None
    if not content:
        # 除錯用(受隱藏開關 is_debug_mode_enabled() 控制): 資料庫/舊版 cookie.txt 裡根本沒有內容(從未設定過,
        # 或是曾經被 invalid_cookie() 清空過), 跟下面「內容存在但解析失敗」是兩種不同原因, 分開記錄方便排查
        # 「明明剛用快速取得設定過, 怎麼還是遊客」
        if is_debug_mode_enabled():
            __color_print(0, '讀取cookie', detail='未發現cookie資料(資料庫內無內容, 將以遊客身份執行)', no_sn=True, status=1)
        cookie = {}
        return cookie

    if log:
        __color_print(0, '讀取cookie', detail='發現cookie資料', no_sn=True, display=False)
    parsed = _parse_cookie_content(content)
    if parsed is not None:
        cookie = parsed
        # 除錯用: 內容存在且解析成功時, 直接記錄解析結果是否含 BAHAID, 這樣「設定裡明明有存 cookie,
        # 但這次讀出來卻變遊客」的情況能一眼看出是解析階段就已經沒有 BAHAID(而不是後面才被清掉)
        if is_debug_mode_enabled():
            __color_print(0, '讀取cookie',
                          detail='已讀取cookie, ' + ('含登入身份 (BAHAID)' if cookie.get('BAHAID') else '不含登入身份 (BAHAID), 將以遊客身份執行'),
                          no_sn=True, status=0 if cookie.get('BAHAID') else 1, display=not cookie.get('BAHAID'))
        return cookie

    __color_print(0, '讀取cookie', detail='cookie資料為空(內容存在但解析失敗, 已標記為失效並清空, 將以遊客身份執行)',
                  no_sn=True, status=1)
    invalid_cookie()
    cookie = {}
    return cookie


def get_cookie_content():
    # 返回 cookie 原始內容, 提供給 Web 控制台編輯 (格式與檔案一致: key1=value1; key2=value2; ...)
    row = _get_cookie_row_lazy()
    return row[0] if row and row[0] else ""


def write_cookie_content(cookie_content):
    # 透過 Web 控制台寫入 cookie
    # updated_at 會同步更新為目前時間, 取代原本檔案 mtime 的角色,
    # 使 get_or_fetch_device_id() 的過期偵測能正確判斷 cookie 已更新, 自動重新申請匹配的裝置ID
    global cookie
    _set_cookie_content(cookie_content.strip())
    cookie = None  # 重置記憶體快取, 讓下次 read_cookie() 讀到新內容


quick_fetch_cancel_requested = threading.Event()


def _kill_quick_fetch_process(pid):
    # 連同子行程自己開的瀏覽器一起精準關閉(只關這一整棵行程樹, 不影響使用者原本開著的其他瀏覽器視窗)
    subprocess.run(['taskkill', '/PID', str(pid), '/T', '/F'],
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def run_quick_fetch(mode, pin=None):
    # 快速取得Cookie / UA-JA3-Akamai / 動畫瘋登入自動代填: 開一個獨立子行程(Dashboard/quick_fetch.py),
    # 由它自己開瀏覽器+獨立控制面板視窗讓使用者操作, 這裡只負責啟動/等待/讀回結果, 不直接處理瀏覽器或 tkinter
    # (tkinter 的阻塞式事件迴圈不適合跟 Flask/gevent 主行程共用)
    #
    # quick_fetch_state 只由這個函式(單一執行緒)寫入; cancel_quick_fetch() 只負責設定
    # quick_fetch_cancel_requested 旗標與強制關閉行程樹, 絕不直接改 quick_fetch_state,
    # 避免兩個執行緒同時寫入同一個 dict 而互相蓋掉對方寫入的結果(曾經導致明明已取消,
    # 卻被稍晚回傳的「未知錯誤」蓋掉狀態, 使用者點下「取消」後畫面看起來像沒有反應)
    quick_fetch_cancel_requested.clear()
    quick_fetch_state.clear()
    quick_fetch_state.update({'status': 'running'})

    creds_path = None
    if mode == 'login':
        # 「動畫瘋登入設定」已加密儲存帳密/2FA密鑰時, Cookie 按鈕改走這個模式自動代填;
        # 這裡解密只是短暫拿到明文供 spawn 子行程前寫進暫存檔, 絕不寫進 quick_fetch_state(會直接回給瀏覽器)
        try:
            creds = AccountVault.unlock_credentials(pin)
        except AccountVault.NotSupportedError:
            quick_fetch_state.update({'status': 'error', 'error': 'not_supported'})
            return
        except AccountVault.NotConfiguredError:
            quick_fetch_state.update({'status': 'error', 'error': 'not_configured'})
            return
        except AccountVault.PinRequiredError:
            quick_fetch_state.update({'status': 'error', 'error': 'pin_required'})
            return
        except AccountVault.WrongPinError:
            quick_fetch_state.update({'status': 'error', 'error': 'pin_wrong'})
            return

        fd, creds_path = tempfile.mkstemp(prefix='anigamer_quickfetch_creds_', suffix='.json')
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            json.dump(creds, f, ensure_ascii=False)

    fd, result_path = tempfile.mkstemp(prefix='anigamer_quickfetch_', suffix='.json')
    os.close(fd)
    os.remove(result_path)  # 只需要一個不衝突的檔名, 讓子行程自己建立

    if getattr(sys, 'frozen', False):
        # 打包後 sys.executable 是 aniGamerPlus.exe 自己, 沒有隨附 python.exe 可以執行 quick_fetch.py,
        # 改成重新呼叫自己並帶上隱藏旗標 --quick-fetch(見 aniGamerPlus.py 開頭的判斷)
        cmd = [sys.executable, '--quick-fetch', mode, result_path]
    else:
        script_path = os.path.join(working_dir, 'Dashboard', 'quick_fetch.py')
        cmd = [sys.executable, script_path, mode, result_path]
    if creds_path:
        cmd.append(creds_path)

    try:
        proc = subprocess.Popen(cmd)
    except OSError as e:
        quick_fetch_state.update({'status': 'error', 'error': '無法啟動瀏覽器輔助程序: ' + str(e)})
        if creds_path:
            try:
                os.remove(creds_path)  # 子行程根本沒啟動起來, 不會有機會自己讀取刪除, 這裡防禦性清除
            except OSError:
                pass
        return
    quick_fetch_state['pid'] = proc.pid

    if quick_fetch_cancel_requested.is_set():
        # 使用者在 pid 寫入前(啟動子行程的極短暫空窗期)就已經按下取消, 這裡補做一次確保子行程不會變成孤兒繼續開著瀏覽器
        _kill_quick_fetch_process(proc.pid)

    proc.wait()  # 等子行程自然結束(使用者操作完成/取消/逾時都會讓它自己退出)

    if creds_path and os.path.exists(creds_path):
        # 正常情況下子行程一開始讀完就會自己刪除; 這裡是防禦性清除, 涵蓋子行程被提早強制關閉、
        # 來不及讀取的邊界情況, 避免帳密明文暫存檔留在磁碟上
        try:
            os.remove(creds_path)
        except OSError:
            pass

    if quick_fetch_cancel_requested.is_set():
        # 只要是使用者主動取消導致的結束, 一律回報 cancelled, 不理會子行程來不及寫完整的中繼進度檔
        try:
            os.remove(result_path)
        except OSError:
            pass
        quick_fetch_state.update({'status': 'cancelled'})
        return

    if not os.path.exists(result_path):
        # 使用者直接關掉整個瀏覽器視窗(而非按面板上的按鈕), 子行程來不及寫結果檔
        quick_fetch_state.update({'status': 'cancelled'})
        return

    try:
        with open(result_path, 'r', encoding='utf-8') as f:
            result = json.load(f)
    except (OSError, json.JSONDecodeError):
        result = {'ok': False, 'error': '讀取結果時發生錯誤'}
    finally:
        try:
            os.remove(result_path)  # 內含 cookie 等機敏資料, 讀完立即刪除, 不留在磁碟上
        except OSError:
            pass

    if result.get('ok'):
        quick_fetch_state.update({'status': 'done'})
        quick_fetch_state.update(result)
    elif result.get('status') == 'cancelled':
        quick_fetch_state.update({'status': 'cancelled'})
    else:
        quick_fetch_state.update({'status': 'error', 'error': result.get('error', '未知錯誤')})


def cancel_quick_fetch():
    quick_fetch_cancel_requested.set()
    pid = quick_fetch_state.get('pid')
    if pid:
        _kill_quick_fetch_process(pid)
    # 不在這裡直接寫 quick_fetch_state: 交給 run_quick_fetch() 自己的執行緒在 proc.wait() 解除阻塞後
    # 統一寫入最終狀態(見上方說明), 這裡只負責「請求取消」與強制關閉行程樹兩件事


def _read_json_file(path):
    if not os.path.exists(path):
        return {}
    try:
        with open(path, 'r', encoding='utf-8') as f:
            content = f.read().strip()
        return json.loads(content) if content else {}
    except (json.JSONDecodeError, OSError):
        return {}


def _manual_task_row_to_params(sn, columns, row_tail):
    row_dict = dict(zip(columns, row_tail))
    params = {
        'sn': sn, 'mode': row_dict['mode'], 'resolution': row_dict['resolution'],
        'classify': bool(row_dict['classify']), 'thread': row_dict['thread'], 'danmu': bool(row_dict['danmu']),
        'bilingual': bool(row_dict['bilingual']), 'rename': row_dict['rename'] or '',
        'ep_range': json.loads(row_dict['ep_range']) if row_dict['ep_range'] else [],
    }
    if 'completed_episodes' in row_dict:
        params['completed_episodes'] = json.loads(row_dict['completed_episodes']) if row_dict['completed_episodes'] else []
    return params


def _read_manual_tasks_table(table_name, columns, legacy_path):
    # 讀取指定表的全部任務; 若表是空的且硬碟上還有舊版 .json 檔, 逐筆匯入(沿用既有 _read_json_file 的容錯:
    # 檔案不存在/損毀一律視為沒有任務, 不需要額外驗證)
    with closing(_get_db_connection()) as conn:
        rows = conn.execute('SELECT sn, ' + ','.join(columns) + ' FROM ' + table_name).fetchall()
    if not rows:
        legacy = _read_json_file(legacy_path)
        if legacy:
            for sn_str, params in legacy.items():
                _write_manual_task_row(table_name, columns, int(sn_str), params)
            __color_print(0, '讀取手動任務',
                          detail='偵測到舊版 ' + os.path.basename(legacy_path) + ', 已匯入資料庫(原始檔案保留, 確認運作正常後可自行刪除)',
                          no_sn=True, status=2)
            with closing(_get_db_connection()) as conn:
                rows = conn.execute('SELECT sn, ' + ','.join(columns) + ' FROM ' + table_name).fetchall()
    return {str(row[0]): _manual_task_row_to_params(row[0], columns, row[1:]) for row in rows}


def read_manual_single_tasks():
    # {sn(str): {task params}}, 供程式啟動時還原意外中斷的單集類手動任務(single/latest/largest-sn)
    with _manual_tasks_lock:
        return _read_manual_tasks_table('manual_single_tasks', _SINGLE_TASK_COLUMNS, manual_single_tasks_path)


def add_manual_single_task(sn, params):
    with _manual_tasks_lock:
        _write_manual_task_row('manual_single_tasks', _SINGLE_TASK_COLUMNS, sn, params)


def remove_manual_single_task(sn):
    with _manual_tasks_lock:
        with closing(_get_db_connection()) as conn:
            conn.execute('DELETE FROM manual_single_tasks WHERE sn=?', (int(sn),))
            conn.commit()


def read_manual_batch_tasks():
    # {sn(str): {task params, 含 mode='all'/'range' 與 range 模式所需的 ep_range,
    #            以及下載途中逐集累加的 completed_episodes(已下載成功的集數 sn 清單)}}
    # 供程式啟動時還原意外中斷的批次類手動任務; 還原時會排除 completed_episodes 裡已經下載成功的集數,
    # 避免當機前已完成的集數被重新下載一次(仍在下載中或已放棄的集數則會照常重新嘗試)
    with _manual_tasks_lock:
        return _read_manual_tasks_table('manual_batch_tasks', _BATCH_TASK_COLUMNS, manual_batch_tasks_path)


def add_manual_batch_task(sn, params):
    with _manual_tasks_lock:
        _write_manual_task_row('manual_batch_tasks', _BATCH_TASK_COLUMNS, sn, params)


def mark_manual_batch_episode_done(sn, ep_sn):
    # 批次類手動任務(all/range)裡, 單一集數下載成功後呼叫, 把該集的 sn 記進這筆批次任務的 completed_episodes
    # 清單並落地存檔; 供程式意外中斷(當機/斷電/被強制關閉)後重啟時, 還原這筆批次任務時可以跳過已經下載成功的集數,
    # 只重新嘗試當時仍在下載中或已放棄的集數。若這筆批次任務已經正常結束並被移除(remove_manual_batch_task()),
    # 這裡就不會有對應紀錄可寫, 屬正常情況直接略過
    with _manual_tasks_lock:
        with closing(_get_db_connection()) as conn:
            row = conn.execute('SELECT completed_episodes FROM manual_batch_tasks WHERE sn=?', (int(sn),)).fetchone()
            if row is None:
                return
            completed = json.loads(row[0]) if row[0] else []
            if ep_sn not in completed:
                completed.append(ep_sn)
                conn.execute('UPDATE manual_batch_tasks SET completed_episodes=? WHERE sn=?',
                             (json.dumps(completed), int(sn)))
                conn.commit()


def remove_manual_batch_task(sn):
    with _manual_tasks_lock:
        with closing(_get_db_connection()) as conn:
            conn.execute('DELETE FROM manual_batch_tasks WHERE sn=?', (int(sn),))
            conn.commit()


def invalid_cookie(remove_file=True):
    # 當cookie失效時, 重置已讀取的cookie記憶體快取
    # remove_file=True 時另外把目前 cookie 內容搬進 last_invalid_content 欄位保留(供人工檢查)並清空 content,
    # 避免重複嘗試失效的cookie, 僅用於 cookie 本身已確定損毀/空白(見 read_cookie())的情況
    #
    # v25.1.7 修正: 登入cookie刷新在多執行緒併發時, 「刷新失敗」有可能只是這個執行緒沒搶到刷新名額的
    # 暫時性競爭(尤其手動任務併發數較高時), 未必代表cookie真的已失效。若這時就把 cookie 整個清空,
    # 會導致其他仍在下載中的執行緒讀到空白 cookie 而任務失敗,
    # 因此這類情況改為只重置記憶體快取、保留資料庫內容不清空, 讓後續請求仍可重新讀取同一份 cookie 重試
    global cookie
    cookie = None  # 重置已讀取的cookie
    if not remove_file:
        __color_print(0, 'cookie狀態', '已重置cookie快取(保留原始資料, 稍後將重新嘗試)', no_sn=True, display=False)
        return
    try:
        _mark_cookie_invalid()
    except BaseException as e:
        __color_print(0, 'cookie狀態', '嘗試標記失效cookie時遇到未知錯誤: ' + str(e), no_sn=True, status=1)
    else:
        __color_print(0, 'cookie狀態', '已成功標記失效cookie', no_sn=True, display=False)
        send_notification('system_cookie_invalid', '系統通知', finish_time=NotifyDB.now_str())


def time_stamp_to_time(timestamp):
    # 把時間戳轉化為時間: 1479264792 to 2016-11-16 10:53:12
    # 代碼來自: https://www.cnblogs.com/shaosks/p/5614630.html
    timeStruct = time.localtime(timestamp)
    return time.strftime('%Y-%m-%d %H:%M:%S', timeStruct)


def get_cookie_time():
    # 獲取 cookie 修改時間(除錯用途)
    row = _get_cookie_row()
    if not row or not row[2]:
        return '尚無紀錄'
    return row[2]


def should_refresh_cookie():
    # 限制登入cookie刷新的頻率(預設最多每90秒一次), 避免多執行緒併發請求時短時間內反覆觸發刷新
    # 而被動畫瘋判定為異常使用行為。回傳 True 代表這次呼叫可以執行刷新, 並會佔用這次的刷新名額
    global _last_cookie_refresh_time
    with _cookie_refresh_lock:
        now = time.time()
        if now - _last_cookie_refresh_time >= cookie_refresh_min_interval:
            _last_cookie_refresh_time = now
            return True
        return False


def _current_ja3_akamai_fingerprint():
    # 目前設定裡的 ja3/akamai, 串成一個字串供比對是否變動過(內容比對, 不是檔案時間比對)
    # 刻意不呼叫 __read_settings_file()(會在資料庫尚無資料時觸發 __init_settings() 建立預設值這個副作用),
    # 只在資料庫已有設定列、或硬碟上還有舊版 config.json 可讀時才嘗試讀取, 否則視為空字串
    content = _get_config_row()
    if content is not None:
        try:
            settings = json.loads(re.sub(r'\\', '\\\\\\\\', content))
        except json.JSONDecodeError:
            settings = {}
    elif os.path.exists(config_path):
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                settings = json.loads(re.sub(r'\\', '\\\\\\\\', f.read()))
        except BaseException:
            settings = {}
    else:
        settings = {}
    return (settings.get('ja3') or '') + '|' + (settings.get('akamai') or '')


def _get_device_id_row_lazy():
    row = _get_device_id_row()
    if row is not None:
        return row
    # 資料庫尚無資料列: 檢查硬碟上是否有舊版 device_id.txt 可匯入(新版JSON格式/舊版純文字格式皆相容)
    if os.path.exists(device_id_path):
        try:
            with open(device_id_path, 'r', encoding='utf-8') as f:
                raw = f.read().strip()
        except BaseException as e:
            __color_print(0, '讀取裝置ID發生異常, 將忽略舊檔案: ' + str(e), no_sn=True, status=1)
            raw = ''
        if raw:
            try:
                parsed = json.loads(raw)
                legacy_device_id = parsed.get('device_id')
                legacy_fingerprint = parsed.get('ja3_akamai_fingerprint')
            except (json.JSONDecodeError, AttributeError):
                # 舊版格式: 檔案內容就是純文字 device_id, 沒有指紋快照可比對, 視為指紋未知(強制觸發一次性的重新申請,
                # 讓舊版升級上來的使用者也補上這組記錄, 之後就不會再誤觸發)
                legacy_device_id = raw
                legacy_fingerprint = None
            if legacy_device_id:
                _set_device_id_row(legacy_device_id, legacy_fingerprint)
                __color_print(0, '偵測到舊版 device_id.txt, 已匯入資料庫(原始檔案保留, 確認運作正常後可自行刪除)',
                              no_sn=True, status=2)
    return _get_device_id_row()


def get_or_fetch_device_id(fetch_func):
    # 取得持久化保存的裝置ID; 若尚未存在, 用 fetch_func() 向伺服器取得一個新的並持久化保存
    # 讓整個應用程式的所有下載任務/重試都共用同一個裝置身分 (模擬真實瀏覽器裝置指紋的持久性),
    # 避免每次下載或重試都跟伺服器要一個新的 device_id, 導致同一帳號短時間內出現大量不同裝置的異常使用模式
    global device_id
    if device_id is not None:
        return device_id
    with _device_id_lock:
        if device_id is not None:  # 雙重檢查, 避免等鎖期間其他線程已經取得
            return device_id
        # 過期判斷分兩部分:
        # 1. cookie 的 updated_at 比 device_id 的 created_at 新 -> 代表使用者重新登入/採集了 cookie
        # 2. 目前設定的 ja3/akamai "內容" 跟這組 device_id 當初核發時記錄的不一樣 -> 代表指紋換過
        # 這兩者只要有一個成立, 舊的裝置ID就是在「另一組」cookie/瀏覽器指紋底下取得的, 沿用它會讓 device_id 與目前的
        # cookie/指紋對不上, 容易被判定為「裝置驗證異常」(code=1007), 因此視同裝置ID也已過期, 一併重新取得
        #
        # 注意 1: ja3/akamai 這裡刻意用「內容比對」而不是比對 config 的更新時間——config 除了使用者
        # 手動更改設定會被寫入, 每次成功通過廣告驗證也會把量測到的廣告等待秒數自動存回 config(見 Anime.py 的
        # check_no_ad()), 是下載過程中的正常副作用。若改用 config 的更新時間比對, 會導致「只要之前成功下載過一次,
        # 下次重啟就一定判定過期」, 讓裝置ID遠比預期頻繁地重新申請, 反而製造出「同一帳號短時間內出現大量不同裝置」
        # 這個機制原本要避免的異常模式。改成只比對 ja3/akamai 的實際內容, 就不會被這類無關的自動存檔誤觸發
        #
        # 注意 2: device_id 一旦讀入記憶體, 在下一次呼叫 reset_device_id_cache() 之前都不會重新檢查(上面的
        # `if device_id is not None: return device_id` 短路)。Dashboard 透過 /cookie 或 /uploadConfig 更新
        # cookie/ja3/akamai 後都會呼叫 reset_device_id_cache() 清掉這個快取, 讓下一次呼叫這裡時重新走一次
        # 上面的過期判斷, 不需要重啟程式就能套用新指紋對應的裝置ID(真的過期才會重新申請, 沒過期會繼續沿用舊的)
        current_fingerprint = _current_ja3_akamai_fingerprint()
        device_row = _get_device_id_row_lazy()
        stored_device_id, stored_fingerprint, device_created_at = device_row if device_row else (None, None, None)

        cookie_row = _get_cookie_row()
        cookie_updated_at = cookie_row[2] if cookie_row else None
        cookie_stale = (
            stored_device_id is not None
            and device_created_at is not None
            and cookie_updated_at is not None
            and cookie_updated_at > device_created_at
        )
        fingerprint_stale = stored_device_id is not None and stored_fingerprint != current_fingerprint
        device_id_stale = stored_device_id is None or cookie_stale or fingerprint_stale

        if stored_device_id is not None and (cookie_stale or fingerprint_stale):
            reason = 'cookie 已更新' if cookie_stale else 'ja3/akamai 指紋已變更'
            __color_print(0, '偵測到' + reason + ', 裝置ID視為過期, 將重新取得', status=2, no_sn=True)

        if not device_id_stale:
            device_id = stored_device_id
            return device_id

        new_id = fetch_func()
        device_id = new_id
        try:
            _set_device_id_row(new_id, current_fingerprint)
        except BaseException as e:
            __color_print(0, '裝置ID保存失敗! 發生異常: ' + str(e), status=1, no_sn=True)
        return device_id


def invalidate_device_id():
    # 收到動畫瘋回應「裝置驗證異常」(code=1007) 時呼叫: 該組裝置ID疑似已被伺服器標記, 之後不管重試幾次、
    # 甚至重啟程式沿用同一組都會持續失敗(實測結果), 因此直接視同過期並清除, 讓下一次呼叫 get_or_fetch_device_id()
    # 強制重新申請一組全新的裝置ID, 不需要使用者手動刪除 device_id.txt 才能恢復
    global device_id
    with _device_id_lock:
        device_id = None
        with _config_db_lock:
            with closing(_get_db_connection()) as conn:
                conn.execute('DELETE FROM device_id WHERE id=1')
                conn.commit()
        if os.path.exists(device_id_path):
            # 舊版遺留的 device_id.txt 也一併清除, 避免下次因資料庫列已清空而重新從這份舊檔案(同一組已被標記的裝置ID)匯入
            try:
                os.remove(device_id_path)
            except BaseException as e:
                __color_print(0, '清除過期裝置ID失敗! 發生異常: ' + str(e), status=1, no_sn=True)


def reset_device_id_cache():
    # Dashboard 存了新 Cookie/JA3/Akamai 後呼叫: 只清掉記憶體裡的快取變數, 讓下一次 get_or_fetch_device_id()
    # 重新跑一次它本來就有的過期判斷(比對 cookie.updated_at 與裝置ID 的 created_at、比對目前 ja3/akamai
    # 內容與核發當下的快照), 真的過期才會重新申請一組, 不會平白製造出一組新裝置身分
    #
    # 跟 invalidate_device_id() 的差別: 那個是收到 code=1007 時的「強制作廢」(連資料庫列與舊的
    # device_id.txt 都刪掉, 一定重新申請一組全新的); 這裡只是「下次重新判斷一次」, 舊的裝置ID若比對後仍然
    # 匹配就會繼續沿用
    global device_id
    with _device_id_lock:
        device_id = None


def get_or_create_dashboard_secret_key():
    # 取得持久化保存的 Dashboard session 簽章金鑰; 若尚未存在則產生一把新的並保存
    # 持久化是為了讓使用者的登入狀態不會因為程式重啟就被登出
    _ensure_config_tables()  # 保險: 這個函式可能在 Server.py 模組匯入期就被呼叫(見 app.secret_key 設定處)
    with closing(_get_db_connection()) as conn:
        row = conn.execute('SELECT secret_key FROM dashboard_secret WHERE id=1').fetchone()
    if row and row[0]:
        return row[0]

    # 資料庫尚無資料列: 檢查硬碟上是否有舊版 dashboard_secret.key 可匯入
    content = ''
    if os.path.exists(dashboard_secret_key_path):
        with open(dashboard_secret_key_path, 'r', encoding='utf-8') as f:
            content = f.read().strip()

    new_key = content if content else secrets.token_hex(32)
    with closing(_get_db_connection()) as conn:
        conn.execute('INSERT OR REPLACE INTO dashboard_secret (id, secret_key) VALUES (1, ?)', (new_key,))
        conn.commit()
    return new_key


def renew_cookies(new_cookie, log=True):
    global cookie
    cookie = None  # 重置cookie
    new_cookie_str = ''
    for key, value in new_cookie.items():
        new_cookie_str = new_cookie_str + key + '=' + value + '; '
    new_cookie_str = new_cookie_str[0:-2]
    # print(new_cookie_str)
    try_counter = 0
    while True:
        try:
            _set_cookie_content(new_cookie_str)
        except BaseException as e:
            if try_counter > 3:
                __color_print(0, '新cookie保存失敗! 發生異常: ' + str(e), status=1, no_sn=True)
                break
            random_wait_time = random.uniform(2, 5)
            time.sleep(random_wait_time)
            try_counter = try_counter + 1
        else:
            if log:
                __color_print(0, '新cookie保存成功', no_sn=True, display=False)
            break


def read_github_releases():
    # v25.2.1 起改抓 /releases 清單(而不是 /releases/latest): /releases/latest 依 GitHub 的定義一定會排除
    # prerelease 與 draft, 抓不到「預告版本」。清單本身已依建立時間新到舊排序, 各分類取第一筆符合條件的
    # 就是最新的那一筆; v25.1.9 起改發布至客製強化版自己的 repo, 不再檢查上游 miyouzi/aniGamerPlus
    # (版號體系不同, 拿來比對沒有意義)
    #
    # 回傳 {'release': entry|None, 'prerelease': entry|None}
    # entry = {'tag_name': str, 'body': str, 'html_url': str, 'prerelease': bool}
    req = 'https://api.github.com/repos/1476523/aniGamerPlusBeta/releases'
    session = requests.session()
    result = {'release': None, 'prerelease': None}
    try:
        releases = session.get(req, timeout=5).json()
        for item in releases:
            if item.get('draft'):
                continue
            key = 'prerelease' if item.get('prerelease') else 'release'
            if result[key] is None:
                result[key] = {'tag_name': item['tag_name'], 'body': item.get('body') or '',
                               'html_url': item.get('html_url') or '', 'prerelease': bool(item.get('prerelease'))}
            if result['release'] and result['prerelease']:
                break
        __color_print(0, '檢查更新', '檢查更新成功', no_sn=True, display=False)
    except Exception:
        __color_print(0, '檢查更新', '檢查更新失敗', no_sn=True, display=False)
    return result


# system_cookie_invalid/system_device_error 這兩種系統類別在併發重試時可能短時間內觸發多次(例如批次下載
# 好幾集同時撞上同一組已失效的裝置ID), 加個簡單冷卻避免同一個問題洗版式地連續發送好幾則一樣的通知
_notification_last_sent = {}
_notification_cooldown_lock = threading.Lock()  # 保護下方「檢查冷卻時間是否已過+更新時間戳記」這組複合操作,
# 避免兩個執行緒(例如批次下載好幾集同時撞上同一組已失效裝置ID)在同一瞬間都讀到「冷卻已過」而各自送出一則,
# 冷卻機制形同虛設
_NOTIFICATION_COOLDOWN_SECONDS = {
    'system_cookie_invalid': 600,
    'system_device_error': 600,
}


def send_notification(category, title_suffix, **context):
    # 統一的 Telegram/Discord 通知派送入口: 供 Anime.py(下載完成/失敗)、Gossip.py(公告事件)、
    # 系統狀態(cookie失效/裝置驗證異常/新版本可用)等各處共用, 避免同樣的 chat_id 偵測/送出邏輯散落多處重複維護。
    # category 對應 settings['notify_categories'] 底下的開關鍵值, 該類別關閉時直接跳過、兩邊管道都不會送出。
    # 這裡改成接收 title_suffix + context(動態內容), 而不是接收呼叫端已經組好的最終訊息字串, 是因為
    # Telegram(HTML 標籤 + parse_mode=HTML, 內容需要 HTML 跳脫)跟 Discord(轉換好的 markdown, 內容不跳脫)
    # 兩邊現在用的模板文字不一樣(見 NotifyDB.render_notify_message), 必須各自在真正要送出那一刻才組字串,
    # 否則沒辦法讓兩邊各自套用正確的跳脫/轉換規則
    settings = read_settings()
    categories = settings.get('notify_categories', {})
    if not categories.get(category, True):
        return

    cooldown = _NOTIFICATION_COOLDOWN_SECONDS.get(category)
    if cooldown:
        with _notification_cooldown_lock:
            last_sent = _notification_last_sent.get(category, 0)
            if time.time() - last_sent < cooldown:
                return
            _notification_last_sent[category] = time.time()

    if settings.get('telebot_notify'):
        # Telegram 沒有獨立的「標題」欄位, 標題行跟內文一樣都是同一則訊息的文字, 所以維持組成同一個字串
        message = notify_title(title_suffix) + '\n' + NotifyDB.render_notify_message(category, 'telegram', **context)
        _send_telegram_notification(category, message)
    if settings.get('discord_notify'):
        # Discord 的 embed 有獨立的標題欄位, 直接拿來放 notify_title(...), 內文(description)只放模板本身,
        # 不用像 Telegram 那樣把標題行併進內文, 也比較符合 embed 原本的呈現方式
        title = notify_title(title_suffix)
        body = NotifyDB.render_notify_message(category, 'discord', **context)
        _send_discord_notification(category, settings, body, title=title)


_RELEASE_BODY_MAX_CHARS = 3000  # 抓 Telegram(4096 字)/Discord embed description(4096 字)訊息長度上限的安全值,
# 留給前後固定文字(標題/標籤/blockquote 標籤)與 html.escape() 跳脫膨脹的空間


def _truncate_release_body(text, max_chars=_RELEASE_BODY_MAX_CHARS):
    # GitHub release notes 全文塞進通知常常超過 Telegram/Discord 的單則訊息長度上限, 超過時 Telegram 直接
    # 回 400 Bad Request: message is too long, 整則通知(含標題與版本資訊)完全送不出去。
    # <blockquote expandable> 只是 Telegram 用戶端「顯示」時預設收合, 完整內容還是得整份送進 API,
    # 不會因為用了摺疊標籤就變相省字數, 所以真的超長時只能自己在送出前砍內容——保留頭尾方便快速掌握重點,
    # 中間用省略提示代替, 完整內容使用者仍可自行到 GitHub 查看
    if len(text) <= max_chars:
        return text
    head_len = max_chars * 2 // 3
    tail_len = max_chars - head_len
    omitted = len(text) - head_len - tail_len
    return (text[:head_len].rstrip() +
            '\n\n...(內容過長, 中間省略 ' + str(omitted) + ' 字, 完整內容請至 GitHub 查看)...\n\n' +
            text[-tail_len:].lstrip())


def send_new_version_notification(is_prerelease, tag_name, version_body_plain):
    # 「新版本可用」系統通知(v25.2.2 起)刻意不走 NotifyDB 的可自訂模板系統, 直接在這裡寫死格式:
    # 這則通知內容(GitHub release notes)完全是系統產生、使用者沒有自行填寫的欄位可自訂, 讓它可被任意改寫
    # 模板只會徒增「內容被改壞導致看不出真正版本資訊」的風險, 保障內容一定完整正確比讓使用者能客製化更重要。
    # Telegram 支援 <blockquote expandable> 摺疊長內容, Discord 沒有對應功能, 維持整段平鋪顯示
    settings = read_settings()
    categories = settings.get('notify_categories', {})
    if not categories.get('system_new_version', True):
        return
    label = '新版本預告' if is_prerelease else '新版本'
    body = _truncate_release_body(version_body_plain)
    if settings.get('telebot_notify'):
        message = (notify_title('系統通知') + '\n發現GitHub上有' + label + ': ' + html.escape(tag_name) +
                   '\n更新內容:\n<blockquote expandable>' + html.escape(body) + '</blockquote>')
        if len(message) > 4096:
            # 保險: _truncate_release_body() 是照原始字數抓的安全值, html.escape() 若剛好把大量字元
            # 展開成 HTML 實體(例如內容剛好有很多 &/</>)理論上仍可能小幅超出 Telegram 4096 字上限;
            # 這裡再做一次硬性裁切並補回結尾標籤, 確保無論如何都能送出, 不會重演「訊息過長送不出去」
            closing = '</blockquote>'
            message = message[:4096 - len(closing)] + closing
        _send_telegram_notification('system_new_version', message)
    if settings.get('discord_notify'):
        title = notify_title('系統通知')
        discord_body = '發現GitHub上有' + label + ': ' + tag_name + '\n更新內容:\n' + body
        _send_discord_notification('system_new_version', settings, discord_body, title=title)


def _telegram_send_core(token, message, settings):
    # 回傳 (ok, info): ok=False 時 info 是人看得懂的失敗原因, ok=True 時 info 是空字串
    # 聊天室ID 為必填, 不再提供「留空時用 getUpdates 自動偵測」的備援: 那個機制依賴 Telegram 短時間內
    # 保留的訊息紀錄, 排程通知這種非即時場景很容易偵測不到對話紀錄, 導致通知悄悄失敗又難以排查
    chat_id = settings.get('telebot_chat_id')
    if not chat_id:
        return False, '尚未設定聊天室ID, 請先按「取得聊天室ID」按鈕取得後儲存'

    # parse_mode=HTML: 讓「通知模板」支援的 <b>/<i>/<code> 等 Telegram HTML 標籤真的被渲染成格式,
    # 而不是原樣顯示成文字; 測試訊息/未使用任何標籤的訊息是純文字, 加這個參數不影響顯示結果
    resp = requests.post(f'https://api.telegram.org/bot{token}/sendMessage',
                          json={'chat_id': chat_id, 'text': message, 'parse_mode': 'HTML'}, timeout=10)
    resp_json = resp.json()
    if resp_json.get('ok'):
        return True, ''
    return False, 'Telegram 回應: ' + resp_json.get('description', resp.text)


_DISCORD_WEBHOOK_URL_RE = re.compile(
    r'^https://(discord\.com|discordapp\.com)/api/webhooks/\d+/[\w-]+/?$'
)


def is_valid_discord_webhook_url(url):
    # 白名單格式檢查: 避免使用者(或惡意請求)把 override_value 塞成內網/雲端 metadata 網址,
    # 讓伺服器代為對任意主機發出 SSRF 請求, 見 _discord_send_core() 直接把 url 丟給 requests.post()
    return bool(url) and bool(_DISCORD_WEBHOOK_URL_RE.match(url.strip()))


def _discord_send_core(url, message, title='aniGamerPlus 通知'):
    # 回傳 (ok, info), 同上
    data = {
        'content': None,
        'embeds': [{
            'title': title,
            'description': message,
            'color': 5814783,
        }]
    }
    r = requests.post(url, json=data, timeout=10)
    if r.status_code == 204:
        return True, ''
    return False, 'Discord 回應: ' + r.text


_TELEGRAM_BAD_GATEWAY_MAX_RETRY = 3
_TELEGRAM_BAD_GATEWAY_RETRY_DELAY = 3  # 秒


def _telegram_send_with_retry(token, message, settings):
    # 只針對 "Bad Gateway" 自動重試: 這是 Telegram 伺服器端暫時性問題(502), 稍等幾秒重試通常就會成功;
    # 其他失敗原因(Token/聊天室ID設定錯誤、訊息格式錯誤等)重試沒有意義, 只會延遲使用者發現設定錯誤的時間
    ok, info = _telegram_send_core(token, message, settings)
    retry_count = 0
    while not ok and 'Bad Gateway' in info and retry_count < _TELEGRAM_BAD_GATEWAY_MAX_RETRY:
        retry_count += 1
        __color_print(0, 'TG NOTIFY', '收到 Bad Gateway, ' + str(_TELEGRAM_BAD_GATEWAY_RETRY_DELAY) +
                      '秒後自動重試(第' + str(retry_count) + '/' + str(_TELEGRAM_BAD_GATEWAY_MAX_RETRY) + '次)',
                      no_sn=True, display=False)
        time.sleep(_TELEGRAM_BAD_GATEWAY_RETRY_DELAY)
        ok, info = _telegram_send_core(token, message, settings)
    if not ok and retry_count >= _TELEGRAM_BAD_GATEWAY_MAX_RETRY and 'Bad Gateway' in info:
        info = info + '(已自動重試 ' + str(_TELEGRAM_BAD_GATEWAY_MAX_RETRY) + ' 次仍失敗)'
    return ok, info


def _send_telegram_notification(category, message):
    settings = read_settings()
    token = settings.get('telebot_token')
    if not token:
        return
    try:
        ok, info = _telegram_send_with_retry(token, message, settings)
        NotifyDB.log_history('telegram', category, message, ok, None if ok else info)
        if not ok:
            __color_print(0, 'TG NOTIFY ERROR', info, status=1, no_sn=True)
    except Exception as e:
        NotifyDB.log_history('telegram', category, message, False, str(e))
        __color_print(0, 'TG NOTIFY ERROR', 'Exception: ' + str(e), status=1, no_sn=True)


def retry_telegram_notification(history_id):
    # 供 Dashboard 通知歷史「手動重試」按鈕使用: 只針對這一筆歷史紀錄的原始內容重新發送一次,
    # 不套用 _telegram_send_with_retry() 的自動重試迴圈(使用者已經明確按下重試, 失敗就直接回報結果,
    # 不需要再自動等 3 次), 成功/失敗都另外記一筆新的歷史紀錄, 保留原始那筆失敗紀錄不覆寫
    row = NotifyDB.get_history_row('telegram', history_id)
    if not row:
        return False, '找不到這筆歷史紀錄'
    settings = read_settings()
    token = settings.get('telebot_token')
    if not token:
        return False, '尚未設定 Telegram Bot Token'
    try:
        ok, info = _telegram_send_core(token, row['message'], settings)
    except Exception as e:
        ok, info = False, 'Exception: ' + str(e)
    NotifyDB.log_history('telegram', row['subcategory'], row['message'], ok, None if ok else info)
    return (True, '手動重試成功') if ok else (False, info)


def _send_discord_notification(category, settings, message, title='aniGamerPlus 通知'):
    url = settings.get('discord_token')
    if not url:
        return
    try:
        ok, info = _discord_send_core(url, message, title=title)
        NotifyDB.log_history('discord', category, message, ok, None if ok else info)
        if not ok:
            __color_print(0, 'Discord NOTIFY ERROR', 'Exception: Send msg error\n' + info, status=1, no_sn=True)
    except Exception as e:
        NotifyDB.log_history('discord', category, message, False, str(e))
        __color_print(0, 'Discord NOTIFY ERROR', 'Exception: ' + str(e), status=1, no_sn=True)


def send_test_notification(channel, override_value=None):
    # 供 Dashboard「發送測試訊息」按鈕使用: override_value 是使用者目前輸入框裡打的新值(尚未儲存時仍可測試),
    # 沒有的話才退回使用已儲存的設定值。回傳 (ok, info) 讓前端直接顯示結果, 不像 send_notification() 只寫入 log
    settings = read_settings()
    message = '此為 aniGamerPlus 客製強化版 ' + aniGamerPlus_version + ' 發送的測試訊息'
    try:
        if channel == 'telegram':
            token = override_value or settings.get('telebot_token')
            if not token:
                return False, '尚未設定 Telegram Bot Token'
            ok, info = _telegram_send_core(token, message, settings)
            return (True, '測試訊息已送出, 請確認 Telegram 是否收到') if ok else (False, info)
        elif channel == 'discord':
            url = override_value or settings.get('discord_token')
            if not url:
                return False, '尚未設定 Discord Webhook URL'
            if not is_valid_discord_webhook_url(url):
                return False, 'Discord Webhook URL 格式不正確, 需為 https://discord.com/api/webhooks/... 開頭的網址'
            ok, info = _discord_send_core(url, message, title=notify_title('消息'))
            return (True, '測試訊息已送出, 請確認 Discord 是否收到') if ok else (False, info)
        return False, '不明的測試管道'
    except Exception as e:
        return False, 'Exception: ' + str(e)


def send_notify_template_test(category):
    # 供 Dashboard「模板測試」按鈕使用: 跟 send_notification() 不同, 這裡刻意忽略「通知類別」開關與冷卻時間限制
    # (使用者是明確按按鈕要求測試, 不是真的觸發到事件), 直接用該類別目前已儲存的模板(NotifyDB.render_notify_message
    # 讀的是資料庫內容, 不是網頁上還沒存檔的文字)套用範例內容(NotifyDB.SAMPLE_CONTEXT)送出。
    # 回傳每個已啟用管道各自的成功/失敗結果, 讓使用者一次看到 Telegram/Discord 是否都設定正確
    if category not in NotifyDB.NOTIFY_CATEGORY_TO_TEMPLATE:
        return False, '不明的通知類別'
    settings = read_settings()
    title_suffix = NotifyDB.NOTIFY_CATEGORY_TITLE_SUFFIX[category]
    results = []

    if settings.get('telebot_notify'):
        token = settings.get('telebot_token')
        if not token:
            results.append(('Telegram', False, '尚未設定 Bot Token'))
        else:
            message = notify_title(title_suffix) + '\n' + NotifyDB.render_notify_message(category, 'telegram', **NotifyDB.SAMPLE_CONTEXT)
            try:
                ok, info = _telegram_send_core(token, message, settings)
            except Exception as e:
                ok, info = False, str(e)
            NotifyDB.log_history('telegram', category, message, ok, None if ok else info)
            results.append(('Telegram', ok, info))

    if settings.get('discord_notify'):
        url = settings.get('discord_token')
        if not url:
            results.append(('Discord', False, '尚未設定 Webhook URL'))
        else:
            title = notify_title(title_suffix)
            body = NotifyDB.render_notify_message(category, 'discord', **NotifyDB.SAMPLE_CONTEXT)
            try:
                ok, info = _discord_send_core(url, body, title=title)
            except Exception as e:
                ok, info = False, str(e)
            NotifyDB.log_history('discord', category, body, ok, None if ok else info)
            results.append(('Discord', ok, info))

    if not results:
        return False, '尚未啟用 Telegram 或 Discord 通知, 請先在上方開啟並儲存設定'

    all_ok = all(ok for _, ok, _ in results)
    summary = '\n'.join((name + '：成功' if ok else name + '：失敗 - ' + info) for name, ok, info in results)
    return all_ok, summary


def fetch_telegram_chat_id(override_value=None):
    # 供 Dashboard「取得Chat ID」按鈕使用: 只查 getUpdates 找出最近曾傳訊息給這個 Bot 的對話, 不涉及發送任何訊息。
    # override_value 同 send_test_notification(): 使用者目前輸入框裡打的新 token(尚未儲存)優先, 留空才用已儲存的
    settings = read_settings()
    token = override_value or settings.get('telebot_token')
    if not token:
        return False, '尚未設定 Telegram Bot Token'
    try:
        updates = requests.get(f'https://api.telegram.org/bot{token}/getUpdates', timeout=10).json()
        if not updates.get('ok'):
            return False, 'Telegram 回應: ' + updates.get('description', str(updates))
        results = updates.get('result') or []
        if not results:
            return False, ('尚未偵測到與這個 Bot 的對話紀錄, 請先在 Telegram 搜尋你設定的 Bot 並傳送任意訊息'
                            '(例如 /start)給它, 再按一次這個按鈕')
        chat_id = results[-1]['message']['chat']['id']  # 取最新一則, 避免永遠只抓第一次互動的舊對話
        return True, str(chat_id)
    except Exception as e:
        return False, 'Exception: ' + str(e)


def __remove_superfluous_logs(max_num):
    if os.path.exists(logs_dir):
        logs_list = [x for x in os.listdir(logs_dir) if 'web' not in x]
        if len(logs_list) > max_num:
            logs_list.sort()
            logs_need_remove = logs_list[0:len(logs_list) - max_num]
            for log in logs_need_remove:
                log_path = os.path.join(logs_dir, log)
                os.remove(log_path)
                __color_print(0, '刪除過期日誌: ' + log, no_sn=True, display=False)


def write_settings(web_config):
    # Dashboard 有好幾支窄範圍端點(例如新增/移除喜好路徑、略過版本通知、改登入密碼)不是走完整設定表單,
    # 而是自己呼叫 read_settings() 拿一份「目前設定」當底稿, 只改動跟自己相關的一兩個欄位, 就把整包
    # 原樣交給這裡寫回。若 bangumi_dir/temp_dir 目前連不到(網路磁碟/UNC 路徑離線), 那份底稿裡的值其實
    # 已經被 read_settings() 換成本機預設目錄, 不是使用者原本設定的路徑; 呼叫端根本沒打算動這兩個欄位,
    # 卻會被下面「等於預設目錄就存回空字串」的還原步驟誤判成「使用者本來就是設定預設目錄」, 把原始路徑
    # 永久洗掉, 之後 NAS 恢復連線也救不回來。這裡偵測到「拿到的值剛好等於目前記錄的暫代值, 且該欄位
    # 確實處於連不到狀態」時, 換回原本設定的路徑, 呼叫端若是真的要清空(例如「暫時改用本機預設資料夾」
    # 功能, 見 Dashboard/Server.py 的 path_fallback_use_default()), 會明確地把欄位設成空字串, 不等於
    # 這個暫代值, 不受影響
    for _field in ('bangumi_dir', 'temp_dir'):
        if (path_fallback_state.get(_field + '_unreachable')
                and (web_config.get(_field) or '') == path_fallback_state.get('fallback_' + _field, '')):
            web_config[_field] = path_fallback_state.get('configured_' + _field, '')

    # 先記下呼叫端原本填的路徑: read_settings() 正規化時, 若 bangumi_dir/temp_dir 設定的是目前連不到的
    # 網路磁碟/UNC 路徑(NAS 關機/斷線), 會暫時換成本機預設目錄; 下面「等於預設目錄就存回空字串」的還原步驟
    # 若直接看正規化後的值, 會把使用者真正設定的路徑當成「本來就是預設值」而永久抹掉, 之後 NAS 恢復連線
    # 也救不回來(這是實測踩到的資料流失 bug, 不是理論上的邊界情況)
    raw_bangumi_dir = web_config.get('bangumi_dir', '') or ''
    raw_temp_dir = web_config.get('temp_dir', '') or ''
    web_config = read_settings(web_config)  # 正規化配置

    # 還原配置
    a = os.path.join(working_dir, 'bangumi')  # 默認番劇目錄
    b = os.path.join(working_dir, 'temp')  # 默認緩存目錄

    def _restore_path(normalized, raw, default_dir):
        if os.path.normcase(normalized) != os.path.normcase(default_dir):
            return normalized  # 沒有被 read_settings() 換成預設目錄, 原樣保留
        if not raw or os.path.normcase(os.path.abspath(raw)) == os.path.normcase(default_dir):
            return ''  # 使用者本來就是留空/設定的就是預設目錄, 維持原本存空字串的行為
        return raw  # 使用者設定的是別的路徑, 只是暫時連不上: 保留原值, 不要存成空字串

    web_config['bangumi_dir'] = _restore_path(web_config['bangumi_dir'], raw_bangumi_dir, a)
    web_config['temp_dir'] = _restore_path(web_config['temp_dir'], raw_temp_dir, b)
    del web_config['working_dir']
    del web_config['aniGamerPlus_version']
    del web_config['use_gost']

    # 配置寫入資料庫
    _set_config_row(web_config)


def is_debug_mode_enabled():
    return bool(read_settings().get('debug_mode'))


def toggle_debug_mode():
    # 供 Dashboard 隱藏開關使用(見 aniGamerPlus.js 的 toc.icu 觸發邏輯): 故意不走 read_settings()/write_settings()
    # 那套路徑正規化(bangumi_dir/temp_dir 暫時連不到 NAS 時會被解析成本機預設目錄, 見 write_settings() 開頭的說明),
    # 只需要單純翻轉一個布林值, 直接讀寫底層原始設定內容, 避免切換這個隱藏開關時意外把使用者設定的網路路徑洗掉
    settings = __read_settings_file()
    settings['debug_mode'] = not settings.get('debug_mode', False)
    _set_config_row(settings)
    return settings['debug_mode']


# v25.1.8 起 config.json/sn_list.txt 等都改存進 aniGamer.db, 一般使用者沒有工具可以直接打開 sqlite 資料庫;
# 啟動流程中偵測到「需要修改某項設定才能繼續」的異常時(目前僅 Dashboard port 被佔用一種), 產生這個純文字檔
# 讓使用者能用記事本手動修改, 下次啟動時會自動讀取驗證並套用進資料庫, 套用成功後這個檔案就會被刪除
emergency_recovery_path = os.path.join(working_dir, 'emergency_fix.txt')


def write_emergency_recovery_file(port):
    content = (
        '# aniGamerPlus 啟動異常修復用暫存檔案\n'
        '# 偵測到 Web 控制面板啟動失敗(port 被佔用), 請將下方 dashboard_port 改成目前沒有被佔用的數字(1~65535),\n'
        '# 存檔後重新啟動 aniGamerPlus.exe, 套用成功後這個檔案會被自動刪除\n'
        'dashboard_port=' + str(port) + '\n'
    )
    try:
        with open(emergency_recovery_path, 'w', encoding='utf-8') as f:
            f.write(content)
    except OSError as e:
        __color_print(0, '啟動修復檔案', '建立時發生錯誤: ' + str(e), status=1, no_sn=True)


def apply_emergency_recovery_file():
    if not os.path.exists(emergency_recovery_path):
        return

    try:
        with open(emergency_recovery_path, 'r', encoding='utf-8') as f:
            lines = f.readlines()
    except OSError as e:
        __color_print(0, '啟動修復檔案', '讀取時發生錯誤: ' + str(e), status=1, no_sn=True)
        return

    values = {}
    for line in lines:
        line = line.strip()
        if not line or line.startswith('#') or '=' not in line:
            continue
        key, _, value = line.partition('=')
        values[key.strip()] = value.strip()

    applied = []
    errors = []

    if 'dashboard_port' in values:
        raw = values['dashboard_port']
        if re.match(r'^\d+$', raw) and 1 <= int(raw) <= 65535:
            new_settings = read_settings()
            new_settings['dashboard']['port'] = int(raw)
            write_settings(new_settings)
            applied.append('dashboard_port=' + raw)
        else:
            errors.append('dashboard_port 必須是 1~65535 之間的整數, 目前內容「' + raw + '」不合法')

    if errors:
        # 內容有誤: 保留檔案讓使用者修正後重新啟動再試一次, 不刪除也不套用
        __color_print(0, '啟動修復檔案', '內容有誤尚未套用: ' + '; '.join(errors), status=1, no_sn=True)
        return

    if applied:
        __color_print(0, '啟動修復檔案', '已套用設定變更(' + ', '.join(applied) + '), 並移除此暫存檔案',
                      status=2, no_sn=True)

    try:
        os.remove(emergency_recovery_path)
    except OSError:
        pass


# set_ja3_options() 只會對「自訂 ja3 擴展清單」與這組 curl_cffi 內建預設啟用擴展的差異部分呼叫 toggle_extension(),
# 完全相同的擴展編號不會被觸發 toggle, 所以只有「差異」的部分才可能踩到 curl_cffi 尚未實作的擴展編號而崩潰
# (對照 curl_cffi.requests.utils.toggle_extensions_by_ids 的邏輯)
_JA3_DEFAULT_ENABLED_EXTENSIONS = {0, 10, 11, 13, 16, 23, 35, 43, 45, 51, 65281}


def sanitize_ja3(ja3_string):
    # 檢查自訂 ja3 指紋裡「需要被切換」的 TLS 擴展是否能被目前安裝的 curl_cffi 版本處理,
    # 自動修正任何會導致 NotImplementedError 的擴展編號(例如新版瀏覽器帶有的 41/pre_shared_key),
    # 避免使用者存檔的自訂指紋在實際發送請求時才崩潰
    # 回傳 (修正後的 ja3 字串, 有變動的擴展編號 list); 解析失敗/無需修正時原樣返回, 變動列表為空
    if not ja3_string:
        return ja3_string, []
    try:
        from curl_cffi import Curl
        from curl_cffi.requests.impersonate import toggle_extension

        parts = ja3_string.split(',')
        if len(parts) != 5:
            return ja3_string, []
        tls_version, ciphers, extensions_str, curves, point_formats = parts
        if not extensions_str:
            return ja3_string, []

        ext_ids_ordered = [int(e) for e in extensions_str.split('-')]
        extension_ids_set = set(ext_ids_ordered)
        to_enable = extension_ids_set - _JA3_DEFAULT_ENABLED_EXTENSIONS
        to_disable = _JA3_DEFAULT_ENABLED_EXTENSIONS - extension_ids_set

        probe = Curl()
        remove_ids = set()  # 想啟用但目前版本無法切換 -> 從字串中移除
        add_ids = set()  # 想停用但目前版本無法切換 -> 補回字串裡(維持預設啟用狀態, 至少不會崩潰)
        try:
            for ext_id in to_enable:
                try:
                    toggle_extension(probe, ext_id, True)
                except NotImplementedError:
                    remove_ids.add(ext_id)
            for ext_id in to_disable:
                try:
                    toggle_extension(probe, ext_id, False)
                except NotImplementedError:
                    add_ids.add(ext_id)
        finally:
            probe.close()

        if not remove_ids and not add_ids:
            return ja3_string, []

        cleaned_ids = [e for e in ext_ids_ordered if e not in remove_ids]
        cleaned_ids.extend(sorted(add_ids - set(cleaned_ids)))
        new_ja3 = ','.join([tls_version, ciphers, '-'.join(map(str, cleaned_ids)), curves, point_formats])
        return new_ja3, sorted(remove_ids | add_ids)
    except BaseException as e:
        # 解析/探測失敗一律視為安全, 不動使用者原本的設定, 避免這個檢查機制本身變成新的崩潰來源
        __color_print(0, 'ja3自動檢測', f'檢測 ja3 相容性時發生未知錯誤(已略過, 不影響原本設定): {str(e)}', status=1, no_sn=True)
        return ja3_string, []


def sanitize_ja3_akamai_in_settings(settings):
    # 對 settings dict 裡的 ja3 就地檢測並修正, 若有修正會記錄警告訊息; 回傳是否有變動(供呼叫端決定是否需要重新寫檔)
    ja3 = settings.get('ja3', '')
    akamai = settings.get('akamai', '')
    if not (ja3 and akamai):
        return False
    new_ja3, changed = sanitize_ja3(ja3)
    if not changed:
        return False
    settings['ja3'] = new_ja3
    __color_print(0, 'ja3自動修正',
                  f'自訂 ja3 指紋包含 curl_cffi 目前無法處理的 TLS 擴展編號 {changed}, 已自動修正並儲存, '
                  '不需手動處理; 若指紋不是最新採集的, 建議重新採集一次以取得最準確的版本',
                  status=1, no_sn=True)
    return True


def write_sn_list(sn_list_content):
    _set_sn_list_row(sn_list_content)


def update_sn_list_schedule(changes):
    # changes: {sn(int): (weekday_zh(str, 一~日), 'HH:MM')}, 用於「取得當前新番更新時間」功能寫回排程標籤
    # 只改動目標 sn 那一行的 *星期* $HH:MM$ 標籤, 其餘標籤(分類/模式/重命名/注釋)原封不動保留
    if not changes:
        return get_sn_list_content()

    content = get_sn_list_content()
    if not content:
        return content

    lines = content.splitlines(keepends=True)

    new_lines = []
    for line in lines:
        has_newline = line.endswith('\n')
        raw = line[:-1] if has_newline else line

        comment_match = re.search(r'#.*$', raw)
        comment = comment_match.group(0) if comment_match else ''
        body = raw[:comment_match.start()] if comment_match else raw

        stripped_body = re.sub(r' +', ' ', body).strip()
        sn_match = re.match(r'^(\d+)( |$)', stripped_body)
        if not sn_match or int(sn_match.group(1)) not in changes:
            new_lines.append(line)
            continue

        weekday_zh, time_str = changes[int(sn_match.group(1))]
        body_without_schedule = re.sub(r'\*[^*]*\*', '', body)
        body_without_schedule = re.sub(r'\$[^$]*\$', '', body_without_schedule)
        body_without_schedule = re.sub(r' +', ' ', body_without_schedule).rstrip()
        new_body = body_without_schedule + ' *' + weekday_zh + '* $' + time_str + '$'
        new_line = new_body + (' ' + comment if comment else '')
        new_lines.append(new_line + ('\n' if has_newline else ''))

    return ''.join(new_lines)


def get_local_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(('8.8.8.8', 80))
        local_ip = s.getsockname()[0]
    except OSError:
        local_ip = '127.0.0.1'
    finally:
        s.close()
    return local_ip


def parse_proxy(proxy_str: str) -> dict:
    if len(proxy_str) == 0 or proxy_str.isspace():
        return {}

    result = {}

    if re.match(r'.*@.*', proxy_str):
        proxy_user = re.sub(r':(\/\/)?', '', re.findall(r':\/\/.*?:', proxy_str)[0])
        proxy_passwd = re.sub(r'(:\/\/:)?@?', '', re.sub(proxy_user, '', re.findall(r':.*@', proxy_str)[0]))
        result['proxy_user'] = proxy_user
        result['proxy_passwd'] = proxy_passwd
        proxy_str = proxy_str.replace(proxy_user + ':' + proxy_passwd + '@', '')
    else:
        result['proxy_user'] = None
        result['proxy_passwd'] = None

    proxy_protocol = re.sub(r':\/\/.*', '', proxy_str).upper()
    proxy_ip = re.sub(r':(\/\/)?', '', re.findall(r':.*:', proxy_str)[0])
    proxy_port = re.sub(r':', '', re.findall(r':\d+', proxy_str)[0])

    result['proxy_protocol'] = proxy_protocol
    result['proxy_ip'] = proxy_ip
    result['proxy_port'] = proxy_port

    return result


if __name__ == '__main__':
    pass
