#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# 監視公告(gossip)資料層(v25.2.0): 取代舊版 gossip_log.jsonl/gossip_disposition_log.jsonl/gossip_pending.json
# 三份散落檔案, 全部改存進 aniGamer.db, 每個欄位都是獨立的資料表欄位(而不是整包塞進一個 JSON 字串欄位),
# 用 DB 瀏覽器打開時每一列都能直接看懂、直接改, 不會看到一長串難以閱讀的 blob。
#
# 寫法沿用 NotifyDB.py 的慣例: 純 sqlite3 無 ORM, 自己的鎖(_gossip_db_lock)與自己的 working_dir 計算,
# 刻意不 import Config(避免循環引用, Config.py/Gossip.py 都需要在模組層級用到這裡)。
#
# 三張表:
#   gossip_log     每則「不重複的」公告原文, source_hash 唯一, 只新增不刪除(永久紀錄); 同一則公告在網站上
#                   停留期間重複偵測到時直接略過(不再重複寫入), 取代舊版每次偵測都 append 一行、歷史紀錄
#                   會被同一則公告洗版的問題
#   gossip_events  每則公告拆解出的子事件(一則公告可能同時提到好幾部作品), 對應「歷史公告」「操作處置」
#                   「機動調整」畫面要顯示的每一列, 只新增不刪除(永久紀錄); 使用者透過「操作處置」畫面
#                   confirm 的處置結果也存在這張表的 disposition/disposition_locked 欄位
#   gossip_pending 目前生效中的臨時排程覆蓋/追蹤狀態, 完成或放棄後依保存天數清理(沿用舊版 gossip_pending.json
#                   的角色), 新增 event_id 欄位回指建立它的那一列 gossip_events, 供畫面對照

import os
import re
import sys
import json
import sqlite3
import threading
import datetime
from contextlib import closing

if getattr(sys, 'frozen', False):
    working_dir = os.path.dirname(sys.executable)
else:
    working_dir = os.path.dirname(os.path.realpath(__file__))

gossip_db_path = os.path.join(working_dir, 'aniGamer.db')
_gossip_db_lock = threading.Lock()

# 六種狀態判斷結果 -> 系統預設的處置建議(操作處置畫面的下拉選單預設值); 使用者可以蓋過這個預設值
STATUS_LABELS = ('暫停更新', '提前更新', '延後更新', '同時更新', '暫時下架', '無法判斷')
DISPOSITION_OPTIONS = ('等待處置', '本週暫停更新', '本週提前更新', '本週延後更新', '本週同時更新',
                        '自訂更新時間', '自訂連續更新時間', '自訂時間範圍', '忽略此公告', '本週下架')
STATUS_TO_DEFAULT_DISPOSITION = {
    '暫停更新': '本週暫停更新',
    '提前更新': '本週提前更新',
    '延後更新': '本週延後更新',
    '同時更新': '本週同時更新',
    '暫時下架': '本週下架',
    '無法判斷': '等待處置',
}


def _get_db_connection():
    return sqlite3.connect(gossip_db_path, timeout=10)


def now_str():
    return datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')


def _ensure_tables():
    with closing(_get_db_connection()) as conn:
        cursor = conn.cursor()
        _do_ensure_tables(conn, cursor)


def _do_ensure_tables(conn, cursor):
    cursor.execute('CREATE TABLE IF NOT EXISTS gossip_log ('
                    'id INTEGER PRIMARY KEY AUTOINCREMENT,'
                    'captured_at TIMESTAMP NOT NULL,'
                    'raw_text TEXT NOT NULL,'
                    'source_hash TEXT NOT NULL UNIQUE)')
    cursor.execute('CREATE TABLE IF NOT EXISTS gossip_events ('
                    'id INTEGER PRIMARY KEY AUTOINCREMENT,'
                    'source_hash TEXT NOT NULL,'
                    'processed_at TIMESTAMP NOT NULL,'
                    'raw_clause TEXT NOT NULL,'
                    'action TEXT NOT NULL,'                  # pause/delay/extra_episode/takedown/manual_review/log_only
                    'match_status TEXT NOT NULL,'             # no_target/unmatched/matched
                    'title_in_gossip TEXT,'
                    'match_method TEXT,'
                    'sn INTEGER,'
                    'name TEXT,'
                    'status_label TEXT NOT NULL,'             # 暫停更新/提前更新/延後更新/同時更新/暫時下架/無法判斷
                    'episode_display TEXT NOT NULL DEFAULT "-",'
                    'target_date TEXT,'                       # 這個子事件算出來的目標日期(可空: 無法算出時間時為空)
                    'target_time TEXT,'
                    'target_time_start TEXT,'                 # 模糊時段公告(只有相對日期詞+時段詞, 沒有明確 HH:MM)的查詢範圍起訖
                    'target_time_end TEXT,'
                    'system_suggestion TEXT NOT NULL,'
                    'disposition TEXT NOT NULL,'
                    'disposition_locked INTEGER NOT NULL DEFAULT 0,'
                    'disposition_applied INTEGER NOT NULL DEFAULT 0,'
                    'custom_check_date TEXT,'
                    'custom_check_time TEXT,'
                    'custom_check_time_start TEXT,'           # 使用者手動選「自訂時間範圍」處置方式時填寫的起訖
                    'custom_check_time_end TEXT,'
                    'custom_episode_count INTEGER,'
                    'disposition_updated_at TIMESTAMP,'
                    'search_candidates_json TEXT)')
    cursor.execute('CREATE TABLE IF NOT EXISTS gossip_pending ('
                    'id TEXT PRIMARY KEY,'
                    'event_id INTEGER,'
                    'sn INTEGER NOT NULL,'
                    'name TEXT,'
                    'type TEXT NOT NULL,'                     # override_check_time / override_check_window / skip_check
                    'check_date TEXT NOT NULL,'
                    'check_time TEXT,'
                    'check_time_start TEXT,'                  # override_check_window 專用: 範圍起訖, 範圍內每分鐘檢查一次
                    'check_time_end TEXT,'
                    'expect_episode_count INTEGER DEFAULT 1,'
                    'found_episode_count INTEGER DEFAULT 0,'
                    'resume_date TEXT,'
                    'status TEXT NOT NULL DEFAULT "pending",'  # pending/done/expired
                    'retry_enabled INTEGER DEFAULT 0,'
                    'retry_interval_minutes INTEGER,'
                    'retry_deadline TEXT,'
                    'checked_once INTEGER DEFAULT 0,'
                    'seen_episodes TEXT,'
                    'next_retry_at TEXT,'
                    'created_at TEXT NOT NULL,'
                    'updated_at TEXT NOT NULL,'
                    'source_hash TEXT)')
    # 舊版資料庫(v25.2.3 以前建立)沒有以下欄位, 補上去避免既有安裝升級後直接炸掉;
    # 沿用 Config.py 的 SELECT COUNT(col) 探測寫法(ALTER TABLE ADD COLUMN 沒有 IF NOT EXISTS 可用)
    for table, column, coltype in (
        ('gossip_events', 'target_time_start', 'TEXT'), ('gossip_events', 'target_time_end', 'TEXT'),
        ('gossip_events', 'custom_check_time_start', 'TEXT'), ('gossip_events', 'custom_check_time_end', 'TEXT'),
        ('gossip_pending', 'check_time_start', 'TEXT'), ('gossip_pending', 'check_time_end', 'TEXT'),
    ):
        try:
            cursor.execute('SELECT ' + column + ' FROM ' + table + ' LIMIT 1')
        except sqlite3.OperationalError as e:
            if 'no such column' in str(e):
                cursor.execute('ALTER TABLE ' + table + ' ADD COLUMN ' + column + ' ' + coltype)
    conn.commit()


_ensure_tables()


# ---------------------------------------------------------------------------
# gossip_log
# ---------------------------------------------------------------------------

def record_gossip_text(raw_text, source_hash, captured_at=None):
    # 回傳 True 代表這是「這則公告文字第一次出現」, 呼叫端才需要往下解析/建立子事件;
    # 回傳 False 代表同一則公告先前已經處理過(內容完全相同), 這次偵測直接略過, 不重複寫入
    captured_at = captured_at or now_str()
    with _gossip_db_lock:
        conn = _get_db_connection()
        try:
            conn.execute('INSERT INTO gossip_log (captured_at, raw_text, source_hash) VALUES (?, ?, ?)',
                         (captured_at, raw_text, source_hash))
            conn.commit()
            return True
        except sqlite3.IntegrityError:
            return False
        finally:
            conn.close()


# ---------------------------------------------------------------------------
# gossip_events
# ---------------------------------------------------------------------------

def add_event(source_hash, processed_at, record):
    # record 是 Gossip.py 組好的一個子事件 dict, 詳見 Gossip.py 呼叫處的欄位說明
    status_label = record.get('status_label', '無法判斷')
    system_suggestion = STATUS_TO_DEFAULT_DISPOSITION.get(status_label, '等待處置')
    with _gossip_db_lock:
        with closing(_get_db_connection()) as conn:
            cursor = conn.execute(
                'INSERT INTO gossip_events (source_hash, processed_at, raw_clause, action, match_status, '
                'title_in_gossip, match_method, sn, name, status_label, episode_display, target_date, target_time, '
                'target_time_start, target_time_end, system_suggestion, disposition, disposition_locked, '
                'disposition_applied, search_candidates_json) '
                'VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 0, ?)',
                (source_hash, processed_at, record.get('raw_clause', ''), record.get('action', 'log_only'),
                 record.get('match', 'no_target'), record.get('title_in_gossip'), record.get('match_method'),
                 record.get('sn'), record.get('name'), status_label, record.get('episode_display', '-'),
                 record.get('target_date'), record.get('target_time'), record.get('target_time_start'),
                 record.get('target_time_end'), system_suggestion, system_suggestion,
                 json.dumps(record.get('search_candidates', []), ensure_ascii=False)))
            conn.commit()
            event_id = cursor.lastrowid
    return event_id


def _row_to_event_dict(row, columns):
    return dict(zip(columns, row))


_EVENT_COLUMNS = ('id', 'source_hash', 'processed_at', 'raw_clause', 'action', 'match_status', 'title_in_gossip',
                   'match_method', 'sn', 'name', 'status_label', 'episode_display', 'target_date', 'target_time',
                   'target_time_start', 'target_time_end', 'system_suggestion', 'disposition', 'disposition_locked',
                   'disposition_applied', 'custom_check_date', 'custom_check_time', 'custom_check_time_start',
                   'custom_check_time_end', 'custom_episode_count', 'disposition_updated_at',
                   'search_candidates_json')


def get_history(limit=200, offset=0):
    # 歷史公告: 全部子事件, 依處理時間新到舊排序
    with _gossip_db_lock:
        with closing(_get_db_connection()) as conn:
            rows = conn.execute(
                'SELECT ' + ','.join(_EVENT_COLUMNS) + ' FROM gossip_events '
                'ORDER BY processed_at DESC, id DESC LIMIT ? OFFSET ?', (limit, offset)).fetchall()
            total = conn.execute('SELECT COUNT(*) FROM gossip_events').fetchone()[0]
    return [_row_to_event_dict(r, _EVENT_COLUMNS) for r in rows], total


def get_actionable(today_str):
    # 操作處置: 目標日期尚未過去(或根本算不出目標日期, 代表還沒人工確認過)的子事件才顯示,
    # 且排除該公告要求的更新其實已經抓到並下載完成的項目(對應的機動調整臨時排程 status='done',
    # 見 gossip_pending), 這種情況不需要使用者再確認處置方式, 依處理時間新到舊排序
    with _gossip_db_lock:
        with closing(_get_db_connection()) as conn:
            rows = conn.execute(
                'SELECT ' + ','.join(_EVENT_COLUMNS) + ' FROM gossip_events '
                'WHERE target_date IS NULL OR target_date >= ? '
                'ORDER BY processed_at DESC, id DESC', (today_str,)).fetchall()
            pending_rows = conn.execute(
                'SELECT ' + ','.join(_PENDING_COLUMNS) + ' FROM gossip_pending '
                'WHERE event_id IS NOT NULL ORDER BY rowid').fetchall()
    # 同一個 event_id 可能有多筆歷史 gossip_pending 紀錄(使用者事後又改過一次處置方式), 只看
    # 最新(最後寫入)那一筆的狀態; gossip_pending.id 是 uuid 字串(非自增數字, 無法用來判斷先後),
    # 改用 SQLite 內建的 rowid 依插入順序排序, pending_rows 已由舊到新排序, 後寫入的會覆蓋前面的, 天然就是最新值
    latest_status_by_event = {}
    for r in pending_rows:
        d = _pending_row_to_dict(r)
        latest_status_by_event[d['event_id']] = d['status']
    events = [_row_to_event_dict(r, _EVENT_COLUMNS) for r in rows]
    # 已經手動確認過「忽略此公告」的項目也排除, 不然使用者明確選了忽略、按下確認之後, 這則公告還是會
    # 一直留在畫面上等到目標日期過去才消失, 等於「確認」按了跟沒按一樣; 這個排除條件同時也是 v25.2.3
    # 新增的「公告從官方頁面撤下時自動標記忽略」(見 Gossip.py 的 _expire_vanished_events())能讓項目
    # 真正從這個畫面消失的關鍵——那邊呼叫 apply_disposition_for_event(..., locked=True) 就是靠這裡濾掉
    return [e for e in events if latest_status_by_event.get(e['id']) != 'done'
            and not (e['disposition'] == '忽略此公告' and e['disposition_locked'])]


def get_event(event_id):
    with _gossip_db_lock:
        with closing(_get_db_connection()) as conn:
            row = conn.execute('SELECT ' + ','.join(_EVENT_COLUMNS) + ' FROM gossip_events WHERE id=?',
                                (event_id,)).fetchone()
    return _row_to_event_dict(row, _EVENT_COLUMNS) if row else None


def set_manual_sn(event_id, sn, name):
    # 供操作處置畫面「選擇指定排程」使用: 公告內容無法自動比對到追蹤作品時(match_status='unmatched'),
    # 讓使用者從自己的排程清單裡手動指定這則子事件對應哪個 sn, 之後才能繼續套用處置方式(Gossip.apply_disposition_for_event
    # 需要 sn 才能建立臨時排程覆蓋); match_method 記為 'manual' 以便跟系統自動搜尋比對到的結果區分
    with _gossip_db_lock:
        with closing(_get_db_connection()) as conn:
            conn.execute(
                'UPDATE gossip_events SET sn=?, name=?, match_status=?, match_method=? WHERE id=?',
                (sn, name, 'matched', 'manual', event_id))
            conn.commit()


def set_disposition(event_id, disposition, custom_check_date=None, custom_check_time=None,
                     custom_episode_count=None, applied=True, locked=True,
                     custom_check_time_start=None, custom_check_time_end=None):
    # locked=True 代表使用者在「操作處置」畫面手動按過「確認」, 之後系統自動判斷不會再改動這筆;
    # 系統自己套用 system_suggestion(機動調整時間開啟時的自動處置)呼叫這裡時要傳 locked=False,
    # 否則畫面會顯示成「已手動確認」, 使用者無法分辨這筆到底是系統自動套用的還是自己確認過的
    with _gossip_db_lock:
        with closing(_get_db_connection()) as conn:
            conn.execute(
                'UPDATE gossip_events SET disposition=?, disposition_locked=?, disposition_applied=?, '
                'custom_check_date=?, custom_check_time=?, custom_check_time_start=?, custom_check_time_end=?, '
                'custom_episode_count=?, disposition_updated_at=? WHERE id=?',
                (disposition, 1 if locked else 0, 1 if applied else 0, custom_check_date, custom_check_time,
                 custom_check_time_start, custom_check_time_end, custom_episode_count, now_str(), event_id))
            conn.commit()


# ---------------------------------------------------------------------------
# gossip_pending
# ---------------------------------------------------------------------------

_PENDING_COLUMNS = ('id', 'event_id', 'sn', 'name', 'type', 'check_date', 'check_time', 'check_time_start',
                     'check_time_end', 'expect_episode_count', 'found_episode_count', 'resume_date', 'status',
                     'retry_enabled', 'retry_interval_minutes', 'retry_deadline', 'checked_once', 'seen_episodes',
                     'next_retry_at', 'created_at', 'updated_at', 'source_hash')


def _pending_row_to_dict(row):
    d = dict(zip(_PENDING_COLUMNS, row))
    d['seen_episodes'] = json.loads(d['seen_episodes']) if d['seen_episodes'] else []
    d['retry_enabled'] = bool(d['retry_enabled'])
    d['checked_once'] = bool(d['checked_once'])
    return d


def add_pending(entry):
    # entry 為 dict, 缺少的欄位一律補上合理預設值; 回傳寫入的 id
    entry = dict(entry)
    entry.setdefault('id', None)
    if not entry['id']:
        import uuid
        entry['id'] = uuid.uuid4().hex
    now = now_str()
    entry.setdefault('created_at', now)
    entry.setdefault('updated_at', now)
    entry.setdefault('status', 'pending')
    entry.setdefault('found_episode_count', 0)
    entry.setdefault('expect_episode_count', 1)
    entry.setdefault('retry_enabled', False)
    entry.setdefault('checked_once', False)
    seen_episodes = json.dumps(entry.get('seen_episodes', []))
    with _gossip_db_lock:
        with closing(_get_db_connection()) as conn:
            conn.execute(
                'INSERT INTO gossip_pending (id, event_id, sn, name, type, check_date, check_time, '
                'check_time_start, check_time_end, expect_episode_count, found_episode_count, resume_date, status, '
                'retry_enabled, retry_interval_minutes, retry_deadline, checked_once, seen_episodes, next_retry_at, '
                'created_at, updated_at, source_hash) '
                'VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
                (entry['id'], entry.get('event_id'), entry['sn'], entry.get('name'), entry['type'],
                 entry['check_date'], entry.get('check_time'), entry.get('check_time_start'),
                 entry.get('check_time_end'), entry['expect_episode_count'],
                 entry['found_episode_count'], entry.get('resume_date'), entry['status'],
                 int(bool(entry['retry_enabled'])), entry.get('retry_interval_minutes'), entry.get('retry_deadline'),
                 int(bool(entry['checked_once'])), seen_episodes, entry.get('next_retry_at'), entry['created_at'],
                 entry['updated_at'], entry.get('source_hash')))
            conn.commit()
    return entry['id']


def update_pending(entry_id, **fields):
    if not fields:
        return
    fields = dict(fields)
    if 'seen_episodes' in fields:
        fields['seen_episodes'] = json.dumps(fields['seen_episodes'])
    if 'retry_enabled' in fields:
        fields['retry_enabled'] = int(bool(fields['retry_enabled']))
    if 'checked_once' in fields:
        fields['checked_once'] = int(bool(fields['checked_once']))
    fields['updated_at'] = now_str()
    set_clause = ', '.join(k + '=?' for k in fields)
    with _gossip_db_lock:
        with closing(_get_db_connection()) as conn:
            conn.execute('UPDATE gossip_pending SET ' + set_clause + ' WHERE id=?',
                         tuple(fields.values()) + (entry_id,))
            conn.commit()


def remove_pending_for_event(event_id):
    # 使用者在「操作處置」重新選了一個不同的處置方式時, 先清掉這個子事件先前(若有)建立的舊排程覆蓋,
    # 避免同一則公告疊加出兩筆互相矛盾的臨時排程
    with _gossip_db_lock:
        with closing(_get_db_connection()) as conn:
            conn.execute('DELETE FROM gossip_pending WHERE event_id=? AND status="pending"', (event_id,))
            conn.commit()


def list_pending(status='pending'):
    with _gossip_db_lock:
        with closing(_get_db_connection()) as conn:
            if status:
                rows = conn.execute('SELECT ' + ','.join(_PENDING_COLUMNS) + ' FROM gossip_pending WHERE status=?',
                                     (status,)).fetchall()
            else:
                rows = conn.execute('SELECT ' + ','.join(_PENDING_COLUMNS) + ' FROM gossip_pending').fetchall()
    return [_pending_row_to_dict(r) for r in rows]


def is_skipped(sn, check_date_str):
    with _gossip_db_lock:
        with closing(_get_db_connection()) as conn:
            row = conn.execute(
                'SELECT 1 FROM gossip_pending WHERE sn=? AND type="skip_check" AND status="pending" AND check_date=?',
                (sn, check_date_str)).fetchone()
    return row is not None


def prune_pending(retention_days):
    cutoff = (datetime.datetime.now() - datetime.timedelta(days=retention_days)).strftime('%Y-%m-%d %H:%M:%S')
    with _gossip_db_lock:
        with closing(_get_db_connection()) as conn:
            conn.execute('DELETE FROM gossip_pending WHERE status != "pending" AND updated_at < ?', (cutoff,))
            conn.commit()


# ---------------------------------------------------------------------------
# 舊版三份檔案匯入(v25.1.6~v25.1.9 遺留): 驗證能解析才匯入, 原始檔案保留不自動刪除
# ---------------------------------------------------------------------------

def import_legacy_files_if_needed(gossip_log_path, gossip_disposition_log_path, gossip_pending_path):
    with _gossip_db_lock:
        with closing(_get_db_connection()) as conn:
            already_has_data = conn.execute('SELECT 1 FROM gossip_log LIMIT 1').fetchone() is not None
    if already_has_data:
        return False

    imported_any = False
    if os.path.exists(gossip_log_path):
        try:
            with open(gossip_log_path, 'r', encoding='utf-8') as f:
                lines = [json.loads(l) for l in f if l.strip()]
        except (OSError, json.JSONDecodeError):
            lines = []
        if lines:
            with _gossip_db_lock:
                with closing(_get_db_connection()) as conn:
                    for entry in lines:
                        try:
                            conn.execute('INSERT OR IGNORE INTO gossip_log (captured_at, raw_text, source_hash) '
                                         'VALUES (?, ?, ?)',
                                         (entry['captured_at'], entry['raw_text'], entry['source_hash']))
                        except (KeyError, sqlite3.Error):
                            continue
                    conn.commit()
            imported_any = True

    if os.path.exists(gossip_disposition_log_path):
        try:
            with open(gossip_disposition_log_path, 'r', encoding='utf-8') as f:
                dispositions = [json.loads(l) for l in f if l.strip()]
        except (OSError, json.JSONDecodeError):
            dispositions = []
        for disposition in dispositions:
            source_hash = disposition.get('source_hash', '')
            processed_at = disposition.get('processed_at', now_str())
            for sub in disposition.get('sub_events', []):
                record = {
                    'raw_clause': sub.get('raw_clause', ''), 'action': sub.get('action', 'log_only'),
                    'match': sub.get('match', 'no_target'), 'title_in_gossip': sub.get('title_in_gossip'),
                    'match_method': sub.get('match_method'), 'sn': sub.get('sn'), 'name': sub.get('name'),
                    'status_label': '無法判斷', 'episode_display': '-',
                    'search_candidates': sub.get('search_candidates', []),
                }
                add_event(source_hash, processed_at, record)
        if dispositions:
            imported_any = True

    if os.path.exists(gossip_pending_path):
        try:
            with open(gossip_pending_path, 'r', encoding='utf-8') as f:
                pending_data = json.load(f)
        except (OSError, json.JSONDecodeError):
            pending_data = {'entries': []}
        for e in pending_data.get('entries', []):
            try:
                add_pending({
                    'id': e.get('id'), 'sn': e['sn'], 'name': e.get('name'), 'type': e['type'],
                    'check_date': e['check_date'], 'check_time': e.get('check_time'),
                    'expect_episode_count': e.get('expect_episode_count', 1),
                    'found_episode_count': e.get('found_episode_count', 0),
                    'resume_date': e.get('resume_date'), 'status': e.get('status', 'pending'),
                    'retry_enabled': e.get('retry', {}).get('enabled', False),
                    'retry_interval_minutes': e.get('retry', {}).get('interval_minutes'),
                    'retry_deadline': e.get('retry', {}).get('deadline'),
                    'checked_once': e.get('_checked_once', False), 'seen_episodes': e.get('_seen_episodes', []),
                    'next_retry_at': e.get('next_retry_at'), 'created_at': e.get('created_at', now_str()),
                    'updated_at': e.get('updated_at', now_str()), 'source_hash': e.get('source_hash'),
                })
            except (KeyError, sqlite3.IntegrityError):
                continue
        if pending_data.get('entries'):
            imported_any = True

    return imported_any
