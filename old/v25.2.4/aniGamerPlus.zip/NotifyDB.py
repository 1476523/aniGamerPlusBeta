#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# 通知模板 / 通知歷史 / 通用字符參考列表: 客製強化版獨有功能, 表格跟 Config.py 那批表一樣存進 aniGamer.db,
# 用自己的一把鎖(_notify_db_lock)保護, 跟 Config.py 的 _config_db_lock 各自獨立, 靠 sqlite3.connect 的
# timeout 讓兩把鎖各自持有連線時不會立刻互踩 "database is locked"(沿用 Config.py 對 _config_db_lock 的說明)。
# 寫法沿用 Config.py 的 _get_db_connection()/_ensure_config_tables() 慣例(純 sqlite3, 無 ORM,
# CREATE TABLE IF NOT EXISTS 冪等)。刻意不 import Config, 自己算一份 working_dir, 避免跟 Config.py
# 互相 import 造成循環引用(Config.py 需要在模組層級呼叫這裡的 seed 函式)。

import os
import re
import sys
import html
import sqlite3
import threading
import datetime
from contextlib import closing

if getattr(sys, 'frozen', False):
    working_dir = os.path.dirname(sys.executable)
else:
    working_dir = os.path.dirname(os.path.realpath(__file__))

notify_db_path = os.path.join(working_dir, 'aniGamer.db')
_notify_db_lock = threading.Lock()

# 三個模板表對應的合法 category 清單, 也用來決定畫面上的 optgroup 分組
# 注意: 不含 'new_version'(新版本可用)——v25.2.2 起這則系統通知改成固定格式, 不開放使用者自訂,
# 詳見 Config.send_new_version_notification() 開頭的說明; _ensure_tables() 會清掉舊版本升級留下的舊資料列
TEMPLATE_TABLES = {
    'download': ('download_templates',
                 ['manual_success', 'manual_failed', 'manual_cancelled', 'schedule_success', 'schedule_failed']),
    'announcement': ('announcement_templates',
                      ['pause', 'delay', 'extra_episode', 'other']),
    'system': ('system_templates',
               ['cookie_invalid', 'device_error', 'daily_digest', 'path_unreachable']),
}

# 14 個通知類別 id(對應 settings['notify_categories'] 的鍵值) -> (表分類, 表內 category)
NOTIFY_CATEGORY_TO_TEMPLATE = {
    'download_manual_success': ('download', 'manual_success'),
    'download_manual_failed': ('download', 'manual_failed'),
    'download_manual_cancelled': ('download', 'manual_cancelled'),
    'download_schedule_success': ('download', 'schedule_success'),
    'download_schedule_failed': ('download', 'schedule_failed'),
    'gossip_pause': ('announcement', 'pause'),
    'gossip_delay': ('announcement', 'delay'),
    'gossip_extra_episode': ('announcement', 'extra_episode'),
    'gossip_other': ('announcement', 'other'),
    'system_cookie_invalid': ('system', 'cookie_invalid'),
    'system_device_error': ('system', 'device_error'),
    'system_daily_digest': ('system', 'daily_digest'),
    'system_path_unreachable': ('system', 'path_unreachable'),
}

# 各類別實際發送時, Config.send_notification() 呼叫點會用的 title_suffix(帶入 Config.notify_title(...)
# 組出「【aniGamerPlus 客製強化版 vX.X.X OOO】」這行標題), 這裡複製一份純粹給「預覽」功能對照用, 因為
# NotifyDB.py 刻意不 import Config(避免循環引用), 沒辦法自己呼叫 notify_title(), 實際的標題字串由
# Dashboard/Server.py(那邊本來就有 import Config)算好後傳進 render_preview()
NOTIFY_CATEGORY_TITLE_SUFFIX = {
    'download_manual_success': '消息',
    'download_manual_failed': '消息',
    'download_manual_cancelled': '消息',
    'download_schedule_success': '消息',
    'download_schedule_failed': '消息',
    'gossip_pause': '公告通知',
    'gossip_delay': '公告通知',
    'gossip_extra_episode': '公告通知',
    'gossip_other': '公告通知',
    'system_cookie_invalid': '系統通知',
    'system_device_error': '系統通知',
    'system_daily_digest': '系統通知',
    'system_path_unreachable': '系統通知',
}

# 預設模板文字(唯一的預設值來源: 建表 seed 與「恢復預設」都讀這裡), 對應目前各呼叫點原本手刻的字串,
# Config.notify_title(...) 前綴不放進這裡, 由呼叫端在拿到 render 結果後自行拼接
DEFAULT_TEMPLATES = {
    'download_manual_success': '@animation_name@ @episode@\n下載完成 @file_size@ MB',
    'download_manual_failed': '@animation_name@ @episode@\n下載失敗: @fail_reason@',
    'download_manual_cancelled': '@animation_name@ @episode@\n下載已取消',
    'download_schedule_success': '@animation_name@ @episode@\n下載完成 @file_size@ MB',
    'download_schedule_failed': '@animation_name@ @episode@\n下載失敗, 將等待下次排程重試',
    'gossip_pause': '《@animation_name@》本週停止更新\n@announcement_text@',
    'gossip_delay': '《@animation_name@》延後更新\n@announcement_text@',
    'gossip_extra_episode': '《@animation_name@》臨時加更\n@announcement_text@',
    'gossip_other': '《@animation_name@》其他公告\n@announcement_text@',
    'system_cookie_invalid': 'Cookie 已失效, 請重新登入取得新的 Cookie 並更新設定',
    'system_device_error': '裝置驗證異常(code=1007)\n@error_message@',
    'system_daily_digest': '@digest_date@ 每日新番通知@digest_update_note@\n\n'
                            '本日排程更新, 共 @today_schedule_count@ 部:\n'
                            '<blockquote expandable>@today_schedule_list@</blockquote>\n\n'
                            '機動調整異動, 共 @dynamic_adjustment_count@ 部:\n'
                            '<blockquote expandable>@dynamic_adjustment_list@</blockquote>',
    'system_path_unreachable': '@path_label@「@configured_path@」目前無法存取\n本次改用: @fallback_path@\n請確認網路磁碟/NAS 是否已連線',
}

# Telegram Bot 支援的 HTML 格式標籤(sendMessage 搭配 parse_mode=HTML), 提供給「通知模板」編輯器的
# 工具列插入按鈕與說明表使用: (標籤, 功能, 使用方法/範例)
TELEGRAM_HTML_TAGS = [
    ('<b>文字</b>', '粗體', '也可用 <strong>文字</strong>'),
    ('<i>文字</i>', '斜體', '也可用 <em>文字</em>'),
    ('<u>文字</u>', '底線', '也可用 <ins>文字</ins>'),
    ('<s>文字</s>', '刪除線', '也可用 <strike>文字</strike> 或 <del>文字</del>'),
    ('<code>文字</code>', '單行程式碼', '適合短片段, 例如指令或變數名稱'),
    ('<pre>文字</pre>', '多行程式碼區塊', '保留換行與空白, 不特別標示語言'),
    ('<pre><code class="language-python">文字</code></pre>', '指定語言的程式碼區塊', '將 language-python 換成想要的語言名稱即可'),
    ('<blockquote>文字</blockquote>', '引用', '整段內縮並標示引用樣式'),
    ('<blockquote expandable>文字</blockquote>', '可摺疊引用', '內容需至少 4 行才會顯示收合箭頭(實測結果); 行數不足時 Telegram 只會顯示成一般引用。Discord 沒有對應功能, 轉換後會退化成一般引用'),
    ('<a href="網址">文字</a>', '超連結', '把「網址」換成實際連結'),
    ('<tg-spoiler>文字</tg-spoiler>', '防劇透(點擊後才顯示)', 'Telegram 專屬效果, Discord 會轉換成對應的防雷符號'),
]

def _wrap_per_line(marker):
    # 逐行各自包一組完整的 marker, 而不是整段多行內容只在頭尾各包一次: 避免標記跨行時, 被下面最後才處理的
    # blockquote 規則插入的 "> " 行首前綴打斷成沒被正確渲染的裸符號(見 _TG_TO_DISCORD_RULES 開頭的說明)
    return lambda m: '\n'.join(marker + line + marker for line in m.group(1).split('\n'))


# Telegram HTML 標籤 -> Discord Markdown 對照表: 由後端在儲存模板時自動轉換, 不需要使用者自己改寫兩份模板。
# 依序處理, 順序很重要:
# 1. 較specific 的樣式(帶 class 的程式碼區塊)必須排在單純 <pre>/<code> 之前, 否則會被泛用規則提前喫掉、
#    無法正確帶出語言名稱
# 2. blockquote 必須排在所有 inline 樣式規則(粗體/斜體/底線/刪除線/防劇透/連結)之後才處理: blockquote 規則
#    會把「> 」前綴插進內容的每一行行首。若排在 inline 樣式規則之前, 這些規則的 DOTALL 模式會在 blockquote
#    已經插入 "> " 之後才跨行比對, 讓 **/*/__ 等標記符號插在剛被插入的 "> " 中間、甚至吃掉某一行行首的 "> "
#    (該行看起來不再是引用的一部分), Discord 最終會顯示成沒被正確渲染的裸符號。上面每個 inline 樣式規則已
#    改成用 _wrap_per_line() 讓標記不再跨行, 搭配「blockquote 最後處理」, 才能確保每一行都是自成一體、
#    沒有被行首 "> " 前綴打斷的合法 markdown
_TG_TO_DISCORD_RULES = [
    (re.compile(r'<pre>\s*<code class="language-([^"]*)">(.*?)</code>\s*</pre>', re.DOTALL),
     lambda m: '```' + m.group(1) + '\n' + m.group(2) + '\n```'),
    (re.compile(r'<pre>(.*?)</pre>', re.DOTALL), lambda m: '```\n' + m.group(1) + '\n```'),
    (re.compile(r'<code>(.*?)</code>', re.DOTALL), lambda m: '`' + m.group(1) + '`'),
    (re.compile(r'<b>(.*?)</b>', re.DOTALL), _wrap_per_line('**')),
    (re.compile(r'<strong>(.*?)</strong>', re.DOTALL), _wrap_per_line('**')),
    (re.compile(r'<i>(.*?)</i>', re.DOTALL), _wrap_per_line('*')),
    (re.compile(r'<em>(.*?)</em>', re.DOTALL), _wrap_per_line('*')),
    (re.compile(r'<u>(.*?)</u>', re.DOTALL), _wrap_per_line('__')),
    (re.compile(r'<ins>(.*?)</ins>', re.DOTALL), _wrap_per_line('__')),
    (re.compile(r'<s>(.*?)</s>', re.DOTALL), _wrap_per_line('~~')),
    (re.compile(r'<strike>(.*?)</strike>', re.DOTALL), _wrap_per_line('~~')),
    (re.compile(r'<del>(.*?)</del>', re.DOTALL), _wrap_per_line('~~')),
    (re.compile(r'<tg-spoiler>(.*?)</tg-spoiler>', re.DOTALL), _wrap_per_line('||')),
    (re.compile(r'<a href="([^"]*)">(.*?)</a>', re.DOTALL), lambda m: '[' + m.group(2) + '](' + m.group(1) + ')'),
    (re.compile(r'<blockquote(?:\s+expandable)?>(.*?)</blockquote>', re.DOTALL),
     lambda m: '\n'.join('> ' + line for line in m.group(1).strip('\n').split('\n'))),
]


def convert_telegram_html_to_discord(text):
    # 把 Telegram HTML 標籤轉成 Discord 的 markdown 語法; @token@ 佔位符不受影響(規則只匹配 <...> 樣式標籤)
    for pattern, repl in _TG_TO_DISCORD_RULES:
        text = pattern.sub(repl, text)
    return text


# Discord 版預設模板: 在模組載入時把 DEFAULT_TEMPLATES 轉換好, 當作 discord_templates 表的預設值來源,
# 跟 Telegram 版共用同一份「原始」文字, 只是差在有沒有轉換過 HTML 標籤(目前預設模板都沒用到標籤, 轉換後文字不變)
DEFAULT_TEMPLATES_DISCORD = {k: convert_telegram_html_to_discord(v) for k, v in DEFAULT_TEMPLATES.items()}

# 通用字符參考列表: 三張獨立表, 每次啟動用 INSERT OR REPLACE 覆蓋成下面這份內建清單(純參考用, 使用者不能編輯)
PLACEHOLDER_REFERENCE = {
    'placeholder_name': [
        ('@animation_name@', '番劇名稱', '下載通知、公告通知皆可用; 系統通知(Cookie失效/裝置驗證異常/新版本可用)沒有對應的番劇, 不適用'),
    ],
    'placeholder_time': [
        ('@download_time@', '下載完成/失敗當下的時間', '下載通知(手動任務/排程任務的完成與失敗)適用'),
        ('@new_sn_time@', '偵測到影片更新的時間', '目前與 @download_time@ 是同一個時間值(偵測到更新後會馬上開始下載), 下載通知適用'),
        ('@announcement_time@', '偵測到公告的時間', '公告通知(停止更新/延後更新/臨時加更/其他)適用'),
        ('@postpone_time@', '延後後的新排程時間', '只有「延後更新通知」在有解析出新時間時才會有值, 其餘類別不適用'),
        ('@finish_time@', '這則通知送出當下的時間', '所有類別皆可用, 沒有更精確的時間可用時的通用備援'),
        ('@digest_date@', '本次每日新番通知彙整的日期', '「每日新番通知」適用'),
    ],
    'placeholder_content': [
        ('@episode@', '集數', '下載通知適用, 例如 [12]'),
        ('@file_size@', '檔案大小(MB)', '下載完成通知適用'),
        ('@fail_reason@', '下載失敗原因', '下載失敗通知適用'),
        ('@error_message@', '系統錯誤訊息內容', '「裝置驗證異常」通知適用'),
        ('@announcement_text@', '公告原文', '公告通知適用'),
        ('@today_schedule_count@', '本日排程更新的部數', '「每日新番通知」適用'),
        ('@today_schedule_list@', '本日排程更新清單(每行一部, 含時間)',
         '「每日新番通知」適用, 沒有排定項目時會顯示「今日無排定更新」; 建議搭配可摺疊引用(<blockquote expandable>)'
         '使用, 內容需至少 4 行才會顯示收合箭頭, 不足 4 行時 Telegram 只會顯示成一般引用'),
        ('@dynamic_adjustment_count@', '機動調整生效中的部數', '「每日新番通知」適用, 需開啟監視公告的機動調整功能才會有內容'),
        ('@dynamic_adjustment_list@', '機動調整清單(每行一部, 含暫停/今日檢查等異動說明)',
         '「每日新番通知」適用, 需開啟監視公告的機動調整功能才會有內容, 沒有異動時會顯示「今日無機動調整異動」; '
         '同樣建議搭配可摺疊引用使用'),
        ('@digest_update_note@', '本次是否為更新版的提示文字', '「每日新番通知」適用, 首次發送時為空字串; '
         '若當天發送後機動調整異動又有變化(新增/修改/移除), 會自動重新發送一次更新版, 這個 token 屆時會帶出提示文字, '
         '建議直接接在標題後面(預設模板即是如此), 不需要額外加標點'),
        ('@path_label@', '無法存取的路徑欄位名稱(下載目錄/暫存目錄)', '「路徑無法存取」通知適用'),
        ('@configured_path@', '設定的路徑', '「路徑無法存取」通知適用'),
        ('@fallback_path@', '本次改用的路徑', '「路徑無法存取」通知適用'),
    ],
}


def _get_db_connection():
    return sqlite3.connect(notify_db_path, timeout=10)


def now_str():
    return datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')


def _ensure_tables():
    with closing(_get_db_connection()) as conn:
        cursor = conn.cursor()
        _do_ensure_tables(conn, cursor)


def _do_ensure_tables(conn, cursor):
    for group, (table, categories) in TEMPLATE_TABLES.items():
        cursor.execute('CREATE TABLE IF NOT EXISTS ' + table + ' ('
                        'category TEXT PRIMARY KEY,'
                        'template TEXT NOT NULL,'
                        'is_default INTEGER NOT NULL DEFAULT 1)')
        # 新使用者(表剛建立)或新版新增的類別: 補上預設列, 讓表裡隨時有完整資料可讀, 不必靠程式端 fallback
        for category in categories:
            notify_category = next(k for k, v in NOTIFY_CATEGORY_TO_TEMPLATE.items() if v == (group, category))
            cursor.execute('INSERT OR IGNORE INTO ' + table + ' (category, template, is_default) VALUES (?, ?, 1)',
                            (category, DEFAULT_TEMPLATES[notify_category]))

    # Discord 版模板獨立成一張新表(而非在既有三張表加欄位): 這裡的 category 直接用 11 個通知類別 id 當
    # PRIMARY KEY(不像 Telegram 版三張表還要分 download/announcement/system 羣組), 每次 set_template()/
    # reset_template() 都會連動寫入這裡, 儲存的是「已經轉換好」的 markdown, 送 Discord 訊息時不用再即時轉換
    cursor.execute('CREATE TABLE IF NOT EXISTS discord_templates ('
                    'category TEXT PRIMARY KEY,'
                    'template TEXT NOT NULL,'
                    'is_default INTEGER NOT NULL DEFAULT 1)')
    for notify_category, default_text in DEFAULT_TEMPLATES_DISCORD.items():
        cursor.execute('INSERT OR IGNORE INTO discord_templates (category, template, is_default) VALUES (?, ?, 1)',
                        (notify_category, default_text))

    for table in ('telegram_history', 'discord_history'):
        cursor.execute('CREATE TABLE IF NOT EXISTS ' + table + ' ('
                        'id INTEGER PRIMARY KEY AUTOINCREMENT,'
                        'category TEXT NOT NULL,'
                        'subcategory TEXT NOT NULL,'
                        'message TEXT NOT NULL,'
                        'success INTEGER NOT NULL,'
                        'error TEXT,'
                        'sent_at TIMESTAMP NOT NULL DEFAULT (datetime(\'now\',\'localtime\')))')

    for table in PLACEHOLDER_REFERENCE:
        cursor.execute('CREATE TABLE IF NOT EXISTS ' + table + ' ('
                        'token TEXT PRIMARY KEY,'
                        'description TEXT NOT NULL,'
                        'usage TEXT NOT NULL)')

    # v25.2.2: 「新版本可用」改成固定格式(見 TEMPLATE_TABLES 上方的說明), 不再是可自訂模板——清掉舊版本
    # 升級留下的舊資料列(不論是預設值還是使用者自訂過的內容), 每次啟動都執行, 空表時 DELETE 也不會出錯
    cursor.execute("DELETE FROM system_templates WHERE category='new_version'")
    cursor.execute("DELETE FROM discord_templates WHERE category='system_new_version'")
    cursor.execute("DELETE FROM placeholder_content WHERE token IN ('@version_tag@', '@version_body@')")

    conn.commit()


_ensure_tables()


def seed_placeholder_reference():
    # 三張參考表純粹是內建清單的鏡像, 每次啟動都覆蓋成最新版本, 使用者不會(也不能透過 UI)編輯這幾張表
    with _notify_db_lock:
        with closing(_get_db_connection()) as conn:
            cursor = conn.cursor()
            for table, rows in PLACEHOLDER_REFERENCE.items():
                for token, description, usage in rows:
                    cursor.execute('INSERT OR REPLACE INTO ' + table + ' (token, description, usage) VALUES (?, ?, ?)',
                                    (token, description, usage))
            conn.commit()


def get_placeholder_reference():
    with _notify_db_lock:
        with closing(_get_db_connection()) as conn:
            cursor = conn.cursor()
            result = {}
            for table in PLACEHOLDER_REFERENCE:
                cursor.execute('SELECT token, description, usage FROM ' + table)
                result[table] = [{'token': r[0], 'description': r[1], 'usage': r[2]} for r in cursor.fetchall()]
            return result


def _table_for(notify_category):
    group, category = NOTIFY_CATEGORY_TO_TEMPLATE[notify_category]
    table = TEMPLATE_TABLES[group][0]
    return table, category, group


def get_template(notify_category, channel='telegram'):
    # channel='telegram' 讀原始 HTML 標籤版模板(三張羣組表); channel='discord' 讀已轉換好的 markdown 版
    # (discord_templates 表), 不用每次發送都重新轉換一次
    if channel == 'discord':
        with _notify_db_lock:
            with closing(_get_db_connection()) as conn:
                cursor = conn.cursor()
                cursor.execute('SELECT template FROM discord_templates WHERE category=?', (notify_category,))
                row = cursor.fetchone()
                return row[0] if row else DEFAULT_TEMPLATES_DISCORD[notify_category]

    table, category, _ = _table_for(notify_category)
    with _notify_db_lock:
        with closing(_get_db_connection()) as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT template FROM ' + table + ' WHERE category=?', (category,))
            row = cursor.fetchone()
            return row[0] if row else DEFAULT_TEMPLATES[notify_category]


def get_all_templates():
    # 給 GET /data/notify_templates 一次撈出全部 11 個類別目前的 Telegram/Discord 模板與 is_default 旗標
    result = {}
    with _notify_db_lock:
        with closing(_get_db_connection()) as conn:
            cursor = conn.cursor()
            for notify_category, (group, category) in NOTIFY_CATEGORY_TO_TEMPLATE.items():
                table = TEMPLATE_TABLES[group][0]
                cursor.execute('SELECT template, is_default FROM ' + table + ' WHERE category=?', (category,))
                row = cursor.fetchone()
                if row:
                    template, is_default = row[0], bool(row[1])
                else:
                    template, is_default = DEFAULT_TEMPLATES[notify_category], True

                cursor.execute('SELECT template FROM discord_templates WHERE category=?', (notify_category,))
                discord_row = cursor.fetchone()
                template_discord = discord_row[0] if discord_row else DEFAULT_TEMPLATES_DISCORD[notify_category]

                result[notify_category] = {'template': template, 'template_discord': template_discord, 'is_default': is_default}
    return result


def set_template(notify_category, text):
    # 存 Telegram 版原始文字的同時, 自動轉換出 Discord 版 markdown 並一併存進 discord_templates,
    # 使用者只需要維護一份模板, 不用自己改寫兩種語法
    table, category, _ = _table_for(notify_category)
    discord_text = convert_telegram_html_to_discord(text)
    with _notify_db_lock:
        with closing(_get_db_connection()) as conn:
            conn.execute('UPDATE ' + table + ' SET template=?, is_default=0 WHERE category=?', (text, category))
            conn.execute('UPDATE discord_templates SET template=?, is_default=0 WHERE category=?', (discord_text, notify_category))
            conn.commit()
    return discord_text


def reset_template(notify_category):
    table, category, _ = _table_for(notify_category)
    default_text = DEFAULT_TEMPLATES[notify_category]
    default_text_discord = DEFAULT_TEMPLATES_DISCORD[notify_category]
    with _notify_db_lock:
        with closing(_get_db_connection()) as conn:
            conn.execute('UPDATE ' + table + ' SET template=?, is_default=1 WHERE category=?', (default_text, category))
            conn.execute('UPDATE discord_templates SET template=?, is_default=1 WHERE category=?',
                         (default_text_discord, notify_category))
            conn.commit()
    return default_text, default_text_discord


def render_notify_message(notify_category, channel='telegram', **context):
    # 取該類別目前的模板(自訂或預設), 把 @token@ 依 context 逐一替換。
    # Telegram 走 parse_mode=HTML, 帶入的動態內容(番劇名、錯誤訊息等)可能含有 <, >, & 等字元,
    # 需要先做 HTML 跳脫才能替換, 否則會被誤判成標籤或讓 Telegram API 直接回錯; Discord 版模板
    # 存的時候已經先把標籤轉成 markdown, 帶入內容不需要(也不應該)再做 HTML 跳脫。
    # context 沒帶到的 token 保留原樣不清空, 方便使用者發現自己拼錯 token 名稱, 而不是默默消失看不出問題
    text = get_template(notify_category, channel)
    escape = html.escape if channel == 'telegram' else (lambda v: v)
    for key, value in context.items():
        text = text.replace('@' + key + '@', escape(str(value)))
    return text


# 「預覽」功能用的範例內容: 涵蓋所有通用字符, 不管目前編輯的模板用到哪些 token 都能替換出看起來合理的結果,
# 讓使用者不用實際觸發下載/公告/系統事件就能看到「大概會長什麼樣子」
SAMPLE_CONTEXT = {
    'animation_name': '葬送的芙莉蓮',
    'episode': '[12]',
    'file_size': '350',
    'download_time': '2026-07-29 20:30:00',
    'new_sn_time': '2026-07-29 20:30:00',
    'announcement_time': '2026-07-29 18:00:00',
    'postpone_time': '2026-08-05 20:30',
    'finish_time': '2026-07-29 20:30:05',
    'fail_reason': '網路連線逾時',
    'error_message': '《葬送的芙莉蓮》code=1007 message: device verification failed',
    'announcement_text': '因版權疑慮, 本片將暫停更新, 恢復時間另行公告',
    'digest_date': '2026-07-30',
    'digest_update_note': ' (機動調整異動更新, 重新發送)',
    'today_schedule_count': '4',
    'today_schedule_list': '- 葬送的芙莉蓮 20:30\n- 進擊的巨人 21:00\n- 鬼滅之刃 22:00\n- 咒術迴戰 23:00',
    'dynamic_adjustment_count': '4',
    'dynamic_adjustment_list': '- 葬送的芙莉蓮 本週暫停更新\n- 鬼滅之刃 今日 23:30 檢查更新(預計加更 2 集)\n'
                               '- 咒術迴戰 本週延後更新\n- 進擊的巨人 今日 20:00 檢查更新',
}


def _discord_markdown_to_preview_html(text):
    # 把 discord_templates 存的 markdown 轉成可以直接塞進預覽視窗的 HTML, 純粹給「預覽」畫面用,
    # 跟真正送去 Discord 的內容無關(那邊就是原始 markdown 字串, 由 Discord 自己渲染)
    text = html.escape(text)
    text = re.sub(r'```(?:\w*)\n?(.*?)```', lambda m: '<pre>' + m.group(1) + '</pre>', text, flags=re.DOTALL)
    text = re.sub(r'`([^`]+)`', lambda m: '<code>' + m.group(1) + '</code>', text)
    text = re.sub(r'\*\*(.+?)\*\*', lambda m: '<b>' + m.group(1) + '</b>', text, flags=re.DOTALL)
    text = re.sub(r'__(.+?)__', lambda m: '<u>' + m.group(1) + '</u>', text, flags=re.DOTALL)
    text = re.sub(r'\*(.+?)\*', lambda m: '<i>' + m.group(1) + '</i>', text, flags=re.DOTALL)
    text = re.sub(r'~~(.+?)~~', lambda m: '<del>' + m.group(1) + '</del>', text, flags=re.DOTALL)
    text = re.sub(r'\|\|(.+?)\|\|', lambda m: '<span class="discord-spoiler-preview">' + m.group(1) + '</span>',
                  text, flags=re.DOTALL)
    text = re.sub(r'\[(.+?)\]\((.+?)\)',
                  lambda m: '<a href="' + m.group(2) + '" target="_blank" rel="noopener">' + m.group(1) + '</a>', text)
    # 引用: 把連續的 "&gt; " 開頭行(html.escape 後 "> " 變成這樣)包成一個 blockquote, 組內用換行分開,
    # 讓 CSS white-space:pre-wrap 自己處理視覺換行
    text = re.sub(r'(?:^&gt; .*(?:\n&gt; .*)*)',
                  lambda m: '<blockquote class="discord-quote-preview">'
                            + re.sub(r'^&gt; ', '', m.group(0), flags=re.MULTILINE) + '</blockquote>',
                  text, flags=re.MULTILINE)
    return text


def render_preview(notify_category, telegram_template, title):
    # 供 Dashboard「預覽」按鈕使用: telegram_template 是使用者「目前輸入框裡」還沒存檔的文字(不是資料庫裡
    # 已存的版本), 讓使用者編輯過程中隨時能看到目前寫的內容大概會長什麼樣子, 不用先按儲存。
    # title 是呼叫端(Dashboard/Server.py)算好的 Config.notify_title(...) 結果, 例如
    # 「【aniGamerPlus 客製強化版 v25.2.0 消息】」——Telegram 沒有獨立標題欄位, 這行要跟內文合併成同一則訊息;
    # Discord embed 則有獨立的標題欄位, 這行要放 embed 的 title、不跟內文(description)混在一起。
    title_html = html.escape(title)

    telegram_body_html = telegram_template
    for key, value in SAMPLE_CONTEXT.items():
        telegram_body_html = telegram_body_html.replace('@' + key + '@', html.escape(str(value)))
    telegram_html = title_html + '\n' + telegram_body_html

    discord_markdown = convert_telegram_html_to_discord(telegram_template)
    for key, value in SAMPLE_CONTEXT.items():
        discord_markdown = discord_markdown.replace('@' + key + '@', str(value))
    discord_html = _discord_markdown_to_preview_html(discord_markdown)

    return {'telegram_html': telegram_html, 'discord_html': discord_html, 'discord_title': title}


def log_history(channel, notify_category, message, success, error=None):
    # channel: 'telegram' 或 'discord', 兩邊分開記錄, 不可混在一起
    table = channel + '_history'
    group, category = NOTIFY_CATEGORY_TO_TEMPLATE.get(notify_category, (notify_category, notify_category))
    with _notify_db_lock:
        with closing(_get_db_connection()) as conn:
            conn.execute('INSERT INTO ' + table + " (category, subcategory, message, success, error, sent_at) "
                         "VALUES (?, ?, ?, ?, ?, datetime('now','localtime'))",
                         (group, notify_category, message, 1 if success else 0, error))
            conn.commit()


def get_history_row(channel, history_id):
    # 供「手動重試」使用: 依 id 取單一筆歷史紀錄(取出原始 message/subcategory 供重新發送)
    table = channel + '_history'
    with _notify_db_lock:
        with closing(_get_db_connection()) as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT id, category, subcategory, message, success, error, sent_at FROM ' + table +
                            ' WHERE id=?', (history_id,))
            r = cursor.fetchone()
    if not r:
        return None
    return {
        'id': r[0], 'category': r[1], 'subcategory': r[2], 'message': r[3],
        'success': bool(r[4]), 'error': r[5], 'sent_at': r[6],
    }


def get_history(channel, category=None, subcategory=None, limit=200):
    table = channel + '_history'
    query = 'SELECT id, category, subcategory, message, success, error, sent_at FROM ' + table
    conditions = []
    params = []
    if category:
        conditions.append('category=?')
        params.append(category)
    if subcategory:
        conditions.append('subcategory=?')
        params.append(subcategory)
    if conditions:
        query += ' WHERE ' + ' AND '.join(conditions)
    query += ' ORDER BY id DESC LIMIT ?'
    params.append(limit)
    with _notify_db_lock:
        with closing(_get_db_connection()) as conn:
            cursor = conn.cursor()
            cursor.execute(query, params)
            rows = cursor.fetchall()
    return [{
        'id': r[0], 'category': r[1], 'subcategory': r[2], 'message': r[3],
        'success': bool(r[4]), 'error': r[5], 'sent_at': r[6],
    } for r in rows]
