#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# 動畫瘋登入設定(客製強化版獨有功能): 加密儲存使用者的動畫瘋帳號密碼與 2FA(TOTP)密鑰, 供「快速取得 Cookie」
# 按鈕升級成自動代填帳號/密碼/兩步驟驗證碼使用, 最終仍交由使用者親自完成 Google reCAPTCHA 並手動按下
# 「取得Cookie」——本模組只負責存取與加解密, 不碰瀏覽器自動化(那是 Dashboard/quick_fetch.py 的事)。
#
# 表格存進 aniGamer.db, 寫法沿用 NotifyDB.py/GossipDB.py 的慣例(純 sqlite3, 無 ORM, 自己的鎖與
# working_dir, CREATE TABLE IF NOT EXISTS 冪等), 刻意不 import Config 避免循環引用。
#
# 加密僅支援 Windows(使用 DPAPI CryptProtectData/CryptUnprotectData, 綁定目前 Windows 使用者帳戶),
# 本專案同時支援 Docker/Linux 部署, 此功能在那些平台上必須完全拒絕/隱藏, 一律先呼叫 is_supported() 把關。
# ctypes 本身跨平台可以無條件 import(參考 ColorPrint.py 的既有先例), 只有實際呼叫 ctypes.windll 的地方
# 才需要限定在 Windows 呼叫路徑內, 所以每個對外函式一開始都要先檢查是否支援, 絕不能讓 DPAPI 呼叫式碼在
# 模組載入時就執行到。
#
# 加密分層(由內而外): 明文 -> (可選) AES-256-GCM(scrypt(PIN, salt)) -> DPAPI(一律套用, 目前使用者帳戶範圍)。
# PIN 本身完全不落地儲存, 只用來衍生金鑰; pin_verifier_enc 是同樣分層加密一組固定常數, 解密前一律先驗證
# 這組 verifier, 錯誤就直接視為 PIN 錯誤, 完全不去碰真正的密碼/2FA 密文, 避免任何旁路訊息。

import os
import sys
import time
import hmac
import base64
import struct
import hashlib
import sqlite3
import threading
import platform
import datetime
from contextlib import closing

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt

if getattr(sys, 'frozen', False):
    working_dir = os.path.dirname(sys.executable)
else:
    working_dir = os.path.dirname(os.path.realpath(__file__))

vault_db_path = os.path.join(working_dir, 'aniGamer.db')
_vault_db_lock = threading.Lock()

_PIN_VERIFIER_MAGIC = b'anigamerplus-account-vault-pin-verify-v1'
_SCRYPT_N, _SCRYPT_R, _SCRYPT_P, _SCRYPT_DKLEN = 2 ** 14, 8, 1, 32
_PIN_SALT_LEN = 16
_GCM_NONCE_LEN = 12

CRYPTPROTECT_UI_FORBIDDEN = 0x1


class NotSupportedError(Exception):
    pass


class NotConfiguredError(Exception):
    pass


class PinRequiredError(Exception):
    pass


class WrongPinError(Exception):
    pass


def is_supported():
    return platform.system() == 'Windows'


def _get_db_connection():
    return sqlite3.connect(vault_db_path, timeout=10)


def _now_str():
    return datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')


def _ensure_tables():
    with closing(_get_db_connection()) as conn:
        cursor = conn.cursor()
        cursor.execute('CREATE TABLE IF NOT EXISTS bahamut_account_vault ('
                        'id INTEGER PRIMARY KEY CHECK (id=1),'
                        'account TEXT NOT NULL,'                # 明文, 使用者確認後可在畫面上明文顯示
                        'password_enc BLOB NOT NULL,'
                        'totp_secret_enc BLOB,'                  # 使用者可不填 2FA 密鑰, 此時為 NULL
                        'pin_enabled INTEGER NOT NULL DEFAULT 0,'
                        'pin_verifier_enc BLOB,'                 # 只在 pin_enabled=1 時有值
                        'pin_kdf_salt BLOB,'                      # 同上; 非機密, 需持久保存才能重新衍生金鑰
                        'updated_at TEXT NOT NULL)')
        conn.commit()


_ensure_tables()


# ---------------------------------------------------------------------------
# DPAPI(僅 Windows): 用 ctypes 直接呼叫 Crypt32.dll, 不需要 pywin32
# ---------------------------------------------------------------------------

def _dpapi_protect(data):
    import ctypes

    class _DATA_BLOB(ctypes.Structure):
        _fields_ = [('cbData', ctypes.c_ulong), ('pbData', ctypes.POINTER(ctypes.c_char))]

    buf = ctypes.create_string_buffer(data, len(data))
    blob_in = _DATA_BLOB(len(data), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char)))
    blob_out = _DATA_BLOB()
    ok = ctypes.windll.crypt32.CryptProtectData(
        ctypes.byref(blob_in), None, None, None, None,
        CRYPTPROTECT_UI_FORBIDDEN, ctypes.byref(blob_out))
    if not ok:
        raise ctypes.WinError()
    try:
        return ctypes.string_at(blob_out.pbData, blob_out.cbData)
    finally:
        ctypes.windll.kernel32.LocalFree(blob_out.pbData)


def _dpapi_unprotect(data):
    import ctypes

    class _DATA_BLOB(ctypes.Structure):
        _fields_ = [('cbData', ctypes.c_ulong), ('pbData', ctypes.POINTER(ctypes.c_char))]

    buf = ctypes.create_string_buffer(data, len(data))
    blob_in = _DATA_BLOB(len(data), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char)))
    blob_out = _DATA_BLOB()
    ok = ctypes.windll.crypt32.CryptUnprotectData(
        ctypes.byref(blob_in), None, None, None, None,
        CRYPTPROTECT_UI_FORBIDDEN, ctypes.byref(blob_out))
    if not ok:
        raise ctypes.WinError()
    try:
        return ctypes.string_at(blob_out.pbData, blob_out.cbData)
    finally:
        ctypes.windll.kernel32.LocalFree(blob_out.pbData)


# ---------------------------------------------------------------------------
# 可選的 PIN 加密層(AES-256-GCM, 金鑰由 scrypt 衍生; PIN 本身永不落地儲存)
# ---------------------------------------------------------------------------

def _derive_pin_key(pin, salt):
    kdf = Scrypt(salt=salt, length=_SCRYPT_DKLEN, n=_SCRYPT_N, r=_SCRYPT_R, p=_SCRYPT_P)
    return kdf.derive(pin.encode('utf-8'))


def _pin_encrypt(plaintext_bytes, pin_key):
    nonce = os.urandom(_GCM_NONCE_LEN)
    ciphertext = AESGCM(pin_key).encrypt(nonce, plaintext_bytes, None)
    return nonce + ciphertext  # 前 12 bytes 是 nonce, 供解密時取出


def _pin_decrypt(blob, pin_key):
    nonce, ciphertext = blob[:_GCM_NONCE_LEN], blob[_GCM_NONCE_LEN:]
    return AESGCM(pin_key).decrypt(nonce, ciphertext, None)  # 驗證失敗會丟 cryptography.exceptions.InvalidTag


def _encrypt_secret(plaintext, pin_key):
    data = plaintext.encode('utf-8')
    if pin_key is not None:
        data = _pin_encrypt(data, pin_key)
    return _dpapi_protect(data)


def _decrypt_secret(blob, pin_key):
    data = _dpapi_unprotect(blob)
    if pin_key is not None:
        data = _pin_decrypt(data, pin_key)
    return data.decode('utf-8')


# ---------------------------------------------------------------------------
# 對外介面
# ---------------------------------------------------------------------------

def get_status():
    # 安全, 可直接回給前端: 絕不含 password/totp_secret 欄位(不只是設成 None, 是根本不放進 dict)
    status = {'supported': is_supported(), 'configured': False, 'account': None,
              'pin_enabled': False, 'has_totp': False, 'updated_at': None}
    if not status['supported']:
        return status
    with _vault_db_lock:
        with closing(_get_db_connection()) as conn:
            row = conn.execute('SELECT account, totp_secret_enc, pin_enabled, updated_at '
                                'FROM bahamut_account_vault WHERE id=1').fetchone()
    if row is None:
        return status
    account, totp_secret_enc, pin_enabled, updated_at = row
    status.update({'configured': True, 'account': account, 'pin_enabled': bool(pin_enabled),
                    'has_totp': totp_secret_enc is not None, 'updated_at': updated_at})
    return status


def save_credentials(account, password, totp_secret=None, pin=None):
    if not is_supported():
        raise NotSupportedError('此功能僅支援 Windows')
    if not account or not password:
        raise ValueError('帳號與密碼為必填')

    pin_key = None
    salt = None
    pin_verifier_enc = None
    if pin:
        salt = os.urandom(_PIN_SALT_LEN)
        pin_key = _derive_pin_key(pin, salt)
        pin_verifier_enc = _dpapi_protect(_pin_encrypt(_PIN_VERIFIER_MAGIC, pin_key))

    password_enc = _encrypt_secret(password, pin_key)
    totp_secret_enc = _encrypt_secret(totp_secret, pin_key) if totp_secret else None

    with _vault_db_lock:
        with closing(_get_db_connection()) as conn:
            conn.execute(
                'INSERT INTO bahamut_account_vault '
                '(id, account, password_enc, totp_secret_enc, pin_enabled, pin_verifier_enc, pin_kdf_salt, updated_at) '
                'VALUES (1, ?, ?, ?, ?, ?, ?, ?) '
                'ON CONFLICT(id) DO UPDATE SET account=excluded.account, password_enc=excluded.password_enc, '
                'totp_secret_enc=excluded.totp_secret_enc, pin_enabled=excluded.pin_enabled, '
                'pin_verifier_enc=excluded.pin_verifier_enc, pin_kdf_salt=excluded.pin_kdf_salt, '
                'updated_at=excluded.updated_at',
                (account, password_enc, totp_secret_enc, 1 if pin else 0, pin_verifier_enc, salt, _now_str()))
            conn.commit()


def delete_credentials():
    with _vault_db_lock:
        with closing(_get_db_connection()) as conn:
            conn.execute('DELETE FROM bahamut_account_vault WHERE id=1')
            conn.commit()


def unlock_credentials(pin=None):
    # 回傳明文 {'account','password','totp_secret'}, 僅供伺服器端在 spawn quick_fetch 子行程前短暫使用,
    # 呼叫端絕對不能把這個回傳值放進任何會回給瀏覽器的回應或log
    if not is_supported():
        raise NotSupportedError('此功能僅支援 Windows')
    with _vault_db_lock:
        with closing(_get_db_connection()) as conn:
            row = conn.execute('SELECT account, password_enc, totp_secret_enc, pin_enabled, pin_verifier_enc, '
                                'pin_kdf_salt FROM bahamut_account_vault WHERE id=1').fetchone()
    if row is None:
        raise NotConfiguredError('尚未設定動畫瘋登入資訊')
    account, password_enc, totp_secret_enc, pin_enabled, pin_verifier_enc, salt = row

    pin_key = None
    if pin_enabled:
        if not pin:
            raise PinRequiredError('需要輸入 PIN 碼')
        pin_key = _derive_pin_key(pin, salt)
        try:
            verifier = _pin_decrypt(_dpapi_unprotect(pin_verifier_enc), pin_key)
        except Exception:
            raise WrongPinError('PIN 碼錯誤')
        if not hmac.compare_digest(verifier, _PIN_VERIFIER_MAGIC):
            raise WrongPinError('PIN 碼錯誤')

    password = _decrypt_secret(password_enc, pin_key)
    totp_secret = _decrypt_secret(totp_secret_enc, pin_key) if totp_secret_enc else None
    return {'account': account, 'password': password, 'totp_secret': totp_secret}


# ---------------------------------------------------------------------------
# TOTP(RFC 6238): HMAC-SHA1, 6 碼, 30 秒週期, 跟一般 Authenticator App 預設一致
# ---------------------------------------------------------------------------

def generate_totp(secret_b32, when=None):
    # secret_b32 是 otpauth:// 連結裡 secret= 後面那段 base32 字串(手動輸入碼), 允許使用者貼上時
    # 夾帶空白(常見於分段顯示), 這裡先去除空白/轉大寫再補齊 base32 padding
    normalized = secret_b32.strip().replace(' ', '').upper()
    padding = '=' * (-len(normalized) % 8)
    key = base64.b32decode(normalized + padding)

    counter = int((when if when is not None else time.time()) // 30)
    counter_bytes = struct.pack('>Q', counter)
    digest = hmac.new(key, counter_bytes, hashlib.sha1).digest()
    offset = digest[-1] & 0x0F
    truncated = struct.unpack('>I', digest[offset:offset + 4])[0] & 0x7FFFFFFF
    return '{:06d}'.format(truncated % 1_000_000)
