#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# 監視公告(gossip)功能(v25.1.6, v25.2.0 改存進 aniGamer.db): 每次「更新終了」後偵測動畫瘋首頁 class="gossip" 公告,
# 在不更動 sn_list.txt 的前提下, 生成臨時排程覆蓋; 同時把每則公告拆解出的子事件(狀態判斷/建議集數/處置方式)
# 寫進 aniGamer.db 供 Dashboard「公告」面板(歷史公告/操作處置/機動調整)顯示與操作。
#
# 資料存放於 GossipDB.py(gossip_log/gossip_events/gossip_pending 三張表), 這個模組只負責:
#   1. 抓取/解析公告文字, 判斷狀態(暫停更新/提前更新/延後更新/同時更新/暫時下架/無法判斷)
#   2. 把每個子事件比對到追蹤中的 sn(不比對名稱字面, 只看 sn 是否有交集)
#   3. 算出建議處置(system_suggestion), 「機動調整時間」開啟時自動套用; 使用者也可以透過 Dashboard 手動覆蓋
#
# 作品比對規則: 一律以 sn 是否有交集判斷是不是同一部作品, 不比對名稱字面
# (公告/搜尋結果/sn_list.txt 三邊的名稱經常不一致, 例如加了 [年齡限制版] 或用 "2nd Season" 代替 "第二季")。
# 但在「從搜尋結果裡挑選要解析成 sn 的候選作品」這一步, 仍需要先用季別標記做粗篩,
# 否則沒寫季別的公告標題可能被誤配到 sn_list.txt 裡帶季別的追蹤項目(例如《相反的你和我》被誤配到「相反的你和我 第二季」)。

import os
import re
import json
import time
import hashlib
import sqlite3
import datetime
import threading
from contextlib import closing
from urllib.parse import quote

import Config
import GossipDB
import NotifyDB
from Anime import Anime
from curl_cffi import requests as cffi_requests
from bs4 import BeautifulSoup
from ColorPrint import err_print

_session = None
_session_lock = threading.Lock()


def _get_session():
    global _session
    with _session_lock:
        if _session is None:
            _session = cffi_requests.Session(impersonate='chrome')
        return _session


def _get(url, **kwargs):
    session = _get_session()
    kwargs.setdefault('timeout', 10)
    last_exc = None
    for _ in range(3):
        try:
            return session.get(url, **kwargs)
        except Exception as e:
            last_exc = e
            time.sleep(2)
    raise last_exc


# ---------------------------------------------------------------------------
# 1. 抓取首頁 gossip 公告
# ---------------------------------------------------------------------------

def fetch_gossip_text():
    try:
        resp = _get('https://ani.gamer.com.tw/')
        soup = BeautifulSoup(resp.text, 'html.parser')
        el = soup.find(class_='gossip')
        if not el:
            return None
        inner = el.find('span')
        text = inner.get_text().strip() if inner else el.get_text().strip()
        return text or None
    except Exception as e:
        err_print(0, '監視公告', '抓取首頁公告失敗: ' + str(e), status=1, no_sn=True)
        return None


# ---------------------------------------------------------------------------
# 2. 季別標記(用於從搜尋結果篩選候選, 不用於最終比對)
# ---------------------------------------------------------------------------

_ZH_DIGIT = {'零': 0, '一': 1, '二': 2, '三': 3, '四': 4, '五': 5, '六': 6, '七': 7, '八': 8, '九': 9}


def _zh_num_to_int(s):
    if not s:
        return None
    if s.isdigit():
        return int(s)
    if s == '十':
        return 10
    if '十' in s:
        parts = s.split('十')
        tens = _ZH_DIGIT.get(parts[0], 1) if parts[0] else 1
        ones = _ZH_DIGIT.get(parts[1], 0) if len(parts) > 1 and parts[1] else 0
        return tens * 10 + ones
    return _ZH_DIGIT.get(s)


_SEASON_ZH_PATTERN = re.compile(r'第([一二三四五六七八九十]{1,3})季')
_SEASON_EN_PATTERN = re.compile(r'(\d{1,2})(?:st|nd|rd|th)\s*Season', re.IGNORECASE)
# 注意: 不能用 \bS(\d{1,2})\b——Python 的 \w 在 Unicode 字串裡包含中文字, 「史萊姆S4」的「姆」跟「S」之間
# 兩邊都是 \w, \b 找不到邊界, 導致公告常見的「中文名稱直接接 S4 無空格」寫法完全偵測不到季別數字
_SEASON_S_PATTERN = re.compile(r'(?<![A-Za-z0-9])S(\d{1,2})(?![A-Za-z0-9])')
# 標題尾端季別標記, 供 _strip_season_suffix() 去除季別、只留下基礎名稱用於搜尋時使用; 錨定在字串尾端,
# 避免誤删標題中間本來就含有這些字樣的部分
_SEASON_SUFFIX_PATTERN = re.compile(
    r'\s*(?:第[一二三四五六七八九十]{1,3}季|\d{1,2}(?:st|nd|rd|th)\s*Season|S\d{1,2})\s*$', re.IGNORECASE)

_SEASON_ZH_DIGITS = ['零', '一', '二', '三', '四', '五', '六', '七', '八', '九']


def _season_number(title):
    # 回傳這個標題「明確寫出」的季別數字, 沒寫季別回傳 None(視為第一季/無季別)
    m = _SEASON_ZH_PATTERN.search(title)
    if m:
        return _zh_num_to_int(m.group(1))
    m = _SEASON_EN_PATTERN.search(title)
    if m:
        return int(m.group(1))
    m = _SEASON_S_PATTERN.search(title)
    if m:
        return int(m.group(1))
    return None


def _season_compatible(a, b):
    # 沒寫季別(None)一律視為第一季; 只有雙方都「明確寫出」且數字不同才算不相容
    a = 1 if a is None else a
    b = 1 if b is None else b
    return a == b


def _season_num_to_zh(n):
    # 阿拉伯數字季別轉中文數字(用於組出「第N季」), 只需支援到雙十位數即可(季數超過20的作品極罕見)
    if n is None or n <= 0:
        return None
    if n < 10:
        return _SEASON_ZH_DIGITS[n]
    if n == 10:
        return '十'
    if n < 20:
        return '十' + _SEASON_ZH_DIGITS[n - 10]
    tens, ones = divmod(n, 10)
    return _SEASON_ZH_DIGITS[tens] + '十' + (_SEASON_ZH_DIGITS[ones] if ones else '')


def _build_search_title(title):
    # 回傳 (search_title, gossip_season) 供 match_title_to_sn() 使用:
    # 公告標題常用英數字季別縮寫(S2/S3/2nd Season), 但動畫瘋站上的正式作品名一律用中文「第N季」命名
    # (sn_list.txt 追蹤項目也是照這個慣例命名, 例如「關於我轉生變成史萊姆這檔事 第四季」), 縮寫直接拿去搜尋
    # 幾乎搜不到任何結果。因此先去除縮寫取得基礎名稱, 再依偵測到的季別數字轉換附加成「基礎名稱 第N季」重新組出
    # 搜尋關鍵字(第一季或沒有季別標記則不附加, 因為多數作品第一季在站上不會特別標出「第一季」字樣)
    gossip_season = _season_number(title)
    base_title = _SEASON_SUFFIX_PATTERN.sub('', title).strip() or title
    if gossip_season is None or gossip_season <= 1:
        return base_title, gossip_season
    season_zh = _season_num_to_zh(gossip_season)
    search_title = (base_title + ' 第' + season_zh + '季') if season_zh else base_title
    return search_title, gossip_season


# ---------------------------------------------------------------------------
# 3. 搜尋 + 解析成 sn, 與 sn_list.txt 做 sn 交集比對(不比對名稱)
# ---------------------------------------------------------------------------

def _search_candidates(title):
    url = 'https://ani.gamer.com.tw/search.php?keyword=' + quote(title)
    resp = _get(url)
    soup = BeautifulSoup(resp.text, 'html.parser')
    candidates = []
    for a in soup.select('a.theme-list-main'):
        href = a.get('href', '')
        m = re.search(r'sn=(\d+)', href)
        if not m:
            continue
        name_el = a.select_one('.theme-name')
        name = name_el.get_text().strip() if name_el else a.get_text().strip()
        year_el = a.select_one('.theme-time')
        year_text = year_el.get_text().strip() if year_el else ''
        year_match = re.search(r'(\d{4})/(\d{2})', year_text)
        year_key = (int(year_match.group(1)), int(year_match.group(2))) if year_match else (0, 0)
        candidates.append({'acg_sn': int(m.group(1)), 'title': name, 'year_key': year_key, 'year_text': year_text})
    return candidates


def _resolve_acg_to_episode_sn(acg_sn):
    resp = _get('https://ani.gamer.com.tw/animeRef.php?sn=' + str(acg_sn), allow_redirects=True)
    m = re.search(r'animeVideo\.php\?sn=(\d+)', resp.url)
    return int(m.group(1)) if m else None


_episode_set_cache = {}  # {sn: (sn_set, fetched_at)}
_episode_set_cache_lock = threading.Lock()
# 集數快取有效期: 過去快取一旦建立就永遠不會更新, 追蹤中的作品出新一集後, 後續公告比對到新集數的 sn
# 會因為不在舊快取裡而被誤判成「無法判斷」——即使該作品明明有在追蹤。設個有效期讓它定期重新查詢即可,
# 不需要精準即時(公告比對本來就是排程性質, 慢個一小時內發現新集數可接受)
_EPISODE_SET_CACHE_TTL_SECONDS = 3600


def _episode_sn_set(any_episode_sn):
    now = time.time()
    with _episode_set_cache_lock:
        cached = _episode_set_cache.get(any_episode_sn)
        if cached and now - cached[1] < _EPISODE_SET_CACHE_TTL_SECONDS:
            return cached[0]
    try:
        anime = Anime(any_episode_sn)
        sn_set = set(anime.get_episode_list().values())
        sn_set.add(any_episode_sn)
    except Exception:
        sn_set = {any_episode_sn}
    with _episode_set_cache_lock:
        for known_sn in sn_set:
            _episode_set_cache[known_sn] = (sn_set, now)
    return sn_set


def match_title_to_sn(title, sn_dict):
    # 回傳 (matched_sn 或 None, matched_name, method, candidates)
    search_title, gossip_season = _build_search_title(title)
    try:
        candidates = _search_candidates(search_title)
    except Exception as e:
        err_print(0, '監視公告', '搜尋《' + search_title + '》失敗: ' + str(e), status=1, no_sn=True)
        return None, None, 'search_failed', []

    same_tier = [c for c in candidates if _season_compatible(gossip_season, _season_number(c['title']))]
    if not same_tier:
        return None, None, 'unmatched', candidates
    # 依年份新到舊排序後逐一嘗試, 而不是只看排名最前面那個——搜尋結果同一季別可能同時列出好幾筆
    # (重製版/合輯/其他同名作品等), 最新的一筆不一定是使用者實際在追蹤的那部, 逐一比對 sn 交集才不會漏掉
    for chosen in sorted(same_tier, key=lambda c: c['year_key'], reverse=True):
        try:
            episode_sn = _resolve_acg_to_episode_sn(chosen['acg_sn'])
            if episode_sn is None:
                continue
            candidate_set = _episode_sn_set(episode_sn)
        except Exception as e:
            err_print(0, '監視公告', '解析《' + title + '》集數列表失敗: ' + str(e), status=1, no_sn=True)
            continue
        for sn, info in sn_dict.items():
            tracked_set = _episode_sn_set(sn)
            if candidate_set & tracked_set:
                return sn, (info.get('rename') or ''), 'sn_overlap', candidates
    return None, None, 'unmatched', candidates


# ---------------------------------------------------------------------------
# 4. 公告文字解析(規則式, 覆蓋常見措辭; 無法辨識的一律標記 manual_review, 交給人工判斷)
# ---------------------------------------------------------------------------

_TITLE_PATTERN = re.compile(r'《([^《》]+)》')
_TIME_PATTERN = re.compile(r'(\d{1,2}):(\d{2})')
_DATE_PATTERN = re.compile(r'(\d{1,2})/(\d{1,2})')
_EPISODE_PATTERN = re.compile(r'第\s*(\d+)\s*話')
_PAUSE_WORDS = ('暫停', '停播', '停止更新')
_TAKEDOWN_WORDS = ('下架',)
_MERGE_WORDS = ('同時', '一併', '合併')
_EXTRA_EP_WORDS = ('更新兩集', '更新2集', '加更兩集')
_EARLY_WORDS = ('提前', '提早')
_RESUME_PATTERN = re.compile(r'(?:將於|回復|恢復)\D{0,6}(\d{1,2})/(\d{1,2})')

# 公告常見沒有給明確 HH:MM 時刻, 只用「明日白天」「今晚」這種相對日期詞+模糊時段詞交代更新時間, 過去這種寫法
# 完全沒有 _TIME_PATTERN/_DATE_PATTERN 可比對, 只能落入 manual_review、最終顯示成「無法判斷」, 使用者還得自己
# 換算成日期手動填「自訂更新時間」。這裡改成抓出這兩種詞, 算出一個(粗略但夠用的)日期+時間範圍, 讓這類公告
# 也能像有明確時刻的公告一樣走「延後更新」判斷、直接套用「本週延後更新」——查詢範圍寧可寬鬆也不要漏查
_RELATIVE_DATE_WORDS = {'明日': 1, '明天': 1, '後天': 2, '後日': 2, '大後天': 3, '今日': 0, '今天': 0, '今晚': 0}
_DAYPART_WORDS = {
    '凌晨': ('00:00', '06:00'), '早上': ('06:00', '09:00'), '上午': ('06:00', '12:00'),
    '中午': ('11:00', '13:00'), '下午': ('13:00', '18:00'), '傍晚': ('17:00', '19:00'),
    '晚上': ('18:00', '24:00'), '深夜': ('23:00', '06:00'),  # 深夜跨午夜, 消費端(process_oneoff_entries)自行處理 end<start
    '白天': ('08:00', '18:00'),
}


def _resolve_fuzzy_date(relative_days, window, reference_dt):
    # 相對日期詞(明日/今天等)有明確寫出時直接用它算日期; 沒寫的話(公告只寫「白天更新」沒交代是哪一天)
    # 比照 _resolve_date() 對純時刻字串的處理方式: 用時段的結束時刻判斷「今天」這個時段是否已經過去,
    # 過去式的話順延一天, 避免算出來的目標時間落在過去導致覆蓋排程一到點檢查就直接判定過期
    if relative_days is not None:
        return (reference_dt + datetime.timedelta(days=relative_days)).date()
    start_str, end_str = window
    start_hour, start_minute = map(int, start_str.split(':'))
    end_hour, end_minute = (23, 59) if end_str == '24:00' else map(int, end_str.split(':'))
    if (end_hour, end_minute) <= (start_hour, start_minute):
        # 跨午夜的時段(例如「深夜」23:00~06:00): 用「今天」的結束時刻(隔天凌晨06:00)去判斷是否已過,
        # 其實比對的是「昨晚」那一輪的尾巴, 跟「今晚」是不同的時段實例——不論現在幾點,「今晚」這個
        # 時段起點永遠還沒發生或正在進行中, 一律錨定在今天, 讓 _process_override_check_window 自己
        # 對結束時刻(隔天06:00)順延一天即可, 這裡不能再多順延一次, 否則會整整晚一天
        return reference_dt.date()
    end_dt_today = datetime.datetime.combine(reference_dt.date(), datetime.time(end_hour, end_minute))
    if end_dt_today < reference_dt:
        return (reference_dt + datetime.timedelta(days=1)).date()
    return reference_dt.date()


def _split_clauses(text):
    # 用全形/半形句號、分號、換行拆句——公告常見「暫停一件事；延後另一件事」這種用分號並列不同動作的寫法,
    # 若不拆開, 兩件事會被套用同一組「暫停/延後」關鍵字判斷, 互相污染彼此的分類
    parts = re.split(r'[。；;\n]', text)
    return [p.strip() for p in parts if p.strip()]


def _extract_title_time_pairs(clause):
    titles = [(m.start(), m.group(1)) for m in _TITLE_PATTERN.finditer(clause)]
    times = [(m.start(), m.group(0)) for m in _TIME_PATTERN.finditer(clause)]
    pairs = []
    if len(titles) == 1:
        # 整句只有一部作品時, 時間不論離標題多遠都算它的(公告常見「《作品》因為XXX原因, 預計延至 HH:MM」這種長敘述)
        pairs.append((titles[0][1], times[0][1] if times else None))
        return pairs
    for pos, title in titles:
        best, best_dist = None, None
        for tpos, tstr in times:
            dist = abs(tpos - pos)
            if dist <= 30 and (best_dist is None or dist < best_dist):
                best, best_dist = tstr, dist
        pairs.append((title, best))
    return pairs


def parse_gossip_text(text):
    events = []
    for clause in _split_clauses(text):
        titles_in_clause = _TITLE_PATTERN.findall(clause)
        if not titles_in_clause:
            events.append({'title': None, 'action': 'log_only', 'raw_clause': clause, 'confidence': 'n/a'})
            continue

        has_pause = any(w in clause for w in _PAUSE_WORDS)
        has_takedown = any(w in clause for w in _TAKEDOWN_WORDS)
        has_merge = any(w in clause for w in _MERGE_WORDS)
        has_extra_ep = any(w in clause for w in _EXTRA_EP_WORDS)
        has_early = any(w in clause for w in _EARLY_WORDS)
        has_tentative = '暫定' in clause
        episodes = _EPISODE_PATTERN.findall(clause)
        pairs = _extract_title_time_pairs(clause)
        single_title = len(titles_in_clause) == 1
        # 用最長匹配而非字典順序:'大後天' 本身包含 '後天' 這個子字串, 若照字典/迭代順序取第一個
        # 命中的詞, 「大後天下午更新」會先被 '後天' 命中(少算一天), 取最長的才會正確選到 '大後天'
        relative_word = max((w for w in _RELATIVE_DATE_WORDS if w in clause), key=len, default=None)
        daypart_word = next((w for w in _DAYPART_WORDS if w in clause), None)

        for title, time_str in pairs:
            ev = {'title': title, 'raw_clause': clause, 'time': time_str, 'confidence': 'medium',
                  'tentative': has_tentative, 'early_hint': has_early}
            title_pos = clause.find('《' + title + '》')
            date_matches = list(_DATE_PATTERN.finditer(clause))
            nearby_date = None
            if single_title:
                nearby_date = date_matches[0].groups() if date_matches else None
            else:
                best_dist = None
                for dm in date_matches:
                    dist = abs(dm.start() - title_pos)
                    if dist <= 30 and (best_dist is None or dist < best_dist):
                        nearby_date, best_dist = dm.groups(), dist
            ev['explicit_date'] = nearby_date

            if has_takedown:
                ev['action'] = 'takedown'
                ev['expect_episode_count'] = 1
            elif has_pause:
                ev['action'] = 'pause'
                resume_match = _RESUME_PATTERN.search(clause)
                ev['resume_date'] = resume_match.groups() if resume_match else None
                ev['expect_episode_count'] = 1
            elif time_str or nearby_date:
                ev['action'] = 'delay'
                ev['expect_episode_count'] = 2 if (has_merge or has_extra_ep or len(episodes) >= 2) else 1
                if episodes:
                    ev['episode_labels'] = ['第' + e + '話' for e in episodes]
            elif daypart_word:
                # 沒有明確 HH:MM/MM:DD, 但抓到「明日」「白天」這類相對日期詞+模糊時段詞: 當成延後更新處理,
                # 只是目標時間是一段範圍(fuzzy_window)而不是單一時刻, 見 _classify_status()/apply_disposition_for_event()
                ev['fuzzy_window'] = _DAYPART_WORDS[daypart_word]
                ev['fuzzy_relative_days'] = _RELATIVE_DATE_WORDS.get(relative_word)
                ev['action'] = 'delay'
                ev['expect_episode_count'] = 2 if (has_merge or has_extra_ep or len(episodes) >= 2) else 1
                if episodes:
                    ev['episode_labels'] = ['第' + e + '話' for e in episodes]
            elif has_extra_ep or has_merge or len(episodes) >= 2:
                # 沒有給明確時間, 但有「同時/一併/合併」或「加更兩集」字樣, 或一次列出兩個以上集數:
                # 視為「本週同時更新」類的公告(照常規時間檢查, 只是這次會有不只一集), 不需要額外的時間資訊
                ev['action'] = 'extra_episode'
                ev['expect_episode_count'] = 2
                if episodes:
                    ev['episode_labels'] = ['第' + e + '話' for e in episodes]
            else:
                ev['action'] = 'manual_review'
                ev['confidence'] = 'low'
            events.append(ev)
    return events


def _resolve_date(mm_dd, reference_dt, time_str=None):
    if mm_dd is None:
        d = reference_dt.date()
        if time_str:
            # 公告沒有明確寫日期, 且套用「今天」這個時間點的結果已經是過去式: 常見於「今晚...凌晨 X 點更新」這種
            # 口語說法——「今晚」在中文語感裡涵蓋到隔天凌晨, 但時鐘時間已經跨過午夜、屬於下一個日曆日, 例如
            # 晚上 8 點多看到「今晚調整為 02:00 更新」, 這裡的 02:00 指的是明天凌晨 2 點, 不是已經過去的今天凌晨
            # 2 點, 這種情況下要把日期順延一天, 否則算出來的目標時間會落在過去, 導致覆蓋排程一到點檢查就直接判定過期
            try:
                hour, minute = map(int, time_str.split(':'))
                if datetime.datetime.combine(d, datetime.time(hour, minute)) < reference_dt:
                    d = d + datetime.timedelta(days=1)
            except ValueError:
                pass
        return d
    month, day = int(mm_dd[0]), int(mm_dd[1])
    year = reference_dt.year
    try:
        d = datetime.date(year, month, day)
    except ValueError:
        return reference_dt.date()
    if d < reference_dt.date():
        # 公告裡的 MM/DD 一律代表即將發生(或今天)的更新/復播日期, 不會是純粹追溯過去的敘述; 用當前年份
        # 算出來若已經是過去式(不論差幾天), 唯一合理的解釋是實際指的是明年同一天, 而不是真的指向已經
        # 過去的那一天——舊版只在差距超過 30 天時才往後修正, 差距在 30 天內的過去日期(例如年初讀到
        # 「12/28」這種上個月的殘留字串, 或單純解析時間點稍晚)會原封不動留在過去, 導致 GossipDB.get_actionable()
        # 的 `target_date >= today` 篩選條件直接把這則子事件濾掉, 使用者在「操作處置」畫面永遠看不到、也修不了
        d = datetime.date(year + 1, month, day)
    return d


def _weekday_matches(check_date, schedule_weekday):
    return check_date.isoweekday() == schedule_weekday


def _hash_text(text):
    return hashlib.sha1(text.encode('utf-8')).hexdigest()


# ---------------------------------------------------------------------------
# 5. 狀態判斷(暫停更新/提前更新/延後更新/同時更新/暫時下架/無法判斷)+ 建議集數
# ---------------------------------------------------------------------------

def _infer_baseline_time(sn, schedule):
    # 算出這部作品「平常大概什麼時候更新」當作提前/延後判斷的基準時間, 回傳 datetime 或 None(算不出來)
    now = datetime.datetime.now()
    if schedule:
        # 有 sn_list.txt 自訂排程標籤(*星期* $時間$): 用「這次應該檢查的那個星期幾+時間」當基準
        days_ahead = (schedule['weekday'] - now.isoweekday()) % 7
        return (now + datetime.timedelta(days=days_ahead)).replace(
            hour=schedule['hour'], minute=schedule['minute'], second=0, microsecond=0)
    # 沒有自訂排程: 找出這部作品最近一次成功下載的集數, 實際查詢該集網頁上顯示的「上架時間」當基準
    # (刻意不用 anime 表的 CreatedTime——那是「檔案下載完成」的時間, 下載排隊/分段下載/網速不穩都可能讓它
    # 比真正上架時間晚上一兩個小時甚至更多, 拿來當「平常幾點更新」的基準會把本來的延後更新誤判成提前更新)
    try:
        with closing(sqlite3.connect(Config.db_path, timeout=10)) as conn:
            tracked_set = _episode_sn_set(sn)
            placeholders = ','.join('?' * len(tracked_set))
            row = conn.execute(
                'SELECT sn FROM anime WHERE sn IN (' + placeholders + ') AND status=1 '
                'ORDER BY CreatedTime DESC LIMIT 1', tuple(tracked_set)).fetchone()
    except sqlite3.Error:
        return None
    if not row:
        return None
    try:
        last_upload_time = Anime(row[0]).get_upload_time()
    except Exception:
        return None
    if last_upload_time is None:
        return None
    days_ahead = (last_upload_time.isoweekday() - now.isoweekday()) % 7
    return (now + datetime.timedelta(days=days_ahead)).replace(
        hour=last_upload_time.hour, minute=last_upload_time.minute, second=0, microsecond=0)


def _classify_status(ev, schedule, matched_sn):
    # 回傳 (status_label, target_date:date|None, target_time:str|None, target_window:(str,str)|None)
    now = datetime.datetime.now()
    action = ev['action']

    if action == 'takedown':
        return '暫時下架', _resolve_date(ev.get('explicit_date'), now), None, None

    if action == 'pause':
        return '暫停更新', _resolve_date(ev.get('explicit_date'), now), None, None

    if action == 'extra_episode':
        return '同時更新', _resolve_date(ev.get('explicit_date'), now, ev.get('time')), ev.get('time'), None

    if action == 'delay':
        if ev.get('fuzzy_window'):
            # 只有相對日期詞+模糊時段詞, 沒有明確 HH:MM 可比對基準時間: 依集數/提前提示詞判斷狀態,
            # 沒有其他線索時比照下面明確時刻的情況, 以延後更新為預設猜測(公告絕大多數情況是延後)
            d = _resolve_fuzzy_date(ev.get('fuzzy_relative_days'), ev['fuzzy_window'], now)
            if ev.get('expect_episode_count', 1) >= 2:
                return '同時更新', d, None, ev['fuzzy_window']
            if ev.get('early_hint'):
                return '提前更新', d, None, ev['fuzzy_window']
            return '延後更新', d, None, ev['fuzzy_window']

        d = _resolve_date(ev.get('explicit_date'), now, ev.get('time'))
        if ev.get('expect_episode_count', 1) >= 2:
            return '同時更新', d, ev.get('time'), None
        if ev.get('early_hint'):
            return '提前更新', d, ev.get('time'), None
        if matched_sn is not None and ev.get('time'):
            baseline = _infer_baseline_time(matched_sn, schedule)
            if baseline is not None:
                try:
                    hour, minute = map(int, ev['time'].split(':'))
                    target_dt = datetime.datetime.combine(d, datetime.time(hour, minute))
                    if target_dt < baseline:
                        return '提前更新', d, ev.get('time'), None
                    return '延後更新', d, ev.get('time'), None
                except ValueError:
                    pass
        if ev.get('time') or ev.get('explicit_date'):
            # 沒有基準時間可比對(新追蹤/從未下載過的作品, 或沒有設定自訂排程): 公告絕大多數情況是延後,
            # 沒有更多資訊時以延後更新為預設猜測, 使用者仍可在「操作處置」畫面自行改成提前/其他
            return '延後更新', d, ev.get('time'), None
        return '無法判斷', None, None, None

    return '無法判斷', None, None, None


def _format_episode_num(n):
    return '第' + str(int(n)).zfill(2) + '話'


def _episode_display(ev, matched_sn):
    if ev.get('episode_labels'):
        return '、'.join(ev['episode_labels'])
    if matched_sn is None:
        return '-'
    try:
        anime = Anime(matched_sn)
        ep_list = anime.get_episode_list()
        nums = [float(label) for label in ep_list if re.match(r'^\d+(\.\d+)?$', label)]
        if not nums:
            return '-'
        return _format_episode_num(int(max(nums)) + 1)
    except Exception:
        return '-'


# ---------------------------------------------------------------------------
# 6. 主流程: 更新終了後呼叫這個
# ---------------------------------------------------------------------------

_GOSSIP_NOTIFY_CATEGORY = {'pause': 'gossip_pause', 'delay': 'gossip_delay', 'extra_episode': 'gossip_extra_episode'}


def run_gossip_check(settings, sn_dict):
    if not settings.get('gossip_monitor', True):
        return
    try:
        text = fetch_gossip_text()
        if not text:
            return
        source_hash = _hash_text(text)
        captured_at = datetime.datetime.now().isoformat(sep=' ', timespec='seconds')

        if not GossipDB.record_gossip_text(text, source_hash, captured_at):
            # 同一則公告在網站上停留期間, 每次「更新終了」都可能重新抓到一樣的文字,
            # 只在第一次看到時處理, 避免同一則公告在歷史紀錄裡被重複列出好幾次
            return

        sub_events = parse_gossip_text(text)
        processed_at = captured_at
        dynamic_schedule_on = settings.get('gossip_dynamic_schedule', True)

        for ev in sub_events:
            record = {'raw_clause': ev['raw_clause'], 'action': ev['action']}
            title = ev.get('title')
            if title is None:
                record['match'] = 'no_target'
                record['status_label'] = '無法判斷'
                record['episode_display'] = '-'
                GossipDB.add_event(source_hash, processed_at, record)
                continue

            matched_sn, matched_name, method, candidates = match_title_to_sn(title, sn_dict)
            record['title_in_gossip'] = title
            record['search_candidates'] = [
                {'acg_sn': c['acg_sn'], 'title': c['title'], 'year': c['year_text']} for c in candidates
            ]
            record['match_method'] = method

            if matched_sn is None:
                record['match'] = 'unmatched'
                record['status_label'] = '無法判斷'
                record['episode_display'] = '-'
                GossipDB.add_event(source_hash, processed_at, record)
                continue

            record['match'] = 'matched'
            record['sn'] = matched_sn
            record['name'] = matched_name
            schedule = sn_dict[matched_sn].get('schedule')

            # 推送公告通知: 用原始判讀出的 action(而非底下的處置)決定類別, 不論「機動調整時間」
            # 這個自動排程功能本身有沒有開啟都照樣通知——使用者要知道的是公告內容本身, 不是有沒有自動幫他調整排程
            notify_category = _GOSSIP_NOTIFY_CATEGORY.get(ev['action'], 'gossip_other')
            notify_context = {
                'animation_name': matched_name,
                'announcement_text': ev['raw_clause'],
                'announcement_time': NotifyDB.now_str(),
                'finish_time': NotifyDB.now_str(),
            }
            if ev['action'] == 'delay':
                try:
                    if ev.get('fuzzy_window'):
                        postpone_date = _resolve_fuzzy_date(ev.get('fuzzy_relative_days'), ev['fuzzy_window'],
                                                             datetime.datetime.now())
                        postpone_time = postpone_date.strftime('%Y-%m-%d') + ' ' + '~'.join(ev['fuzzy_window'])
                    else:
                        postpone_date = _resolve_date(ev.get('explicit_date'), datetime.datetime.now(), ev.get('time'))
                        postpone_time = postpone_date.strftime('%Y-%m-%d')
                        if ev.get('time'):
                            postpone_time += ' ' + ev['time']
                    notify_context['postpone_time'] = postpone_time
                except Exception:
                    pass
            Config.send_notification(notify_category, '公告通知', **notify_context)

            status_label, target_date, target_time, target_window = _classify_status(ev, schedule, matched_sn)
            record['status_label'] = status_label
            record['episode_display'] = _episode_display(ev, matched_sn)
            record['target_date'] = target_date.isoformat() if target_date else None
            record['target_time'] = target_time
            if target_window:
                record['target_time_start'], record['target_time_end'] = target_window

            event_id = GossipDB.add_event(source_hash, processed_at, record)

            if dynamic_schedule_on and status_label != '無法判斷' and ev.get('confidence') != 'low':
                system_suggestion = GossipDB.STATUS_TO_DEFAULT_DISPOSITION.get(status_label, '等待處置')
                try:
                    # locked=False: 這是系統依判斷結果自動套用的預設處置, 不是使用者手動確認過的,
                    # 「操作處置」畫面不應該顯示「已手動確認」徽章, 使用者選了別的處置並按下確認時才會變成 locked
                    apply_disposition_for_event(event_id, system_suggestion, locked=False)
                except ValueError as e:
                    err_print(matched_sn, '監視公告', '自動套用機動調整時間失敗: ' + str(e), status=1)

        _expire_vanished_events({ev['raw_clause'] for ev in sub_events})

        GossipDB.prune_pending(settings.get('gossip_retention_days', 30))
        err_print(0, '監視公告', '本次公告解析完成, 共 ' + str(len(sub_events)) + ' 個子事件', no_sn=True)
    except Exception as e:
        err_print(0, '監視公告', '執行時發生未知錯誤: ' + str(e), status=1, no_sn=True)


def _expire_vanished_events(current_clauses):
    # 公告文字整份重新解析(見上面呼叫處), 只有整份頁面文字有變動(record_gossip_text() 偵測到新的
    # source_hash)才會走到這裡——但這不代表這次解析出的每個子句都還在原本的頁面上: 巴哈姆特把某則已經
    # 處理完的公告從頁面撤下時, 頁面雜湊自然也會跟著變, 目前的解析邏輯卻是整份重新解析、沒有拿「這次
    # 還看得到哪些子句」去對照「先前還在等待處置、系統自動套用建議但使用者還沒手動確認過」的舊子事件,
    # 導致公告明明已經被撤下, 「操作處置」卻永遠留著、機動調整臨時排程也永遠不會被清掉。
    #
    # 這裡只處理使用者還沒手動確認過(disposition_locked=0)的項目——已經手動確認過的維持原樣不動,
    # 公告文字從頁面撤下不代表使用者當初做的決定跟著失效(有可能只是官網把已解決的公告清掉,
    # 不代表原本的處置判斷錯了), 不應該悄悄覆蓋使用者自己確認過的選擇
    today_str = datetime.date.today().isoformat()
    for event in GossipDB.get_actionable(today_str):
        if event.get('disposition_locked'):
            continue
        if event.get('raw_clause') in current_clauses:
            continue
        try:
            # locked=True(而非系統自動套用建議常用的 False): 這裡要讓項目真正從「操作處置」消失,
            # 不是留著一個預設選好但還沒確認的建議——見 GossipDB.get_actionable() 排除「已確認忽略」項目的說明
            apply_disposition_for_event(event['id'], '忽略此公告', locked=True)
        except ValueError:
            pass


# ---------------------------------------------------------------------------
# 7. 處置(操作處置畫面的「確認」按鈕與系統自動套用都走這個函式)
# ---------------------------------------------------------------------------

def _cached_anime_name(sn):
    # 從本地 aniGamer.db 的下載紀錄快取撈番劇名稱, 跟 aniGamerPlus.py 的 _lookup_cached_anime_name() 同樣邏輯,
    # 這裡不能直接 import aniGamerPlus(aniGamerPlus.py 反過來 import 這個模組, 會造成循環引用), 故獨立實作一份
    try:
        with closing(sqlite3.connect(Config.db_path, timeout=10)) as conn:
            row = conn.execute('SELECT anime_name FROM anime WHERE sn=?', (sn,)).fetchone()
    except sqlite3.Error:
        return None
    return row[0] if row else None


def assign_manual_sn(event_id, sn, sn_dict):
    # 供操作處置畫面「選擇指定排程」使用, 只限公告的「無法判斷」項目(match_status='unmatched', 沒有比對到 sn)——
    # 已經自動比對到作品的子事件不需要、也不應該被手動覆蓋掉自動比對結果, 一律拒絕
    event = GossipDB.get_event(event_id)
    if event is None:
        raise ValueError('找不到指定的公告子事件')
    if event['sn'] is not None:
        raise ValueError('這則子事件已經自動比對到作品, 不需要手動指定排程')
    info = sn_dict.get(sn)
    if info is None:
        raise ValueError('指定的排程項目不存在, 可能已從追蹤清單移除')
    name = _cached_anime_name(sn) or info.get('rename') or ('sn=' + str(sn))
    GossipDB.set_manual_sn(event_id, sn, name)


# 這個鎖只序列化「清掉舊覆蓋 + 寫入新覆蓋」這整段操作本身, 跟 GossipDB._gossip_db_lock(只包住單次
# DB 呼叫)是不同的鎖、不會巢狀搶同一把鎖造成死鎖。因為 remove_pending_for_event()/add_pending() 是兩次
# 各自獨立上鎖的 DB 呼叫, 沒有這把鎖的話, 兩個並發的 apply_disposition_for_event() 呼叫(例如使用者快速
# 連點兩次「確認」)可能都先執行完各自的 remove、才輪到 add, 疊加出兩筆互相矛盾的臨時排程
_apply_disposition_lock = threading.Lock()


def apply_disposition_for_event(event_id, disposition, custom_check_date=None, custom_check_time=None,
                                 custom_episode_count=None, locked=True,
                                 custom_check_time_start=None, custom_check_time_end=None):
    _apply_disposition_lock.acquire()
    try:
        return _apply_disposition_for_event(event_id, disposition, custom_check_date, custom_check_time,
                                             custom_episode_count, locked,
                                             custom_check_time_start, custom_check_time_end)
    finally:
        _apply_disposition_lock.release()


def _apply_disposition_for_event(event_id, disposition, custom_check_date, custom_check_time,
                                  custom_episode_count, locked,
                                  custom_check_time_start, custom_check_time_end):
    event = GossipDB.get_event(event_id)
    if event is None:
        raise ValueError('找不到指定的公告子事件')
    if disposition not in GossipDB.DISPOSITION_OPTIONS:
        raise ValueError('未知的處置方式: ' + str(disposition))

    # 先清掉這個子事件先前建立的舊排程覆蓋(不論是系統自動套用或使用者先前手動選過的), 避免同一則公告
    # 因為重複確認/改選而疊加出兩筆互相矛盾的臨時排程
    GossipDB.remove_pending_for_event(event_id)

    sn = event['sn']
    name = event['name']
    source_hash = event['source_hash']

    if disposition in ('等待處置', '忽略此公告'):
        GossipDB.set_disposition(event_id, disposition, applied=True, locked=locked)
        return

    if sn is None:
        raise ValueError('這則子事件尚未比對到追蹤中的作品, 無法套用排程處置(可選擇「忽略此公告」關閉待處理狀態)')

    now = datetime.datetime.now()
    target_date = datetime.date.fromisoformat(event['target_date']) if event['target_date'] else now.date()
    target_time = event['target_time']

    def _retry_fields(check_date_str, check_time_str):
        # 覆蓋檢查時間一律給「目標檢查時間之後」2 小時的重試視窗(每 30 分鐘複查一次), 而不是只檢查一次就直接
        # 放棄——公告寫的時間未必精準到分秒, 目標時間到了但影片還沒真的上架是常態, 只檢查一次很容易在還沒上架
        # 時就誤判成「過期」(v25.2.0 上線後第一批實測就踩到: 單集覆蓋完全沒有重試, 到點檢查一次沒找到就直接
        # 標記過期, 使用者在「機動調整」畫面完全看不到這筆本來應該還在等待的紀錄)。
        # 期限刻意從「目標檢查時間」而不是「現在(套用處置的當下)」起算——公告偵測到/使用者確認處置的時間點,
        # 跟公告寫的目標時間可能差很多個小時(例如中午就看到公告說「今晚 19:30 更新」), 若從「現在」起算 2 小時,
        # 目標時間都還沒到、這筆覆蓋就會先過期, 完全達不到重試視窗的效果(v25.2.3 修正的實際案例)
        check_dt = datetime.datetime.strptime(check_date_str + ' ' + check_time_str, '%Y-%m-%d %H:%M')
        return {'retry_enabled': True, 'retry_interval_minutes': 30,
                'retry_deadline': (check_dt + datetime.timedelta(hours=2)).isoformat()}

    if disposition in ('本週暫停更新', '本週下架'):
        GossipDB.add_pending({
            'event_id': event_id, 'sn': sn, 'name': name, 'type': 'skip_check',
            'check_date': target_date.isoformat(), 'source_hash': source_hash,
        })
    elif disposition in ('本週提前更新', '本週延後更新'):
        if target_time:
            GossipDB.add_pending({
                'event_id': event_id, 'sn': sn, 'name': name, 'type': 'override_check_time',
                'check_date': target_date.isoformat(), 'check_time': target_time,
                'expect_episode_count': 1, 'source_hash': source_hash,
                **_retry_fields(target_date.isoformat(), target_time),
            })
        elif event.get('target_time_start') and event.get('target_time_end'):
            # 公告只有相對日期詞+模糊時段詞(例如「明日白天」), 沒有明確 HH:MM 可用: 改用範圍型覆蓋,
            # 在 target_time_start~target_time_end 這段範圍內每分鐘檢查一次(process_oneoff_entries())
            GossipDB.add_pending({
                'event_id': event_id, 'sn': sn, 'name': name, 'type': 'override_check_window',
                'check_date': target_date.isoformat(), 'check_time_start': event['target_time_start'],
                'check_time_end': event['target_time_end'], 'expect_episode_count': 1, 'source_hash': source_hash,
            })
        else:
            raise ValueError('公告內容沒有解析出明確時間, 請改用「自訂更新時間」或「自訂時間範圍」')
    elif disposition == '本週同時更新':
        count = max(2, len((event.get('episode_display') or '').split('、')))
        if target_time:
            GossipDB.add_pending({
                'event_id': event_id, 'sn': sn, 'name': name, 'type': 'override_check_time',
                'check_date': target_date.isoformat(), 'check_time': target_time, 'expect_episode_count': count,
                'source_hash': source_hash, **_retry_fields(target_date.isoformat(), target_time),
            })
        elif event.get('target_time_start') and event.get('target_time_end'):
            GossipDB.add_pending({
                'event_id': event_id, 'sn': sn, 'name': name, 'type': 'override_check_window',
                'check_date': target_date.isoformat(), 'check_time_start': event['target_time_start'],
                'check_time_end': event['target_time_end'], 'expect_episode_count': count, 'source_hash': source_hash,
            })
        else:
            # 比照上面「本週提前更新」/「本週延後更新」的驗證: 沒有明確時間卻仍寫入 pending 紀錄,
            # process_oneoff_entries() 會因為沒有 check_time/check_time_start 而永久跳過這筆, 變成使用者在畫面上
            # 看不到、系統也不會再處理的殭屍排程(不會被標記完成也不會過期)
            raise ValueError('公告內容沒有解析出明確時間, 請改用「自訂連續更新時間」或「自訂時間範圍」')
    elif disposition == '自訂更新時間':
        if not (custom_check_date and custom_check_time):
            raise ValueError('自訂更新時間需要填寫日期與時間')
        GossipDB.add_pending({
            'event_id': event_id, 'sn': sn, 'name': name, 'type': 'override_check_time',
            'check_date': custom_check_date, 'check_time': custom_check_time, 'expect_episode_count': 1,
            'source_hash': source_hash, **_retry_fields(custom_check_date, custom_check_time),
        })
    elif disposition == '自訂連續更新時間':
        if not (custom_check_date and custom_check_time and custom_episode_count):
            raise ValueError('自訂連續更新時間需要填寫日期、時間與集數')
        GossipDB.add_pending({
            'event_id': event_id, 'sn': sn, 'name': name, 'type': 'override_check_time',
            'check_date': custom_check_date, 'check_time': custom_check_time,
            'expect_episode_count': int(custom_episode_count), 'source_hash': source_hash,
            **_retry_fields(custom_check_date, custom_check_time),
        })
    elif disposition == '自訂時間範圍':
        # 「未知的白天/早上/上午/中午/下午/晚上/深夜」這類沒有精確時刻的情況專用: 使用者自己給一段開始~結束時間,
        # process_oneoff_entries() 在這段範圍內每分鐘檢查一次, 不像「自訂更新時間」只在單一時刻檢查+事後補查
        if not (custom_check_date and custom_check_time_start and custom_check_time_end):
            raise ValueError('自訂時間範圍需要填寫日期、開始時間與結束時間')
        if custom_check_time_start == custom_check_time_end:
            # 開始=結束不是合法的時間範圍: _process_override_check_window() 對 end<=start 一律當成跨午夜
            # 順延一天處理(例如「深夜」23:00~06:00), 這種輸入會被誤判成整整 24 小時的範圍, 幾乎可以確定
            # 是使用者忘記調整其中一個欄位, 而不是真的想要跨午夜, 這裡直接擋掉、不留給消費端去猜
            raise ValueError('自訂時間範圍的開始時間不能跟結束時間相同')
        GossipDB.add_pending({
            'event_id': event_id, 'sn': sn, 'name': name, 'type': 'override_check_window',
            'check_date': custom_check_date, 'check_time_start': custom_check_time_start,
            'check_time_end': custom_check_time_end, 'expect_episode_count': int(custom_episode_count or 1),
            'source_hash': source_hash,
        })

    GossipDB.set_disposition(event_id, disposition, custom_check_date, custom_check_time, custom_episode_count,
                              applied=True, locked=locked, custom_check_time_start=custom_check_time_start,
                              custom_check_time_end=custom_check_time_end)


# ---------------------------------------------------------------------------
# 8. 提供給既有排程迴圈查詢/處理的介面
# ---------------------------------------------------------------------------

def is_skipped(pending_snapshot, sn, check_date):
    # pending_snapshot 參數保留(呼叫端 aniGamerPlus.py 沿用舊介面), 但改為即時查詢資料庫, 不再需要事先讀好整份快照
    return GossipDB.is_skipped(sn, check_date.isoformat())


def load_pending_snapshot():
    # 保留舊介面名稱供 aniGamerPlus.py 呼叫, 回傳格式改為 GossipDB.list_pending() 的 list, 而不是舊版
    # {'entries': [...]} 的 dict——is_skipped() 已經改成即時查詢資料庫, 不再依賴這份快照的內容,
    # 這裡回傳值只用來在 process_oneoff_entries() 前確認資料庫可正常連線
    return GossipDB.list_pending('pending')


def list_pending_for_date(date_str):
    # 供「每日新番通知」彙整當天(date_str 格式 'YYYY-MM-DD')生效中的機動調整異動(暫停/延期/加更等);
    # skip_check、override_check_time、override_check_window 三種 type 的 check_date 都是「異動生效的日期」,
    # 直接照這個欄位過濾即可, 不需要額外判斷
    return [entry for entry in GossipDB.list_pending('pending') if entry.get('check_date') == date_str]


_WINDOW_CHECK_INTERVAL_MINUTES = 1  # 「自訂時間範圍」/模糊時段(明日白天等)覆蓋: 範圍內每分鐘檢查一次


def _run_pending_check(entry, check_single_sn, start_queued_workers, queue, processing_queue, read_db):
    # override_check_time 與 override_check_window 共用的「實際觸發一次檢查」邏輯: 呼叫 check_single_sn(),
    # 彙整這次+先前看過的集數(seen_episodes)算出目前已確定拿到幾集, 回傳 (found, found_episode_count)
    sn = entry['sn']
    queued_before = set(queue.keys())
    found = check_single_sn(sn)
    start_queued_workers()
    newly_queued = set(queue.keys()) - queued_before

    seen = set(entry.get('seen_episodes', [])) | newly_queued
    done_count = 0
    for ep in seen:
        try:
            if read_db(ep)['status'] == 1 or ep in queue.keys() or ep in processing_queue:
                done_count += 1
        except IndexError:
            pass
    found_episode_count = max(done_count, len(newly_queued) if found else entry['found_episode_count'])
    return found, seen, found_episode_count


def process_oneoff_entries(now, check_single_sn, start_queued_workers, queue, processing_queue, read_db):
    # 處理 override_check_time / override_check_window 類型的臨時排程(本週時間調整/自訂更新時間/連續更新時間的
    # 雙重保險複查、模糊時段的範圍內每分鐘檢查), 由 _scheduled_check_worker 每輪(30秒)呼叫一次
    for entry in GossipDB.list_pending('pending'):
        if entry['type'] == 'override_check_time':
            _process_override_check_time(entry, now, check_single_sn, start_queued_workers, queue, processing_queue,
                                          read_db)
        elif entry['type'] == 'override_check_window':
            _process_override_check_window(entry, now, check_single_sn, start_queued_workers, queue,
                                            processing_queue, read_db)


def _process_override_check_time(entry, now, check_single_sn, start_queued_workers, queue, processing_queue,
                                  read_db):
    if not entry.get('check_time'):
        return  # 公告只給模糊時段(例如「白天」), 沒有明確時間就不主動觸發, 交由使用者/一般檢查機制發現

    try:
        check_dt = datetime.datetime.strptime(entry['check_date'] + ' ' + entry['check_time'], '%Y-%m-%d %H:%M')
    except ValueError:
        GossipDB.update_pending(entry['id'], status='expired')
        return

    deadline = datetime.datetime.fromisoformat(entry['retry_deadline']) if entry.get('retry_deadline') else None
    if deadline and now > deadline:
        GossipDB.update_pending(entry['id'], status='expired' if entry['found_episode_count'] == 0 else 'done')
        return

    should_check = False
    if now >= check_dt and not entry.get('checked_once'):
        should_check = True
    else:
        next_retry_at = entry.get('next_retry_at')
        if next_retry_at and now >= datetime.datetime.fromisoformat(next_retry_at):
            should_check = True
    if not should_check:
        return

    found, seen, found_episode_count = _run_pending_check(entry, check_single_sn, start_queued_workers, queue,
                                                            processing_queue, read_db)
    updates = {'checked_once': True, 'seen_episodes': list(seen), 'found_episode_count': found_episode_count}
    if found_episode_count >= entry['expect_episode_count']:
        updates['status'] = 'done'
    elif entry.get('retry_enabled'):
        updates['next_retry_at'] = (now + datetime.timedelta(
            minutes=entry['retry_interval_minutes'] or 30)).isoformat()
        err_print(entry['sn'], '監視公告', '已找到部分集數, ' + str(entry['retry_interval_minutes']) +
                  ' 分鐘後複查是否已補齊剩餘集數(雙重保險)', status=2)
    else:
        updates['status'] = 'done' if found else 'expired'
    GossipDB.update_pending(entry['id'], **updates)


def _process_override_check_window(entry, now, check_single_sn, start_queued_workers, queue, processing_queue,
                                    read_db):
    if not entry.get('check_time_start') or not entry.get('check_time_end'):
        return
    try:
        start_dt = datetime.datetime.strptime(entry['check_date'] + ' ' + entry['check_time_start'], '%Y-%m-%d %H:%M')
        end_str = entry['check_time_end']
        if end_str == '24:00':
            end_dt = start_dt.replace(hour=0, minute=0) + datetime.timedelta(days=1)
        else:
            end_dt = datetime.datetime.strptime(entry['check_date'] + ' ' + end_str, '%Y-%m-%d %H:%M')
        if end_dt <= start_dt:
            end_dt += datetime.timedelta(days=1)  # 跨午夜的時段(例如「深夜」23:00~06:00)
    except ValueError:
        GossipDB.update_pending(entry['id'], status='expired')
        return

    if now < start_dt:
        return  # 還沒進入檢查範圍
    if now > end_dt:
        GossipDB.update_pending(entry['id'], status='expired' if entry['found_episode_count'] == 0 else 'done')
        return

    next_check_at = entry.get('next_retry_at')
    if next_check_at and now < datetime.datetime.fromisoformat(next_check_at):
        return  # 還沒到下一次每分鐘檢查的時間點

    found, seen, found_episode_count = _run_pending_check(entry, check_single_sn, start_queued_workers, queue,
                                                            processing_queue, read_db)
    updates = {
        'checked_once': True, 'seen_episodes': list(seen), 'found_episode_count': found_episode_count,
        'next_retry_at': (now + datetime.timedelta(minutes=_WINDOW_CHECK_INTERVAL_MINUTES)).isoformat(),
    }
    if found_episode_count >= entry['expect_episode_count']:
        updates['status'] = 'done'
    GossipDB.update_pending(entry['id'], **updates)
